# JavaFX Desktop Design System

A reference for keeping the desktop app visually consistent with the web product — same structure and rigor as a web design system (tokens → typography → components), rewritten for what JavaFX can actually do.

---

## 0. Read this first — about the source files

The zip contained a production web design system, not a generic stylesheet: the CSS is versioned (`data-ds-version="v2026.9.19"`), tagged per sub-brand (`data-brand=blackrock / ishares / aladdin / aladdin-hub`), and the type family (`BLK Fort`) is a custom typeface named after a specific ticker. That's a company's proprietary, internally-licensed brand system, not a set of assets that come free to reuse in an unrelated app.

So this document and `global.css` copy the **structure** of what's there — the same kind of token scale, the same component inventory (buttons, inputs, nav, tabs, modal, cards, pagination, notifications) — but with:
- a **neutral placeholder palette** instead of the exact brand hex values, and
- a **placeholder font name** instead of `BLK Fort` and its actual font files.

If you're building this as an authorized internal tool for that organization and have the rights to the real tokens and font, swapping them in is a five-minute find-and-replace — every place a value needs to change is centralized in `.root` in `global.css` and in §4 below. If not, treat the palette here as a starting point and put your own brand colors in.

One more thing worth flagging separately from the legal question: even with permission, the actual `.woff2` files in the zip **cannot be loaded by JavaFX as-is** — see §5. You'll need `.ttf`/`.otf` versions regardless of whose font it is.

---

## 1. How this maps from web to JavaFX

The single biggest mistake porting a web design system to JavaFX is assuming the CSS does the same job. It doesn't — JavaFX CSS only styles nodes that Java code already created and arranged. Layout, structure, and composition are Java/FXML's job, not CSS's.

| Web concept | JavaFX reality |
|---|---|
| `@font-face` | Doesn't exist. Fonts are registered in Java via `Font.loadFont(...)` before the scene is shown. CSS only *references* the family name after that. |
| CSS variables (`--x`, `var(--x)`) | "Looked-up values": declare `-my-token: value;` under `.root`, reference it elsewhere as `-fx-property: -my-token;` (no `var()` wrapper). Reliable for colors; treat numeric/text tokens as documentation you keep in sync by hand (see §4). |
| `display:flex`, CSS Grid | Not a CSS concept in JavaFX. Use `HBox`, `VBox`, `GridPane`, `BorderPane`, `StackPane`, `FlowPane` in Java/FXML. CSS can set `-fx-spacing` (on HBox/VBox) and `-fx-hgap`/`-fx-vgap` (on GridPane), but the box structure itself is code. |
| `box-shadow` | `-fx-effect: dropshadow(gaussian, rgba(0,0,0,.15), 24, 0, 0, 6);` — one effect per node, can't stack multiple shadows. |
| `border-radius` | Needs **two** properties in sync: `-fx-background-radius` (shapes the fill) and `-fx-border-radius` (shapes the stroke). Also set `-fx-background-insets: 0;` or you'll see a ghost square corner peeking out. |
| `:hover`, `:focus`, `:disabled` | Native pseudo-classes on standard controls: `:hover`, `:pressed`, `:focused`, `:disabled`, `:selected`, `:armed`. No JS needed. |
| `letter-spacing` | **Not supported.** There is no tracking/letter-spacing property in JavaFX CSS. For short uppercase labels (eyebrows, badges) where tracking matters visually, either accept tighter type or insert a thin space character between letters programmatically — don't rely on CSS for it. |
| `line-height` (multiplier) | `-fx-line-spacing` adds a fixed pixel gap between wrapped lines — it's additive, not a multiplier. Tune per text size rather than reusing one ratio everywhere. |
| Responsive breakpoints | No viewport media queries. If you want the layout to adapt to window size, bind a listener to `stage.widthProperty()` in Java and swap layout/style classes yourself. |
| Font stacks (`font-family: A, B, C`) | Give one real family name. Fallback lists aren't reliably honored — load the fonts you need and reference them directly. |

Keep this table in mind before assuming anything from the original CSS "just works" — most of it needs a deliberate JavaFX equivalent rather than a copy-paste.

---

## 2. Design principles

- **Neutral first, one accent.** Black/white/gray carries the interface; a single accent color is reserved for primary actions, links, and focus states. Don't let more than one accent hue compete for attention on a screen.
- **Density over decoration.** This is a working tool, not a marketing page — tighter type, tighter spacing, fewer large hero-style moments than the web site would use. See §4.4 for why the type scale here is compressed relative to a marketing site's.
- **Calm motion.** Short, consistent transition durations for state changes (hover, focus, panel open/close). Nothing bounces; nothing takes longer than ~350ms.
- **Consistent elevation logic.** Flat surfaces are the default. Shadow only appears when something is meant to float above the page — a card, a popover, a modal — and the amount of shadow should track how "high" it floats (see the elevation scale).
- **States are not afterthoughts.** Every interactive class in `global.css` defines hover, pressed/active, focused, and disabled — design new components the same way from the start rather than bolting states on later.

---

## 3. Design tokens

All of these are declared once, under `.root`, in `global.css`. Reference them by name — don't hardcode hex values or pixel numbers in individual component rules.

### 3.1 Color roles

| Token | Placeholder value | Use for |
|---|---|---|
| `-color-bg` | `#FFFFFF` | App/window background |
| `-color-bg-subtle` | `#F6F6F4` | Secondary panels, table stripe, subtle section fill |
| `-color-bg-inverse` | `#111111` | Sidebar, dark chrome |
| `-color-surface` | `#FFFFFF` | Cards, inputs, dialogs, popovers |
| `-color-border` | `#1A1A1A` | High-emphasis borders (rare) |
| `-color-border-subtle` | `#D9D9D6` | Input borders, dividers between sections |
| `-color-border-subtlest` | `#ECECE9` | Table row lines, card hairlines |
| `-color-text` | `#111111` | Default text |
| `-color-text-subtle` | `#5B5B57` | Secondary text, captions, labels |
| `-color-text-disabled` | `#A3A39E` | Disabled text |
| `-color-text-inverse` | `#FFFFFF` | Text on dark/accent backgrounds |
| `-color-accent` | `#1F5FBF` | **Replace with your brand color.** Primary buttons, links, focus rings, selection |
| `-color-success` | `#1B8A5A` | Gains, confirmations |
| `-color-warning` | `#B7791F` | Warnings, pending states |
| `-color-error` | `#C0272D` | Losses, errors, destructive actions |

`derive(-color-accent, -12%)` / `derive(-color-accent, 85%)` etc. generate hover/pressed/tint variants from a single source color — see `global.css` — so changing the one accent token re-tints every derived state automatically.

### 3.2 Spacing scale (4pt grid)

`xxxs 4 · xxs 8 · xs 12 · s 16 · m 24 · l 32 · xl 40 · xxl 48 · xxxl 56` (px)

Use `s`/`m` for control padding, `l`/`xl` for spacing between form fields or list items, `xxl`+ for spacing between major page sections. Utility classes `.p-xxs` … `.p-xxl` and `.gap-xs` … `.gap-xl` (for `HBox`/`VBox` spacing) are in `global.css`.

### 3.3 Radius scale

`none 0 · xs 4 · s 8 · m 12 · l 16 · full 999` (px) — `full` for pills and avatar-style circles.

### 3.4 Elevation

| Level | Effect | Use for |
|---|---|---|
| 0 | none | Default flat surfaces |
| 1 | soft, tight shadow | Cards at rest |
| 2 | medium shadow | Popovers, dropdown menus, hovered cards |
| 3 | strongest shadow | Modals, dialogs |

### 3.5 Motion

| Token | Duration | Use for |
|---|---|---|
| `short` | 150ms | Hover/pressed color changes |
| `medium` | 250ms | Focus rings, small reveals |
| `long` | 350ms | Panel/drawer open-close |

Easing curves (standard, decelerate, accelerate — the well-known Material-style cubic-béziers) are listed in `global.css` as comments for use with `javafx.animation.Interpolator` / `Timeline`, since JavaFX CSS transitions are limited to a handful of properties (`-fx-opacity`, colors on some controls) — most real interaction motion is done with `Transition`/`Timeline` classes in Java, not CSS.

### 3.6 Typography scale

Deliberately **smaller** than what you'd expect from the web version. Web marketing type looks huge because it fills a wide viewport at arm's length; a desktop app window is denser and read up close, so the scale below is compressed accordingly — and it matches the platform convention (JavaFX's own default stylesheet, Modena, uses a 13px base, not the 16px web default).

| Class | Size | Weight |
|---|---|---|
| `.heading-display` | 42px | 800 |
| `.heading-xxl` | 34px | 800 |
| `.heading-xl` | 28px | 800 |
| `.heading-l` | 24px | 700 |
| `.heading-m` | 21px | 700 |
| `.heading-s` | 18px | 700 |
| `.heading-xs` | 16px | 700 |
| `.heading-xxs` | 14px | 700 |
| `.eyebrow-l` / `-m` / `-s` | 13 / 12 / 11px | 800, uppercase |
| `.body-xl` | 16px | 400 (base UI text) |
| `.body-l` | 14px | 400 |
| `.body-m` | 13px | 400 — **default root size** |
| `.body-s` | 12px | 400 |
| `.body-xs` | 11px | 400 |

Each also has a `-bold`, `-italic`, and `-link` variant, mirroring the source system's pattern — see `global.css`.

If this app is closer to a marketing/landing surface than a data tool, scale everything up by roughly 20–30% — the ratios will still hold.

---

## 4. Fonts in JavaFX — the part that actually blocks you

Three separate problems, don't conflate them:

1. **Format.** JavaFX's `Font.loadFont()` only reads `.ttf` and `.otf`. It cannot read `.woff` or `.woff2` at all — those are web-only compressed wrappers. The files from the zip (`BLKFort-*.woff2`) will silently fail to load.
2. **Registration.** There's no `@font-face`. You load each weight/style as its own file, once, at startup, before any `Scene` is shown — this registers the family name with the font system so later CSS `-fx-font-family` references resolve.
3. **Licensing.** Separate from both of the above: most commercial and custom-commissioned fonts are licensed for *web embedding* specifically, and app/desktop embedding is often a different (sometimes additional-cost) license term. This applies regardless of whether the font in question is proprietary to a specific company — check the license or ask whoever manages the type agreement before shipping any real font binary inside a distributed desktop build.

### Converting woff2 → ttf (once you have the right to use the font here)

```bash
pip install fonttools brotli
python3 - <<'PY'
from fontTools.ttLib import TTFont
font = TTFont("YourFont-Bold.woff2")
font.flavor = None
font.save("YourFont-Bold.ttf")
PY
```

Do this for each weight/style you need. If you don't have the original desktop-format files and can't reliably convert, ask the design/brand team for the source `.ttf`/`.otf` kit directly — foundries almost always deliver both.

### Loading fonts at startup

```java
public final class Fonts {
    private Fonts() {}

    public static void load() {
        load("/fonts/BrandSans-Regular.ttf");
        load("/fonts/BrandSans-Bold.ttf");
        load("/fonts/BrandSans-ExtraBold.ttf");
    }

    private static void load(String resourcePath) {
        try (InputStream is = Fonts.class.getResourceAsStream(resourcePath)) {
            if (is == null || Font.loadFont(is, 12) == null) {
                System.err.println("Font failed to load: " + resourcePath);
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Could not load " + resourcePath, e);
        }
    }
}
```

Call `Fonts.load()` once in `Application.init()`, before `start()` builds any UI. The `12` passed to `loadFont` is irrelevant to how the font later renders — actual sizes come from `-fx-font-size` in CSS; `loadFont` just needs *a* size to construct a default `Font` object.

Until you have real files, `global.css` points `-font-family-base` at a placeholder (`"Inter"`, commonly preinstalled or easy to bundle) so the app renders correctly today. Swap the token once your `.ttf` files exist.

---

## 5. Component guide

Each entry: what it's for, which JavaFX control it's built from, and the class name(s) in `global.css`.

| Component | JavaFX control | Classes |
|---|---|---|
| Buttons | `Button` | `.button` (primary, filled dark), `.button-accent`, `.button-secondary` (outlined), `.button-tertiary` (text/link-style). Sizes: `.button-sm`, `.button-lg` |
| Text input | `TextField`, `PasswordField`, `TextArea` | `.text-field` / `.text-area`; add `.error` for validation state; pair with `.field-label`, `.field-help-text`, `.field-error-text` |
| Checkbox / Radio | `CheckBox`, `RadioButton` | Styled via internal `.box`/`.radio` sub-regions — see comments in `global.css`; no extra class needed on the control itself |
| Dropdown | `ComboBox` | `.combo-box`; popup list rows styled via `.combo-box-popup .list-cell` |
| Card / panel | any `Region` (usually `VBox`/`StackPane`) | `.card` (bordered + shadow), `.card-flat` (tinted, no shadow) |
| Sidebar nav | `VBox` of `Label`/`Button` items | `.sidebar` (container), `.sidebar-item`, `.sidebar-item-selected` |
| Top bar | `HBox` | `.top-bar` |
| Tabs | `TabPane` / `Tab` | native `.tab-pane`, `.tab`; selected/hover state rules included |
| Modal / dialog | `Dialog`, `Alert` | native `.dialog-pane` and its sub-regions (`.header-panel`, `.button-bar`) |
| Notification / banner | `HBox` | `.banner` + one of `.banner-info` / `-success` / `-warning` / `-error` |
| Table | `TableView` | native `.table-view`, `.column-header`, `.table-row-cell` (odd/hover/selected states included) |
| Pagination | custom `HBox` of buttons, or `Pagination` control | `.pagination` rules for the built-in control |
| Badge / tag | `Label` | `.badge` + `-success` / `-warning` / `-error` / `-neutral` |
| Tooltip | `Tooltip` | native `.tooltip` |
| Progress | `ProgressBar` | native `.progress-bar` |
| Divider | thin `Region` | `.divider` |
| Split layout | `SplitPane` | for the web system's two-pane "split layout" pattern — style dividers, leave pane sizing to Java |

### Notes on specific controls

- **Buttons:** `min-width: 88px` is intentional (matches common design-system convention so short labels like "OK" don't look cramped) — override per-instance with `-fx-min-width` if a compact icon-only button is needed.
- **Focus rings:** every interactive class defines a `:focused` state with a 2px accent-colored border. Don't remove focus indication for mouse-only aesthetics — keyboard and accessibility-tooling users need it (see §7).
- **Disabled state:** always pair a background/border change with `-fx-opacity` staying at `1` and `-fx-cursor: default` — JavaFX's default disabled treatment (a faint auto-applied gray-out) can double up with a manual one and look muddy; the rules in `global.css` set colors explicitly rather than relying on the automatic effect.

---

## 6. Applying the stylesheet

```java
@Override
public void start(Stage stage) {
    Fonts.load(); // must happen before building/showing the scene

    Parent root = ...;
    Scene scene = new Scene(root, 1280, 800);
    scene.getStylesheets().add(
        Objects.requireNonNull(getClass().getResource("/css/global.css")).toExternalForm()
    );
    stage.setScene(scene);
    stage.show();
}
```

Project layout convention:
```
src/main/resources/
  css/global.css
  fonts/BrandSans-Regular.ttf
  fonts/BrandSans-Bold.ttf
  fonts/BrandSans-ExtraBold.ttf
```

---

## 7. Accessibility checklist

- Text-on-background pairs should hit **4.5:1** contrast minimum (body text) and **3:1** (large text, 18px+/bold 14px+) — check `-color-text-subtle` against whatever background it actually sits on, not just against white.
- Never remove the `:focused` outline; keyboard navigation depends on it.
- Hit targets (buttons, checkboxes, list rows) should be at least ~32px tall — mouse users on desktop are more forgiving than touch, but consistency still matters.
- Don't encode meaning in color alone — pair `-color-error`/`-color-success` with an icon or label text ("Failed" / "Complete"), not just a red/green swatch, for colorblind users.

---

## 8. Customizing this system

To make this genuinely yours (or to restore the real brand once you've confirmed you have the rights to):

1. Replace the eight color values under `.root` in `global.css` — everything else derives from them.
2. Replace `-font-family-base` / `-font-family-display` once real `.ttf`/`.otf` files are loaded (§4).
3. Adjust the typography scale in §3.6 if the app skews more marketing-surface than data-tool.
4. Everything else — spacing, radius, elevation, motion, component structure — is intentionally generic and shouldn't need to change per brand.

# InvoiceStudio — Worklog

Project: Bill Design & Printing tool (Next.js 16 + TypeScript + Tailwind + shadcn/ui, JSON file storage in `/db`).

---

Task ID: 1
Agent: Z.ai Code (main)
Task: Full initial build of InvoiceStudio — bill template designer, dynamic variables, bill creation, industry-standard printing, history, dashboard. Confirmed plan with user first; user requested simple JSON file DB (no Prisma).

Work Log:
- Explored scaffold (Next.js 16 App Router, Tailwind 4, shadcn/ui New York, bun).
- Built core libs under `src/lib/studio/`:
  - `types.ts` — Template/TemplateElement/PageConfig/Bill/BillItem/BillTotals/Settings/VariableDef, PAGE_SIZES (mm).
  - `jsondb.ts` — JSON file store with per-file write locks + atomic tmp/rename writes.
  - `store.ts` — collections (templates/bills/variables/settings) with lazy first-run seeding.
  - `defaults.ts` — built-in bill variables, variable groups, DEFAULT_ITEM_COLUMNS, DEFAULT_SETTINGS (Indian GST business profile), `createDefaultTemplate()` — professional A4 "GST Tax Invoice — Classic" seed with 47 elements (header, logo, buyer/invoice boxes, items table, CGST/SGST totals block, amount-in-words, bank, terms, signature, page footer).
  - `format.ts` — en-IN money/number formatting, Indian amount-in-words (lakh/crore + paise), `computeTotals` (discount, CGST/SGST/IGST, round-off, grand total), bill-no helper.
  - `render.ts` — buildContext (business/bank/computed/bill variables; unknown placeholders resolve to blank), `itemCellValue` incl. custom item columns.
- API routes (all `force-dynamic`): templates CRUD, variables CRUD (key validation, built-in protection), bills CRUD + `POST /api/bills/[id]/print` (print counter) + `GET /api/bills/export` (CSV, BOM, date filters), settings GET/PUT. Bill POST auto-advances `billNoNext`.
- Shared render engine: `ElementRenderer.tsx` (design/final modes for text/image/table/line/rect/pageno; variable chips highlighted in design mode), `BillPreview.tsx` (mm-accurate page, screen scale or print size), `useFitScale.ts` (callback-ref fit hook; width or width+height fit), `PrintManager.tsx` (portal `#print-root`, dynamic `@page size`, multi-copy labels Original/Duplicate/Triplicate, afterprint → increments print count).
- Designer (`TemplateDesigner.tsx` + `DesignerCanvas.tsx` + `PropertiesPanel.tsx` + `LayersPanel.tsx`): pointer-based drag & 8-handle resize in mm, 5mm grid + snap (Alt bypass), margin guides, zoom, undo/redo (50 steps), keyboard (arrows nudge, Del, Ctrl+D/Z/Y), page setup popover (A4/A5/Letter/Legal/Custom, orientation, margins), element insert (Text/Logo/Items/Box/Line/Page#), properties (position, content + variable picker with groups, typography, appearance, table column editor with per-column label/key/width/align, header colors, row height, borders, zebra), layers (hide/lock/z-order/delete), image upload, template rename + save.
- Views: `DashboardView` (KPIs, 6-month revenue bars, top buyers, recent bills), `TemplatesView` + `TemplateThumb` (fit thumbnails, create/duplicate/delete), `CreateBillView` (auto form from built-in + custom variables, buyer autofill from past bills, items editor with custom columns, live totals + words, sticky actions, live preview pane), `HistoryView` (search + date filters, totals bar, view dialog with preview & print, edit/duplicate/delete, CSV export), `VariablesView` (built-in + custom CRUD), `SettingsView` (business profile, logo upload with client-side compression, bank, currency, IGST toggle, bill-no prefix/next).
- Shell `StudioApp.tsx`: fixed app layout (h-screen, internal scroll), dark charcoal + amber "BlackRock-style" theme, nav, footer (mt-auto within app frame), loading skeletons; `page.tsx` renders it.
- Print CSS in `globals.css` (#print-root portal show/hide, page breaks, exact colors, scrollbar styling, hidden number spinners).
- QA fixes found via agent-browser: missing useState import (DesignerCanvas), PAGE_SIZES import path, duplicate uid import (TemplatesView), JSX `{{business_logo}}` expression crash (SettingsView), raw `{{var}}` leaking into prints (resolve now blanks unknown keys), preview scroll-away (app-shell now fixed-height), thumbnail cropping (TemplateThumb with height-fit), clipped number inputs (spinner CSS + suffix removal).
- Verified APIs via curl (CSV export row, print count increment, settings PUT) and full UI golden path via agent-browser: create bill INV-0001 (Acme Industries, 2 items, ₹42,550.80, words correct), saved to db/bills.json, history view/edit/duplicate/delete present, custom variable `{{delivery_date}}` added and surfaced in bill form, mobile 390px layout OK. Fresh browser session: 0 console errors. `bun run lint` clean.

Stage Summary:
- App is feature-complete for v1 and verified end-to-end. Data lives in `/db/*.json` (atomic writes). Default template + settings auto-seed on first run.
- Key decisions: JSON-file DB per user request (no Prisma); mm-based layout with pt typography for print accuracy; portal-based print root with dynamic @page; single-route SPA with view state (sandbox constraint).
- Screenshots saved as qa-01…qa-24 during verification.

Current project status:
- Stable. All views functional, zero runtime errors on fresh load, lint clean.

Unresolved / next-phase recommendations (priority):
1. Multi-page item overflow (paginate table rows across pages when items exceed page height).
2. Direct `{{business_logo}}` variable support in text/image elements.
3. Duplicate bill should offer "next number" instead of `-C` suffix.
4. Element rotation + inline text editing on canvas (dblclick).
5. Backup/restore UI (download/upload `db/*.json` zip) and PDF export button (via browser print-to-PDF guidance).
6. Buyer master (saved buyers list) instead of only autofill.

---
Task ID: 2
Agent: Z.ai Code (cron review round 1)
Task: Status assessment + QA via agent-browser, then bug fixes + next feature batch (multi-page printing, buyer master, duplicate-number fix, business logo, styling polish).

Work Log:
- Reviewed worklog Task 1; ran fresh-session QA: 0 console errors, dashboard/templates/history healthy (one "blank page" scare was the browser sitting on about:blank — not an app bug).
- [Bug] jsondb.ts: concurrent writes to the same JSON file could generate identical tmp filenames (pid + same millisecond) → rename ENOENT → GET /api/buyers 500 → app stuck on skeleton. Fixed with random tmp suffix; verified buyers API now 200.
- [Bug] StudioApp.loadAll: single failed fetch bricked the UI on the skeleton forever. Now validates response status, retries up to 2× (700 ms apart), and renders an error state with a Retry button.
- [Feature] Multi-page pagination engine (`paginateTemplate` in render.ts): page 1 takes rows until the first element below the table; continuation pages fill down to the bottom margin; last page re-adds below-table elements (totals, signature, terms). New `repeatOnPages` element flag (properties panel toggle "Repeat on every page") re-renders letterhead/footer elements on every page. BillPreview renders stacked pages (screen gap) or `.print-page` breaks (print); PrintManager wraps copies in `.print-copy`. Table grows to fit its slice (TABLE_HEADER_MM + rows×rowHeight). Seeded template migrated: header zone + footer repeat automatically. Added `{{page_count}}` variable; `{{page_no}}` now "x of y" in pageno elements. Verified: 22-item bill → page 1 = 13 rows + totals, page 2 = repeated letterhead/TAX INVOICE band + rows 14–22 + totals + signature; footer shows "Page 1/2".
- [Feature] Buyer master: `db/buyers.json` + `/api/buyers` (GET, POST upsert-by-name) + `/api/buyers/[id]` (PUT, DELETE). Create Bill: "Saved buyer" dropdown (name + GST), fills all buyer fields; "Save buyer to the buyer list" checkbox auto-upserts on save. Verified: INV-0001's buyer auto-saved; picking from list fills name/GST/phone.
- [Feature] `{{business_logo}}`: Settings logo now available as a variable; image elements have "Use business logo (from Settings)" toggle — renders business logo when no own src. Verified with a test logo in live preview; test data cleaned after.
- [Fix] Duplicate bill now prefills the NEXT bill number (INV-0003) instead of "INV-0001-C".
- [Styling] Gold gradient accent line under the header; view-switch enter animation (studio-view keyframes); KPI + template-card hover lift with shadow; History table sticky thead with gold hairline; notes textarea compact + buyer-save checkbox row.
- Re-verified after all changes: `bun run lint` clean; fresh browser session 0 errors; dashboard reflects 2 bills / ₹1,18,519.70; screenshots qa-30…qa-38.

Stage Summary:
- Multi-page printing (industry-standard continuation invoices) is now the headline capability, plus buyer master and several robustness fixes.
- Data files now: templates.json, bills.json, buyers.json, variables.json, settings.json (all atomic writes).

Unresolved / next-phase recommendations (priority):
1. Rotation for elements (branding stamps/watermarks) + inline canvas text editing (double-click).
2. Backup/restore UI (download/upload the /db JSONs) + "Save as PDF" helper hint near Print.
3. Item-level discount % and per-item description wrapping toggle.
4. Buyer management page (list/edit/delete) — API exists, UI still implicit via Create Bill.
5. Dashboard: export monthly GST summary report (CSV/PDF), taxable-value analytics.
6. Print margin/offset calibration setting (for pre-printed letterhead stock).

---
Task ID: 3
Agent: Z.ai Code (cron review round 2)
Task: Status assessment + QA via agent-browser; repair broken build left by interrupted session; finish that session's feature set; add payment-status tracking + GST reporting; styling polish.

Work Log:
- Assessment: dev server was returning 500 — `BuyersView.tsx` (created by the interrupted previous round, never logged) had a mismatched JSX tag (`<AlertDialogTitle>…</AlertDialogHeader>`). Fixed tag; `api/settings/route.ts` PUT was missing new `printOffsetX/Y` fields (types already had them) — added with safe number coercion.
- [Lint] DesignerCanvas inline-editor used setState-in-effect; refactored into a keyed `InlineEditor` subcomponent (remounts per edit session, draft initialises from state) — no effect needed.
- [Data cleanup] `db/templates.json` had 2 leftover QA elements from round-2 testing (stray items table mid-page + stray image). Removed; template is back to the 47-element seed. Verified via API.
- Browser QA of recovered features: inline dblclick text editing (edit → Enter commit → Ctrl+Z undo verified on canvas), element rotation (Rotate spinner → `rotate(15deg)` transform + selection frame), Buyers page (stats/search/edit/delete), Settings print calibration + Backup/Restore + Data storage panels — all render and function.
- Verified per-item discount math live: 100×12.5 disc 10% GST 18% → subtotal 1250, discount 125, taxable 1125, CGST/SGST 101.25 each, words "One Thousand Three Hundred Twenty Seven Rupees and Fifty Paise Only". Bill INV-0003 saved + persisted.
- [Bug] CreateBillView double-save: after POST the form stayed in create mode, so a second Save duplicated the bill. Now tracks `savedId` → subsequent saves PUT-update the same bill; added "Start next bill" reset button + "Saved — further changes will update this bill" hint chip.
- [Feature] Payment status tracking: `BillStatus` (unpaid/paid/cancelled) + `paidAt` on Bill; legacy bills default unpaid. POST /api/bills persists status; CSV export gained Status column. History: clickable status badge (toggles paid↔unpaid via PUT), status filter dropdown, collected/outstanding chips in toolbar, view-dialog "Mark paid" / "Cancel bill" buttons. Dashboard: KPI row now Outstanding (amber) + Collected (green, with this-month sub), all revenue stats exclude cancelled bills.
- [Feature] GST reporting: new `GET /api/reports/gst` month-wise summary CSV (bills, subtotal, discount, taxable, CGST/SGST/IGST, round-off, grand total + TOTAL row; cancelled excluded) + dashboard "Reports (CSV)" card exposing it alongside the bill-wise export (which was previously computed but unreachable from the UI). GST & Taxable Value analytics panel (8 stat tiles) added.
- [Feature] CreateBillView: Payment select (Unpaid/Paid/Cancelled) in the sticky action bar; saved with the bill.
- [Styling] Status badges (amber/emerald/red pills with dots), accent-outlined Outstanding & Collected KPI cards, GST stat tiles, PDF-export tip line in history preview dialog, "Clear filters" button, toast messages on status change.
- QA: mark-paid flow verified live (badge flips, toast, collected ₹77,296.40 / outstanding ₹42,550.80 update instantly + persist to bills.json); status filter (Paid → 2 bills, correct totals); GST summary CSV curl-verified (month row + TOTAL row); settings PUT regression (partial body keeps offsets/currency); mobile 390px — dashboard KPI stack + CreateBill action bar wrap correctly; fresh session 0 console errors; `bun run lint` + `tsc --noEmit` clean. Screenshots qa-r4-01…qa-r4-20.

Stage Summary:
- Recovered from a broken intermediate state and shipped the full payments/reporting layer. App remains single-route SPA; data still pure JSON in /db (bills now carry `status`/`paidAt`).
- Bill lifecycle: unpaid → paid (click badge or dialog button), or cancelled (excluded from all revenue/GST/collection stats).

Unresolved / next-phase recommendations (priority):
1. Watermark/stamp element type (PAID stamp auto-overlay on paid bills when printing).
2. Print margin calibration test page + per-template offset override.
3. Payment history ledger per buyer (partial payments, UPI reference field on Mark-paid).
4. Multi-user-ish polish: bill-level lock/edit protection after printing N copies? (currently free edit).
5. Designer: snap guides (alignment lines) + multi-select; A5/half-sheet template presets gallery.
6. Recurring bills (duplicate with date rollover) & Proforma/Quotation document types.

---
Task ID: 4
Agent: Z.ai Code (cron review round 3)
Task: Status assessment + agent-browser QA; feature batch: PAID/CANCELLED print stamp, designer snap guides, payment ledger (partial payments + reference), document types (Invoice/Proforma/Quotation), template presets gallery, styling polish.

Work Log:
- Assessment: dev server healthy (HTTP 200), all 7 views render, 0 console errors on fresh session. Note: db holds 2 bills (INV-0003 from round-2 QA had been deleted during round-3 cleanup); an initial "3 bills" sighting was a stale pre-round-3 browser tab, not data loss. Verdict: stable phase → proceeded to feature batch.
- [Feature] Status stamp: BillPreview renders a rotated double-border rubber stamp (green PAID / red CANCELLED, sized relative to page width, print-color-adjust exact) on every page when the bill has that status and showStatusStamp is set. Wired into PrintManager (respects new `statusStamp` setting), HistoryView preview dialog, and CreateBillView live preview. Settings → Print Calibration gained a "Status stamp on print" switch (default ON); `Settings.statusStamp` persisted via settings PUT (partial-body merge verified by curl).
- [Feature] Payments ledger: `BillPayment {id,date,amount,method,reference}` on Bill; helpers `paidAmount()`/`dueAmount()` (legacy bills fall back to full-total convention). New "Record payment" dialog in History (amount/date/method UPI-Cash-Cheque-…/reference) — partial payments keep the bill UNPAID with "₹x paid" annotation under Balance; auto-flips to PAID when total received ≥ grand total. Status badge click opens the dialog (paid → click marks unpaid). View dialog gained a payment ledger panel + "Record more"/"Mark unpaid" actions. Balance column (amber due / green ₹0) + HandCoins quick action added to the history table.
- [Feature] Buyer ledger: BuyersView cards gained "Open ledger" → dialog with Billed/Received/Outstanding tiles, per-doc table (type chip, status, total, balance) and a receipts timeline (date · method · reference · billNo · amount), matched by buyer name across history.
- [Feature] Doc types: `Bill.docType` (invoice default; helper `docTypeOf`). Create Bill has a Document type select; `{{doc_type}}` renders TAX INVOICE / PROFORMA INVOICE / QUOTATION live; payment select shows "n/a" for proforma/quotation. New context vars: `paid_amount`, `due_amount`, `payment_status`. History: doc-type filter + INV/PI/QT chips. Business rules enforced: revenue, GST analytics, top buyers, collections, and /api/reports/gst now use TAX INVOICES only (cancelled excluded); bills CSV export gained Doc Type / Paid / Due / Payments columns. Dashboard "Total bills" sub shows invoice vs proforma/quote split; recent-bills rows show doc chips.
- [Feature] Template presets: `buildPresetTemplate(key)` in defaults.ts — Classic (existing seed), Modern (charcoal header + gold rule, right column invoice details), Compact GST (A5 docket), Minimal (hairline borderless) — all with repeatOnPages marks via markSeedRepeats. TemplatesView "New template" now opens a preset gallery with stylised CSS mock cards + "start blank" option; verified end-to-end by creating the Modern preset (40 elements, designer opened, saved clean).
- [Feature] Designer snap guides: while dragging (move or resize), element edges/centres align to other elements' edges/centres + page edges/centre within a ~6px screen threshold; glowing coral guide lines render at the snap target; Alt bypasses; guides clear on release. Verified live: dragged {{doc_type}} → X locked exactly to 110 (Invoice-No left edge) + bottom edge to 41mm, guide lines captured in screenshot, Ctrl+Z restored (140,5) exactly, 0 console errors.
- [Styling] History view-dialog header rebuilt (doc chip + mono bill no + truncated buyer + status chip, actions shrink-0 — no more ugly wrapping); Collected KPI card gained an emerald collection progress bar; active nav item gets a gold gradient underline; preset cards with hover lift + accent dot; buyer ledger tiles/receipts styling.
- QA: partial-payment flow live-tested (₹500 → UNPAID ₹892 balance, collected total +500; final ₹892 → PAID + stamp), QA bill deleted after test (buyers list untouched). bills CSV + GST summary CSV re-verified via curl (new columns, invoice-only totals). Settings PUT partial merge regression-checked. Mobile 390px history layout OK. `bun run lint` clean, `tsc --noEmit` clean for src/. Screenshots qa-r5-01…qa-r5-26.

Stage Summary:
- App now covers the full quote-to-cash mini-cycle: Quotation/Proforma → Tax Invoice → partial/full payments with references → PAID-stamped prints → buyer statements. Still pure JSON storage in /db (bills gained optional `payments`/`docType`; settings gained `statusStamp` — all backward compatible).
- Preset gallery gives 4 ready designs + blank; designer gains alignment snap guides.

Unresolved / next-phase recommendations (priority):
1. Multi-select + group move/align tools in designer; rotate handle visual polish.
2. Payment edit/delete (receipts are append-only today); payment receipt PDF/print template.
3. Convert Quotation→Invoice one-click (carry items/buyer, new number series).
4. Per-template print-offset override (Settings offset is global today); calibration test page.
5. Dashboard month picker (currently fixed to current month for "this month" KPIs).
6. A5/thermal (80mm) preset needs its own pagination cap check if receipt-style bills are wanted.

---
Task ID: 5
Agent: Z.ai Code (cron review round 4)
Task: Status assessment + agent-browser QA; repair the broken interrupted round-6 session (multi-select props), then feature batch: history bulk actions, printer calibration sheet, designer shortcuts overlay; fix a concurrent-write race found during bulk testing.

Work Log:
- Assessment: found the round-6 session had been interrupted mid-work — qa-r6-* screenshots existed but no worklog entry. Code audit showed convert-to-invoice, month picker, payment edit/delete, receipts all landed; the ONLY casualty was PropertiesPanel: TemplateDesigner passed `multiCount`/`onAlign`/`onDistribute` props it didn't accept → tsc failure. Implemented all three: new Props + a polished gold multi-select banner ("N elements selected", Shift+click hint, 6 align buttons, 2 distribute buttons with 3+ gating and helper text) shown above the normal panel when multi-selecting.
- Browser-verified the multi-select flow via dispatched shift+clicks: 2 elements selected → banner renders; align-top works; added a 3rd → distribute-H spreads lefts to even 157px gaps; Ctrl+Z×2 restored exact original positions (verified element coords via API after exiting without save).
- [Bug] React "unique key" warning from convert flow: API-created bills carried items without `id` (and wrong field names like `description`). Fixed at two levels: (1) new `src/lib/studio/sanitize.ts` — sanitizeItem/sanitizeItems/sanitizePayment(s) coerce any input into well-formed BillItem/BillPayment (id generation, desc←description fallback, numeric coercion, gst/discPct clamping, custom-column preservation, method validation); (2) CreateBillView normalizeItems() defensively fixes legacy bills on load; row keys fall back to index.
- [Data integrity] POST /api/bills now recomputes totals server-side from sanitized items (computeTotals + interState from settings) and auto-generates amountInWords when missing. PUT recomputes totals whenever items/discountPct change (partial bodies like status toggles untouched). Verified live: malformed POST (string qty/rate, `description` field, no totals) → stored bill with proper ids, correct totals (100+18%→1280) and words.
- [Bug — race condition] Bulk "Mark paid" lost one of two concurrent updates: PUT handlers did listBills→mutate→saveBills outside the write lock (TOCTOU; last-write-wins). Added `mutateBills`/`mutateBuyers`/`mutateTemplates` to store.ts using the existing jsondb updateJson per-file read-modify-write lock, and converted ALL bill/ buyer/ template mutation routes (POST, PUT, DELETE, print-count) to them. Re-tested with truly concurrent curl PUTs — both updates persist.
- [Feature] History bulk actions: checkbox column + header select-all (indeterminate state), rows tint gold when selected; floating "studio-rise" bulk bar (sticky bottom, gold-bordered, blur) shows "N selected · ₹total" with contextual buttons: Mark paid (n) for unpaid invoices, Mark unpaid (n) for paid/cancelled, Export n (CSV via new `ids=` filter on /api/bills/export), Delete (AlertDialog lists first 8 bill numbers), and clear-X. Quotations/proforma correctly excluded from status actions. Verified: bulk select → mark paid (API persisted both), mark unpaid, bulk delete (confirm dialog → gone from db + UI), ids-CSV returns exactly the selected bills. Mobile 390px: bar wraps to two rows cleanly.
- [Feature] Printer calibration sheet: new CalibrationSheet.tsx — full A4 print artifact with 10mm reference grid (heavier 50mm lines), mm rulers with labels, corner crop marks, 100×50mm test box, centre crosshair, 150mm stepped span, and an info block printing the business name + current applied offsets; content shifted by printOffsetX/Y exactly like real bills (all geometry in explicit mm strings). PrintManager gained a `calibrateJob` (A4 @page, no side effects); Settings → Print Calibration gained a gold "Calibration sheet" card with "Print test sheet" button. Verified via agent-browser `pdf` print-media render: rulers/box/offsets all present in the PDF text layer.
- [Feature] Designer keyboard shortcuts overlay: toolbar keyboard icon (or `?` key) opens a themed dialog — 12 shortcuts in a two-column kbd/description grid (select, shift-click add, dblclick edit, drag/Alt-bypass, arrows 1mm, shift-arrows 5mm, Ctrl+D, Del, undo/redo, Escape) with a multi-select tip footer. Verified button + `?` toggle.
- Styling: gold multi-select banner + hover states on align/distribute buttons; bulk bar (emerald/amber/red action buttons, mono bill list in confirm); calibration card gradient; selection row tint; studio-rise keyframes added to globals.css.
- Cleanup: QA bills QA-NORM-1, QA-BULK-1/2 removed after testing; QT-0001 (quotation, Gamma Constructions) kept intentionally to demo doc-type flows.
- Final state: `bun run lint` clean; tsc clean for src/; fresh browser session 0 console errors; dashboard healthy (4 bills: 3 invoices + 1 quotation, outstanding/collected correct); all recent API requests 200. Screenshots qa-r7-01…qa-r7-13.

Stage Summary:
- App recovered from the interrupted session and is stable; multi-select + align/distribute tools are now fully wired and verified.
- New: history bulk operations (status/delete/export), printer calibration sheet, designer shortcuts help. API layer hardened (input sanitization + server-side totals + race-free mutations).
- Recommended next phase: per-template print-offset override; thermal 80mm receipt preset with pagination caps; recurring bills (date rollover); Quotation→Proforma conversions maybe; PDF export via print-to-PDF remains the guidance.

Unresolved / risks:
- jsondb locks are in-process only (single Node server) — fine for this single-user tool.
- Headless afterprint doesn't fire, so print-root cleanup can't be observed in CI-like runs (works in real browsers; printCount increments verified in earlier rounds).
- Old db/bills.json rows created before sanitization may lack item ids until next edit (CreateBillView now normalizes on load, PUT re-sanitizes on save).

---
Task ID: 6
Agent: Z.ai Code (cron review round 5)
Task: Status assessment + agent-browser QA (stable phase confirmed) → feature batch: UPI QR-code element, Thermal 80mm continuous receipts, recurring monthly invoices, per-template print-offset override; two data-integrity bug fixes; styling polish.

Work Log:
- Assessment: fresh session 0 page errors, all 7 views render, lint clean, tsc clean for src/, all API 200s. Data note: an interrupted earlier round had converted QT-0001→INV-0005 and marked INV-0002/INV-0004 paid (legacy paid-full convention) — data consistent, no corruption.
- [Bug] Blank entry rows were saved as real items (INV-0006 initially had a 3rd empty item polluting receipts/tables). Fixed in sanitize.ts: isEmptyItem() drops rows with no desc/hsn/qty/rate/amount (unit deliberately ignored — the items editor prefills "PCS"). Verified via API: POST with an empty row → stored with 1 item; INV-0006/0007 re-sanitized to 2 items each, totals unchanged.
- [Bug] Clearing a per-template print offset in the designer sent `undefined`, which JSON.stringify drops → old value persisted. Fixed both sides: designer now sends explicit null; PUT /api/templates/[id] treats null as "clear" (→ undefined = use global), partial bodies keep existing values. Round-trip verified by curl (clear→set X=2→partial keeps→clear).
- [Feature] QR code element (designer "QR" insert button): qrSource = "UPI pay + amount (per bill)" (upi://pay?pa=<business UPI>&pn=<name>&am=<grand total>&cu=INR&tn=<bill no>) | "UPI pay (no amount)" | "Custom text/link" with {{variable}} support; properties panel section (source select, payload textarea + variable picker, QR color, min-size hint); renders synchronously via qrcode.react SVG in design mode (demo payload) and final mode (real bill data); prints exactly (SVG + print-color-adjust). Layers panel shows "QR — UPI + amount / UPI / custom".
- [Feature] Thermal 80mm continuous receipts: new page size "Thermal 80" + page.autoHeight flag ("Continuous roll (auto height)" switch in page setup); print engine emits `@page { size: 80mm auto }` (verified in injected style + PDF capture); BillPreview renders one content-driven page; rollTableShift() pushes/pulls every element below the items table by the table's real row-count delta (grows AND shrinks — no overlap at any item count); designer canvas height follows content. New preset "Thermal POS Receipt (80mm)" (23 elements: centered header, inv/buyer lines, compact 5-col table, subtotal/tax, big TOTAL, amount-in-words, 22mm UPI QR, scan-to-pay line, thank-you footer) + gallery mock card. Seed layout error (totals inside reserved table area) caught in QA and redesigned (table reserves 4 sample rows, totals at y=68.5).
- [Feature] Recurring invoices: Bill.repeat ('none'|'monthly') persisted by POST/PUT; Create Bill action-bar "Monthly" toggle (invoices only, gold when active); History row "Repeat next month" action + gold "M↻" chip (tooltip shows next occurrence); Dashboard "Recurring Invoices" gold panel — due cards (buyer, bill no → due date, amount, "Create next") when nextRepeatDate ≤ today, otherwise "N flagged · nothing due yet"; StudioApp.repeatBillFn opens a prefilled draft: next bill number, date rolled +1 month (clamped month-end, overdue → today), unpaid, receipts cleared, repeat kept. Verified live: repeat INV-0001 → INV-0007 dated 07 Oct; back-dated QA bill → panel showed "Create next" → prefilled INV-0008 (today-clamped, Monthly on); QA bill deleted after test.
- [Feature] Per-template print offset: Template.printOffsetX/Y override Settings globally (PrintManager prefers template value); designer page-setup popover has "Print offset (mm)" X/Y with global placeholders + "Empty = use global" hint; Settings calibration card now mentions the override.
- [Styling] Create Bill preview caption now reads "Continuous 80mm roll — content ≈ Nmm at X items" for rolls; recurring panel (gold gradient border + cards); monthly chip styling; QR properties section themed like the rest.
- QA: thermal print flow verified end-to-end (Print clicked → @page 80mm auto injected → PDF capture shows perfect continuous receipt with QR, items, totals, words, footer); GST report buckets the Oct-dated recurring invoice into 2026-10 correctly; CSV/buyers/backup regressions clean; mobile 390px dashboard + Create Bill action bar wrap correctly; bun run lint + tsc (src/) clean; fresh session 0 console errors, 0 server errors this round. Screenshots qa-r9-01…qa-r9-18 + qa-r9-13 thermal print PDF.
- Final state: 6 bills (4 invoices + 2 recurring-flagged... precisely: INV-0001/02/04/05 + INV-0006 thermal + INV-0007 monthly), 3 templates (Classic A4, Modern A4, Thermal 80mm roll), 3 buyers, 1 custom var.

Stage Summary:
- App now covers thermal/POS receipts with scan-to-pay UPI QR (killer feature for Indian counter billing), recurring monthly invoicing with a dashboard nag + one-click roll, and printer-alignment overrides per template.
- Data files unchanged in shape; bills gained optional `repeat`, templates gained optional `printOffsetX/Y` + `page.autoHeight` — all backward compatible with existing JSON.

Unresolved / next-phase recommendations (priority):
1. Thermal: allow hiding zero-value summary rows (e.g. skip Subtotal when 0) via a per-element "hide when blank" flag.
2. Recurring: support weekly/yearly cadences + auto-create (background job) instead of manual "Create next".
3. QR: QR for payment *receipts* (PaymentReceipt could embed UPI deep link of receipt no); barcode (CODE128) element for transport/e-way copies.
4. Designer: multi-element roll-shift preview (designer shows authored positions; a "preview with N rows" toggle would close the designer/preview gap for thermal layouts).
5. Duplicate-bill flow could offer "keep same number, new copy label" for transport-office workflows.
6. Email/WhatsApp share of a printed PDF remains manual (print-to-PDF guidance) — a proper export-to-PDF button would need a server-side renderer.

---
Task ID: 7
Agent: Z.ai Code (cron review round 7)
Task: Status assessment + agent-browser QA (stable phase confirmed) → feature batch: per-element "hide when blank", CODE128 barcode element, designer roll-preview (N-row simulation), recurring weekly/monthly/yearly cadences, WhatsApp share, Thermal 58mm; styling polish.

Work Log:
- Assessment: found the dev server DOWN on port 3000 at session start (sandbox had reaped it; background `nohup` processes are killed between tool calls). `(setsid bun run dev &)` subshell detach keeps it alive — server restored, all APIs 200. Fresh browser QA: all 7 views render, 0 console errors, lint + tsc clean → stable phase, proceeded to features.
- [Feature] Per-element "Hide when blank": new `TemplateElement.hideWhenBlank` flag (properties panel toggle for text/image/qrcode/barcode, sky-blue when on). Final-mode only: text hides when EVERY placeholder resolves blank or ₹0 (literal-only text never auto-hides — a plain "Subtotal" label is safe); image hides without src; QR/barcode hide with empty payload. Existing thermal template updated: Vehicle line flagged → disappears on bills without `vehicle_no` (verified on INV-0006 preview), still visible in the designer. Thermal preset now ships `Subtotal  {{subtotal}}` as a single hide-when-blank row for new templates.
- [Feature] CODE128 barcode element: `jsbarcode` dep; designer toolbar "Barcode" insert; renders crisp SVG stretched to the element box with the human-readable value under the bars (`barcodeShowText` toggle, ink color picker); `barcodeData` supports {{variables}} (defaults to {{invoice_no}}); non-ASCII stripped automatically; properties section + layers label; added to the thermal preset bottom (invoice-no barcode). Verified live: designer demo render + real "INV-0006" bars on a saved bill preview.
- [Feature] Designer roll preview: toolbar "Rows" popover on continuous-roll templates — simulate 1/2/3/5/8/12/18 item rows; every element below the table shifts by the real row delta (reuses rollTableShift) and the canvas page height follows (verified 132→151mm @ 8 rows with caption "Content height ≈ 151mm"). Display-only (positions never saved); "Off" returns to authored layout.
- [Feature] Recurring cadences: `Bill.repeat` now 'weekly' | 'monthly' | 'yearly' (+ 'none'); addDaysISO/addYearsISO helpers, cadence-aware nextRepeatDate/repeatDue, REPEAT_META. Create Bill action bar: gold One-off/Weekly/Monthly/Yearly select (replaces the old Monthly toggle). History: per-cadence W/M/Y chip + "Repeat next week/month/year" action title. Dashboard recurring panel now counts any cadence ("2 flagged"), cards show a cadence label chip; "Create next" rolls the date by one cadence step (month-end clamped, overdue → today). API POST/PUT validate the new values.
- [Feature] WhatsApp share: row action (MessageCircle, emerald) on every history row + "WhatsApp" outline button in the view dialog. Builds a wa.me deep link: business name, doc type + bill no, date, buyer, amount, balance due + status, scannable `upi://pay?…` link with the invoice amount (reuses buildContext/buildQrPayload), thank-you note; buyer phone auto-prefixed with 91 when 10 digits. Verified capture: `https://wa.me/919876543210?text=*SHREE TRADERS*…` with correct UPI payload.
- [Feature] Thermal 58mm page size (compact POS rolls): PAGE_SIZES entry, page-size dropdown option, auto-continuous roll like Thermal 80; Create Bill preview caption now says the real roll width.
- [Styling] Sky-blue active states for preview/hide-when-blank toggles, emerald WhatsApp accents, gold cadence chips + hover rings on dashboard recurring cards, CODE128 section themed like QR's, generic roll-width caption.
- QA: designer flows (barcode insert/props/save via API: 24 elements, barcode @(20,130), hideWhenBlank persisted), thermal bill preview (barcode + hidden vehicle line), WhatsApp URL capture, weekly↔none cadence via API + dashboard "2 flagged", mobile 390px history + dashboard, all-7-view sweep with 0 console errors, CSV/GST/backup/templates/buyers APIs 200, `bun run lint` + tsc clean. INV-0002 cadence restored to none after testing. Screenshots qa-r10-01…qa-r10-19.

Stage Summary:
- Printing engine now covers variable content gracefully (hide-when-blank), machine-readable codes end-to-end (CODE128 alongside UPI QR), 58mm + 80mm rolls with a designer-level N-row simulation, and cadence-aware recurring invoicing.
- WhatsApp share closes the loop from "print" to "send" — bill summary + UPI pay link in one tap, matching Indian counter-billing workflows.
- Data files unchanged in shape; bills/templates gained optional fields only (backward compatible). jsbarcode added as the sole new dependency.

Unresolved / risks:
- Roll preview shifts elements for display only — dragging while a preview row-count is active edits authored (unshifted) coordinates; hint text tells users to turn it Off to edit.
- effectivePageHeight still counts elements that hideWhenBlank will suppress at print time, so roll length can slightly overestimate when trailing elements are blank (never clips — safe direction).
- WhatsApp share assumes Indian local numbers (auto +91); numbers already carrying a country code pass through untouched.
- Dialog a11y warnings ("Missing Description / aria-describedby") remain from shadcn dialogs — cosmetic, pre-existing.

Next-phase recommendations (priority):
1. Auto-create recurring bills via a daily cron/scheduled job (cadences are in place; needs a trigger surface).
2. Thermal 58 preset in the gallery (page size already supported; needs a 58mm layout seed).
3. Payment receipt document: embed a receipt-no barcode/QR + WhatsApp share of receipts.
4. Server-side PDF export button (headless Chromium) — print-to-PDF guidance works today but a real export button removes the manual step.
5. Designer: element "preview mode" bar for fixed-size templates (simulate N rows across continuation pages).
6. Duplicate-bill flow with "keep same number, new copy label" for transport-office workflows.

---
Task ID: 8
Agent: Z.ai Code (cron review round 11)
Task: Status assessment + agent-browser QA (stable phase confirmed) → feature batch: auto-create recurring invoices (lazy daily sweep), Delivery Challan + Credit Note doc types, Thermal 58mm preset, payment-receipt UPI QR + WhatsApp share of receipts; dashboard trend chips + empty states; one robustness fix (orphan-template preview).

Work Log:
- Assessment: dev server healthy, all 7 views render, 0 console errors, lint + tsc (src/) clean → stable phase, proceeded to features.
- [Feature] Auto-create recurring invoices: new `src/lib/studio/recurring.ts` — lazy daily sweep (runRecurringSweep) that rolls every due recurring invoice forward (next bill no, cadence-stepped date clamped overdue→today, same buyer/items, server-recomputed totals + words, fresh unpaid, cadence preserved; SOURCE bill's repeat flag cleared under the bills write lock so each chain keeps exactly one open occurrence). `db/meta.json` lastSweepDate marker = at most one auto-run per day; Settings switch `autoRecurring` (default OFF) gates it. New POST /api/recurring/sweep ({force:true} for manual runs). StudioApp fires the sweep once per session after first load and toasts what was created. Settings → Billing Preferences gained a gold "Auto-create recurring invoices" switch; Dashboard recurring panel gained an ON/OFF status pill + "Enable auto-create"/"Pause" toggle button. Verified via API: back-dated monthly INV-0008 (07 Aug) → forced sweep created INV-0009 dated exactly 07 Sept (due date), source flag cleared, counter advanced to 10, meta marker written; non-force respects off/day-marker; 2nd forced sweep idempotent (0 created). Dashboard Pause toggle live-tested (settings persisted, badge flipped). QA bills deleted + counter restored to 8 + switch back OFF after testing.
- [Feature] Delivery Challan + Credit Note doc types: DocType union extended; DOC_TYPE_TITLE ("DELIVERY CHALLAN"/"CREDIT NOTE") + DOC_TYPE_META (teal DC / rose CN chips); repeatDue now invoice-only; bills POST accepts new types; History doc filter + Create Bill select gained both; convert-to-invoice available for them; revenue/GST/collections/reporting untouched (invoice-scoped filters already exclude them — GST CSV re-verified: DC/CN not counted). Dashboard "other docs" wording. Note: challan/credit notes keep Unpaid/Paid badge "—" (no payment lifecycle), Balance shows "—".
- [Feature] Thermal Mini Receipt (58mm) preset: 24-element seed for 58mm rolls (compact fonts 4.8–9.5pt, 4-col table #/Item/Qty/Amt, {{doc_type}} line, hide-when-blank GSTIN/phone/vehicle/scan-pay rows, 18mm UPI QR, invoice barcode); PresetKey/TEMPLATE_PRESETS/gallery mock card added; verified end-to-end: created from gallery (24 elements saved, Thermal 58 58×132 autoHeight), Create Bill live preview renders with caption "Continuous 58mm roll — content ≈ 119mm at 1 item", 2×250→₹590 totals correct. Template kept in db as demo (4 templates total).
- [Feature] Receipt upgrades: PaymentReceipt embeds a QRCodeSVG QR — UPI pay link for the REMAINING BALANCE (label "PAY BALANCE") when due > 0, else a scannable receipt-verification text ("Verified"); helper text explains scanning. History payment-ledger rows gained a WhatsApp share button → receiptWhatsAppUrl() deep link (receipt no, date, buyer, amount + method + ref, invoice, balance/settled, buyer phone +91 prefix). Verified: wa.me capture for INV-0009 receipt (₹600 UPI, balance ₹580), receipt print PDF capture shows the QR + caption.
- [Bug] View dialog rendered a BLANK body for bills whose template was deleted (templateId dangling — the delete-template flow explicitly allows this). Added a graceful "Preview unavailable" fallback panel with the doc's grand total/items + guidance (Convert/Duplicate). Verified with an orphaned CN bill.
- [Styling] Revenue KPI card now shows a month-over-month trend chip (▲/▼ % MoM, emerald/red, capped display ">999%", tooltip = prev-month figure); chart bars dim to 40% opacity when zero + hover brightness; auto-create badge whitespace-nowrap (mobile); History: redesigned empty states — "No bills yet" (icon + CTA "Create your first bill", new onNewBill prop) vs "No bills match your filters" (Clear all filters button); footer version bumped to v1.1.
- [Data note] Mid-session, INV-0001/0002/0004 flipped paid→unpaid at 11:03–11:05 while this agent was editing code — traced to the PREVIOUS cron round's browser session still running its payment QA (PUTs at dev.log lines 237–303, before this round's API tests). Concurrent-session interference, not an app bug. Data restored to the r10 end-state (0001/0002/0004 paid; 0001/0004 keep payment receipts). Recommendation: cron rounds should close their agent-browser session (`agent-browser close`) before finishing.
- QA: sweep flow (API + UI toggle), challan/credit-note chips+filter+preview+fallback, 58mm designer + bill preview, receipt QR PDF, WhatsApp receipt URL capture, no-matches empty state + clear, mobile 390px recurring panel (badge nowrap), fresh desktop session 0 console errors, `bun run lint` + tsc clean. Final data: 6 bills (INV-0001/0002/0004 paid, 0005/0006/0007 unpaid, INV-0007 monthly-flagged), 4 templates, 3 buyers, 1 custom var, settings autoRecurring=false counter=8. Screenshots qa-r11-01…qa-r11-20 + qa-r11-13-receipt.pdf.

Stage Summary:
- Recurring invoicing is now hands-free: opt-in once, and each day's first app-open issues the next copies automatically (chain-safe, once-per-day, transparent toasts + dashboard status).
- Document coverage now matches Indian accounting reality: Tax Invoice / Proforma / Quotation / Delivery Challan / Credit Note.
- 58mm rolls give pocket-POS printers a purpose-built template; receipts close the loop with pay-balance QR + WhatsApp confirmation.

Unresolved / risks:
- The sweep runs on app-open (lazy cron) — if the app isn't opened on a day, that day's rolls happen the next time it opens (by design; overdue→today clamp keeps dates sane).
- Concurrent browser sessions (two agents/users) can race UI-level quick actions (see data note); server writes are lock-protected so no corruption occurred, but sessions should not overlap QA.
- Roll length still overestimates when trailing elements are hidden via hideWhenBlank (safe direction, pre-existing).
- Dialog a11y warnings (missing aria-describedby) remain — cosmetic, pre-existing.

Next-phase recommendations (priority):
1. Server-side PDF export button (headless Chromium) — print-to-PDF guidance works today; a real "Download PDF" removes the manual step.
2. Credit notes with negative amounts / linkage to the source invoice (adjustment tracking).
3. Recurring: per-cadence end dates ("until 31 Mar") + skip-next-occurrence action.
4. Designer: A4 N-row pagination preview (extend the roll "Rows" simulation to fixed-size templates).
5. WhatsApp: attach the PDF itself (needs #1) instead of text-only deep link.
6. Buyer statement PDF export from the buyer ledger (billed/received/receipts).
---
Task ID: 9
Agent: Z.ai Code (cron review round 12)
Task: Status assessment + agent-browser QA (stable phase confirmed) → feature batch: server-side PDF export ("Download PDF" buttons everywhere via headless Chromium), recurring end dates + one-shot skip-next, credit-note ↔ invoice linkage, buyer statement PDF export; dialog a11y fixes + styling details.

Work Log:
- Assessment: dev server healthy, all 7 views render, 0 console errors, lint + tsc (src/) clean, data matches r11 end-state → stable phase, proceeded to the r11 recommendation list.
- [Feature] Server-side PDF export — POST /api/pdf (route.tsx) with three kinds:
  - `bill`: re-renders the designed document server-side via renderToStaticMarkup(BillPreview…) — exact @page size (fixed templates) or measured content height (continuous rolls), multi-copy (.print-copy breaks), per-template print offsets, PAID/CANCELLED stamp support, multipage table pagination — pixel-faithful to the live preview (verified INV-0005 A4 + INV-0007 thermal 80mm).
  - `receipt`: A5 PaymentReceipt PDF with UPI pay-balance / verification QR.
  - `statement`: buyer account statement (A4) — business header, summary tiles (billed/received/credit notes/outstanding), outstanding-by-age buckets (not due/1-30/31-60/61-90/90+), full transaction table (CN totals in rose negative), receipts ledger, period filters from/to.
  - Engine `src/lib/studio/pdfEngine.ts`: playwright-core + the sandbox's cached Chromium (auto-highest revision under ~/.cache/ms-playwright, env CHROME_PATH override), warm singleton browser, print-color-adjust exact, fonts.ready wait.
  - Two infra tricks this needed: (1) Next.js forbids 'react-dom/server' imports in App Router code — solved with a Turbopack resolveAlias `react-dom/server-static` → next/dist/compiled/react-dom/server.node.js (same vendored React copy; declared in src/types/react-dom-server-static.d.ts). (2) qrcode.react uses hooks → new isomorphic `src/lib/studio/qrsvg.ts` (qrcode.create() matrix → inline SVG) and `src/lib/studio/code128.ts` (CODE128-B encoder → stretched inline SVG, viewBox+preserveAspectRatio=none).
  - BillPreview/ElementRenderer/PaymentReceipt are now hook-free shared modules (no 'use client') so BOTH the client and the PDF route invoke them directly. BarcodeSvg was unified on the isomorphic encoder (jsbarcode import dropped) — as a bonus barcodes now genuinely stretch to fill their element box on screen, print and PDF alike (previously JsBarcode wrote fixed width/height attrs, no viewBox).
  - UI: HistoryView row "PDF" action (FileDown, sky) + view-dialog "PDF" button (honours the copies selector) + per-receipt PDF in the payment ledger; CreateBillView "PDF" action-bar button (after save); BuyersView ledger "Statement PDF" button. All via client helper `downloadPdf()` with error toasts + busy pulse states. UI downloads verified by capture: INV-0006 bill PDF + Acme statement PDF saved from real button clicks.
- [Feature] Recurring end dates + skip-next-occurrence: Bill.repeatEndDate (chain stops after it) + Bill.repeatSkipNext (consume-once: cadence rolls forward, no copy). Sweep rewritten around a patch-map — creates rolls, applies skips (rolls source date forward), and clears chains whose next occurrence passed the end date (ended[] + skipped[] returned by /api/recurring/sweep; StudioApp toasts each case). UI: "Repeat until" date input inside the cadence pill (Create Bill), Skip/Undo-skip row action + recurrence banner with skip state in the view dialog, dashboard cards show "until" date + "next occurrence will be skipped", history chip turns sky when skip armed / struck-through when chain ended. API-verified end-to-end: skip consumed when due (created=0, date rolled), end date carried onto rolled copies, chain past end date auto-clears (ended=['TEST-END']). Data fully restored after tests (6 bills, counter=8, autoRecurring off).
- [Feature] Credit-note linkage: docType=creditnote now shows a rose "Against Invoice" section (reference-invoice picker over all invoices + reason input) storing `ref_invoice_no` / `credit_reason` bill variables — flow into templates as {{ref_invoice_no}}/{{credit_reason}} (added to the designer's Bill variable group). View dialog shows a rose "against INV-xxxx" chip. Revenue/GST scoping untouched (CN still excluded — dashboard shows "1 other docs" correctly).
- [Bug/style] Dialog a11y: every Dialog now carries a DialogDescription (visually sr-only where the design has no subtitle) — the pre-existing "Missing Description / aria-describedby" console warnings are gone (0 errors, 0 warnings on a full view sweep + dialog open/close).
- [Style] Footer bumped to v1.2; PDF buttons themed sky-blue outline with pulsing busy state; recurrence banner gold panel; credit-note section rose-tinted panel; skip chip states (gold=armed, sky=skip, struck grey=ended).
- QA: PDF kinds bill/receipt/statement all verified visually (₹ glyph, QR + CODE128 render correctly in headless output; roll content height now measured in-browser so nothing spills to page 2); skip/end-date sweep flows API-tested then cleaned up; CN linkage end-to-end (create → chip in view dialog → delete); Statement PDF via real UI click; CSV + GST report regressions 200; mobile 390px dashboard fine; `bun run lint` + tsc (src/) clean; browser session closed at end of round (r10's recommendation).

Stage Summary:
- The print engine's last manual step is gone: one click exports a pixel-faithful PDF (any template, thermal rolls included) — ready for WhatsApp/e-mail attachments or a PDF-capable POS printer.
- Recurring chains are now fully controllable (end date, skip once) and self-cleaning (expired chains clear themselves during the daily sweep).
- Credit notes are first-class: linked to the invoice they adjust, with template variables for the reference and reason.
- Buyer statements (with aging) complete the receivables story: bill → share → receipt → statement.

Unresolved / risks:
- `/api/pdf` renders with a warm Chromium singleton — first export after a cold server pays ~1s browser start; subsequent exports are fast. Memory stays resident (~100MB) by design.
- PDF export requires the bill's template to still exist (409 with a clear message otherwise) — matches the preview behaviour.
- Statement groups by exact buyer-name match (same as the ledger UI); renamed buyers split their history.
- Receipt PDF page height uses 209.6mm content in a 210mm page to avoid Chromium rounding spill — visually identical.
- Roll bill PDFs still estimate from authored layout when the first measure pass races fonts (never observed in QA; measurement happens after fonts.ready).

Next-phase recommendations (priority):
1. WhatsApp: attach the exported PDF itself (share the /api/pdf URL or upload flow) instead of text-only deep link.
2. Credit notes with negative line amounts (currently credit value = entered items total; a true negative-total flow needs totals math changes).
3. Recurring: per-cadence "create next N occurrences ahead" (generate a quarter at once).
4. Designer: A4 N-row pagination preview (extend the roll "Rows" simulation to fixed-size templates).
5. PDF export for the GST report / dashboard month (single-click archive copies).
6. Settings: default PDF stamp toggle & export filename pattern.
---
Task ID: 10
Agent: Z.ai Code (main session — user feature request)
Task: Bulk buyer upload via CSV with a downloadable sample file (user request), plus CSV export for a full round trip.

Work Log:
- [Feature] Shared CSV toolkit `src/lib/studio/csv.ts` — RFC4180 parser (quoted fields, "" escapes, commas/newlines inside quotes, BOM strip, CRLF), serializer (csvCell/csvRow), buyer header-alias mapper (name/buyer name/party/customer, gstin, mobile, billing address, place of supply…), GSTIN format validator, Indian-mobile validator. Isomorphic (client + server safe).
- [API] POST /api/buyers/import — server-authoritative validation (name required, ≤120 chars, GSTIN format), modes: 'skip' (existing buyers untouched) | 'update' (non-empty CSV fields overwrite saved details, blanks never clobber); in-file duplicate names collapse last-wins; rows processed under the mutateBuyers lock; 1,000-row cap (413); returns {created, updated, skipped, failed, errors[{row,name,reason}]}.
- [API] GET /api/buyers/sample — downloadable buyers-sample.csv: canonical header + 5 realistic Indian demo rows, last row shows optional fields left blank; UTF-8 BOM so Excel opens it cleanly.
- [API] GET /api/buyers/export — all buyers in the exact import format (name,address,gst,phone,state), A-Z, multi-line addresses correctly quoted → export → edit in Excel → import round trip verified.
- [UI] BuyersView: gold "Import CSV" toolbar button + neutral "Export" button (disabled when list empty) + "Import CSV" CTA in the empty state. Three-step import wizard dialog (sm:max-w-3xl):
  1. Pick — file-format guide card (column list, quoting hint, alias note), "Download sample CSV" button, keyboard-accessible drag-&-drop zone (gold highlight on dragover) + hidden file input, parse errors surfaced inline (too large >2MB, no rows, >1000 rows, unreadable file).
  2. Review — file chip + row counters (N ready / warnings / errors / already-saved), amber note banner (unrecognised columns ignored / missing name column), skip-vs-update ModeCard radio pair + "N rows match saved buyers" hint, scrollable preview table (sticky header; per-row spreadsheet line number, SAVED badge, color-coded ok/warn/error rows with reasons on hover; errors excluded from import with an explanatory footnote).
  3. Done — Created/Updated/Skipped/Failed result tiles, server-side "Row problems" list, skipped-buyers guidance ("re-import in Update mode to refresh"), success line; toast summary; "Import another file" loop + Done.
- [Fix found during QA] shadcn Dialog base carries sm:max-w-lg which silently overrode an unprefixed max-w-3xl — fixed by using sm:max-w-3xl (tailwind-merge now dedupes correctly); review table fits fully with no column clipping.
- QA (agent-browser): pick-step render, real file upload through the unhidden input, header-alias mapping with scrambled column order (Buyer Name,GSTIN,Mobile,Billing Address,State parsed perfectly), SAVED badge on existing rows, duplicate-pair warnings both directions, invalid-GSTIN error row, bad-phone warning row, live import → Created 3 / Skipped 1 tiles + toast, buyers grid refreshed to 6 then restored; done-step + mobile 390px screenshots fine; API tests for skip & update merge semantics (blank CSV fields never overwrite saved data — verified Beta Engineers); sample/export endpoints byte-checked; 0 console errors; lint + tsc clean. Test buyers removed after QA (list back to Acme/Beta/Gamma). Screenshots qa-import-01…06.

Stage Summary:
- Buyers master now scales from 3 to 3,000: one drag-&-drop imports a whole customer list with server-validated preview, skip/update control and a per-row audit — plus a sample file for non-technical users and an export button that makes the Excel round trip lossless.
- No schema changes; buyers.json shape untouched. No new dependencies (hand-rolled CSV parser).

Unresolved / risks:
- Import matches buyers strictly by (case-insensitive) exact name — renamed buyers create a new entry, consistent with ledger/stats grouping.
- GSTIN validation is format-only (no checksum/pAN-lookup); a structurally-valid but wrong GSTIN passes — flagged as a deliberate trade-off to avoid blocking real-world data.
- The Failed tile counts server-side rejections only; preview-detected bad rows are pre-filtered client-side, so it usually reads 0 with the review step showing the real errors.

Next-phase recommendations (priority):
1. Buyer-ledger drill-down: click a row in the statement PDF? (skip) — better: "New bill for this buyer" shortcut on buyer cards.
2. Import preview virtualisation for the full 1,000-row cap (currently renders all rows; fine to ~2-3k DOM nodes but worth noting).
3. Item (product) master + CSV import, mirroring this pattern for repeat line items.
4. WhatsApp buyer-level blast: statement PDF + outstanding reminder to all buyers with dues (opt-in per buyer).
5. Auto-import watcher: drop buyers.csv into /db to import on next app open (low priority; dialog flow already frictionless).

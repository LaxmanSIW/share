import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  turbopack: {
    resolveAlias: {
      // Server-side PDF export renders React trees to HTML strings.
      // Next blocks 'react-dom/server' imports in App Router code, so the
      // PDF engine imports this alias which resolves to Next's vendored
      // react-dom server build — the same React copy the app renders with.
      "react-dom/server-static": "./node_modules/next/dist/compiled/react-dom/server.node.js",
    },
  },
};

export default nextConfig;

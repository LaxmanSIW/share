/* ============================================================
 * InvoiceStudio — shared domain types
 * ============================================================ */

export type ElementType = 'text' | 'image' | 'table' | 'line' | 'rect' | 'pageno' | 'qrcode' | 'barcode';

export type Align = 'left' | 'center' | 'right';
export type VAlign = 'top' | 'middle' | 'bottom';

export interface TableColumn {
  key: string;
  label: string;
  width: number; // percentage of table width (0-100)
  align: Align;
}

export interface TemplateElement {
  id: string;
  type: ElementType;
  /** position & size in millimetres, relative to page top-left */
  x: number;
  y: number;
  w: number;
  h: number;
  zIndex: number;
  locked?: boolean;
  hidden?: boolean;
  /** render this element again on every continuation page (headers/footers) */
  repeatOnPages?: boolean;
  /** rotation in degrees (-180..180), around the element centre */
  rotation?: number;
  /** skip this element at print/preview time when its content resolves blank (or ₹0) —
   *  e.g. hide Subtotal when zero, or the Vehicle line when no vehicle was entered */
  hideWhenBlank?: boolean;

  /* ---- text ---- */
  text?: string; // may contain {{variable}} placeholders
  fontFamily?: string;
  fontSize?: number; // pt
  fontWeight?: number;
  italic?: boolean;
  underline?: boolean;
  uppercase?: boolean;
  color?: string;
  align?: Align;
  vAlign?: VAlign;
  lineHeight?: number;
  letterSpacing?: number; // pt

  /* ---- appearance ---- */
  bg?: string;
  borderWidth?: number; // mm
  borderColor?: string;
  borderRadius?: number; // mm
  padding?: number; // mm
  opacity?: number; // 0-1

  /* ---- image ---- */
  src?: string; // data URL
  objectFit?: 'contain' | 'cover' | 'fill';
  /** when true and src is empty, render the business logo from Settings */
  useBusinessLogo?: boolean;

  /* ---- qrcode ---- */
  /** what the QR encodes: UPI intent with amount, UPI without amount, or custom text */
  qrSource?: 'upi_amount' | 'upi' | 'custom';
  /** custom payload — supports {{variables}} (e.g. a payment link or tracking code) */
  qrCustom?: string;
  /** QR modules color (dark) */
  qrColor?: string;

  /* ---- barcode (CODE128) ---- */
  /** payload — supports {{variables}} (defaults to the invoice number) */
  barcodeData?: string;
  /** bar ink color */
  barcodeColor?: string;
  /** print the human-readable value under the bars */
  barcodeShowText?: boolean;

  /* ---- line ---- */
  direction?: 'h' | 'v';

  /* ---- table ---- */
  columns?: TableColumn[];
  headerBg?: string;
  headerColor?: string;
  rowHeight?: number; // mm per body row
  borderStyle?: 'grid' | 'rows' | 'none';
  showZebra?: boolean;
}

export type PageSizeName = 'A4' | 'A5' | 'Letter' | 'Legal' | 'Thermal 80' | 'Thermal 58' | 'Custom';

export interface PageConfig {
  sizeName: PageSizeName;
  width: number; // mm
  height: number; // mm (used as the design height for rolls; printing flows continuously)
  orientation: 'portrait' | 'landscape';
  margin: { top: number; right: number; bottom: number; left: number }; // mm
  /** continuous receipt roll — printed height follows the content (thermal printers) */
  autoHeight?: boolean;
}

export interface Template {
  id: string;
  name: string;
  page: PageConfig;
  elements: TemplateElement[];
  /** per-template print shift in mm — overrides Settings for pre-printed stock */
  printOffsetX?: number;
  printOffsetY?: number;
  createdAt: string;
  updatedAt: string;
}

export interface VariableDef {
  key: string;
  label: string;
  type: 'text' | 'number' | 'date';
  builtin?: boolean;
}

export interface Buyer {
  id: string;
  name: string;
  address: string;
  gst: string;
  phone: string;
  state: string;
  /** user-defined extra fields (keys come from Settings.buyerFields) */
  custom?: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

/** a buyer-specific field defined by the user in Settings → Buyer custom fields.
 *  values live on each Buyer.custom[key]; they flow into bills as {{buyer_<key>}} variables. */
export interface BuyerFieldDef {
  key: string; // stable slug — never changes after creation (values are keyed by it)
  label: string;
  type: 'text' | 'number' | 'date';
}

export interface ItemRecord {
  id: string;
  name: string;
  hsn: string;
  unit: string;
  rate: number;
  gst: number;
  createdAt: string;
  updatedAt: string;
}

export interface BillItem {
  id: string;
  desc: string;
  hsn: string;
  qty: number;
  unit: string;
  rate: number;
  gst: number; // percent
  /** per-item discount percent (0-100) */
  discPct?: number;
  /** allows template-defined custom item columns */
  [key: string]: string | number | undefined;
}

export interface BillTotals {
  subtotal: number;
  discount: number; // amount
  taxable: number;
  cgst: number;
  sgst: number;
  igst: number;
  roundOff: number;
  grandTotal: number;
  totalQty: number;
  itemCount: number;
}

export type BillStatus = 'unpaid' | 'paid' | 'cancelled';

export type DocType = 'invoice' | 'proforma' | 'quotation' | 'challan' | 'creditnote';

/** document types that represent real sales (revenue / GST reporting) */
export const REVENUE_DOC_TYPES: DocType[] = ['invoice'];

export type PaymentMethod = 'Cash' | 'UPI' | 'Bank Transfer' | 'Cheque' | 'Card' | 'Other';

export type RepeatCadence = 'none' | 'weekly' | 'monthly' | 'yearly';

export const REPEAT_CADENCES: RepeatCadence[] = ['none', 'weekly', 'monthly', 'yearly'];

/** a single payment receipt recorded against a bill (partial payments supported) */
export interface BillPayment {
  id: string;
  date: string; // yyyy-mm-dd
  amount: number;
  method: PaymentMethod;
  reference?: string; // UPI id / txn no / cheque no
  note?: string;
}

export interface Bill {
  id: string;
  billNo: string;
  date: string; // yyyy-mm-dd
  templateId: string;
  templateName: string;
  variables: Record<string, string>;
  items: BillItem[];
  discountPct: number;
  totals: BillTotals;
  amountInWords: string;
  notes: string;
  printCount: number;
  /** payment lifecycle — older bills without the field are treated as 'unpaid' */
  status?: BillStatus;
  /** ISO timestamp captured when the bill is marked paid */
  paidAt?: string;
  /** payment receipts (partial payments supported); older bills may have none */
  payments?: BillPayment[];
  /** document kind — older bills are invoices */
  docType?: DocType;
  /** recurring cadence — surfaces a "create next" action on the dashboard when due */
  repeat?: RepeatCadence;
  /** optional end date (yyyy-mm-dd) — the recurring chain stops creating copies after it */
  repeatEndDate?: string;
  /** when true the NEXT occurrence is skipped once (the cadence rolls one step forward instead) */
  repeatSkipNext?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface BusinessProfile {
  name: string;
  address: string;
  gstin: string;
  phone: string;
  email: string;
  state: string;
  stateCode: string;
  logo: string; // data URL
  bankName: string;
  accountNo: string;
  ifsc: string;
  upi: string;
  terms: string;
}

export interface CustomFontDef {
  id: string;
  name: string;
  family: string;
  source: 'google' | 'upload' | 'url';
  url?: string;
  fileUrl?: string;
  dataUrl?: string;
  format?: 'woff2' | 'woff' | 'truetype' | 'opentype';
  category?: 'sans' | 'serif' | 'mono' | 'display' | 'handwriting';
  weights?: number[];
  createdAt: string;
}

export interface Settings {
  business: BusinessProfile;
  currency: string;
  interState: boolean; // true -> IGST, false -> CGST+SGST
  billNoPrefix: string;
  billNoNext: number;
  /** print calibration shift in mm (for pre-printed letterhead stock) */
  printOffsetX: number;
  printOffsetY: number;
  /** overlay a PAID / CANCELLED rubber stamp when printing bills with that status */
  statusStamp: boolean;
  /** create due recurring invoices automatically when the app is opened each day */
  autoRecurring?: boolean;
  /** user-defined buyer fields — shown on buyer forms, bill variables and CSV import/export */
  buyerFields?: BuyerFieldDef[];
  /** user-installed custom fonts (uploaded or web fonts) */
  customFonts?: CustomFontDef[];
}

export const PAGE_SIZES: Record<Exclude<PageSizeName, 'Custom'>, [number, number]> = {
  A4: [210, 297],
  A5: [148, 210],
  Letter: [215.9, 279.4],
  Legal: [215.9, 355.6],
  'Thermal 80': [80, 240], // design height for the roll preview; print flows continuously
  'Thermal 58': [58, 180], // compact 58mm POS roll
};

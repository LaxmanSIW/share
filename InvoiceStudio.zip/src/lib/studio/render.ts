/* ============================================================
 * InvoiceStudio — variable resolution & render context
 * (client-safe)
 * ============================================================ */
import type { Bill, BillItem, Settings, Template, TemplateElement } from './types';
import { BUILTIN_BILL_VARS } from './defaults';
import { DOC_TYPE_TITLE, amountInWords, billStatus, dueAmount, fmtDate, fmtMoney, fmtNum, itemAmount, paidAmount } from './format';

export interface RenderContext {
  values: Record<string, string>;
  items: BillItem[];
  settings: Settings;
  pageNo: number;
  pageCount: number;
  copyLabel: string;
}

const COPY_LABELS = ['Original for Recipient', 'Duplicate for Transporter', 'Triplicate for Supplier'];

export function buildContext(
  bill: Bill | null,
  settings: Settings,
  copyIndex = 0,
  pageNo = 1,
  pageCount = 1,
): RenderContext {
  const b = settings.business;
  const values: Record<string, string> = {
    invoice_no: bill?.billNo ?? 'INV-0001',
    invoice_date: fmtDate(bill?.date ?? new Date().toISOString().slice(0, 10)),
    business_name: b.name,
    business_address: b.address,
    business_gst: b.gstin,
    business_phone: b.phone,
    business_email: b.email,
    business_state: b.state,
    business_logo: b.logo,
    terms: b.terms,
    bank_name: b.bankName,
    bank_account: b.accountNo,
    bank_ifsc: b.ifsc,
    bank_upi: b.upi,
    notes: bill?.notes ?? '',
    page_no: String(pageNo),
    page_count: String(pageCount),
    copy_label: COPY_LABELS[copyIndex % COPY_LABELS.length],
    doc_type: DOC_TYPE_TITLE[bill ? (bill.docType ?? 'invoice') : 'invoice'],
  };
  // bill variables override business defaults
  if (bill) {
    for (const [k, v] of Object.entries(bill.variables)) {
      if (v !== undefined && v !== null && v !== '') values[k] = String(v);
    }
  }
  // never print raw placeholders — unresolved bill vars become blank
  for (const v of BUILTIN_BILL_VARS) {
    if (!(v.key in values)) values[v.key] = '';
  }
  const t = bill?.totals;
  values.subtotal = t ? fmtNum(t.subtotal) : '1,14,000.00';
  values.discount = t ? fmtNum(t.discount) : '0.00';
  values.taxable = t ? fmtNum(t.taxable) : '1,14,000.00';
  values.cgst = t ? fmtNum(t.cgst) : '5,130.00';
  values.sgst = t ? fmtNum(t.sgst) : '5,130.00';
  values.igst = t ? fmtNum(t.igst) : '10,260.00';
  values.round_off = t ? fmtNum(t.roundOff) : '0.00';
  values.grand_total = t ? fmtMoney(t.grandTotal, settings.currency) : '₹1,24,260.00';
  values.amount_in_words = bill?.amountInWords || 'One Lakh Twenty Four Thousand Two Hundred Sixty Rupees Only';
  values.total_qty = t ? fmtNum(t.totalQty) : '100';
  values.item_count = t ? String(t.itemCount) : '3';
  if (bill) {
    values.paid_amount = fmtMoney(paidAmount(bill), settings.currency);
    values.due_amount = fmtMoney(dueAmount(bill), settings.currency);
    values.payment_status = billStatus(bill).toUpperCase();
  } else {
    values.paid_amount = '₹0.00';
    values.due_amount = '₹1,24,260.00';
    values.payment_status = 'UNPAID';
  }
  return { values, items: bill?.items ?? [], settings, pageNo, pageCount, copyLabel: values.copy_label };
}

/** Replace {{key}} placeholders with resolved values (unknown keys → blank). */
export function resolveText(text: string, values: Record<string, string>): string {
  return text.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_m, key: string) =>
    key in values ? values[key] : '',
  );
}

/**
 * True when a resolved text should count as "blank" for the hide-when-blank
 * flag: empty/whitespace, or a value that reduces to zero (₹0, 0.00, 0).
 */
export function isBlankValue(resolved: string): boolean {
  if (!resolved || resolved.trim() === '') return true;
  const numeric = resolved.replace(/[^0-9.-]/g, '');
  return numeric !== '' && Number(numeric) === 0;
}

/**
 * Hide-when-blank check for a whole text element:
 *  - no placeholders → only literal whitespace counts as blank
 *    (a plain label like "Subtotal" is never auto-hidden)
 *  - with placeholders → blank when EVERY placeholder resolves blank/zero
 *    (e.g. "Vehicle: {{vehicle_no}}" hides when no vehicle, "₹{{subtotal}}"
 *    hides when the subtotal is 0)
 */
export function isTextBlank(text: string, values: Record<string, string>): boolean {
  const parts = text.match(/\{\{\s*[a-zA-Z0-9_]+\s*\}\}/g);
  if (!parts) return text.trim() === '';
  return parts.every((p) => isBlankValue(resolveText(p, values)));
}

/* ---------------- QR code payload ---------------- */

const enc = encodeURIComponent;

/**
 * Build the string a barcode element encodes, from the render context.
 * CODE128 supports ASCII 0-127 — anything else is stripped.
 */
export function buildBarcodeValue(
  el: Pick<TemplateElement, 'barcodeData'>,
  ctx: RenderContext,
): string {
  const raw = resolveText(el.barcodeData?.trim() ? el.barcodeData : '{{invoice_no}}', ctx.values);
  return raw.replace(/[^\x20-\x7e]/g, '').trim();
}

/** Build the string a QR element encodes, from the render context. */
export function buildQrPayload(
  el: Pick<TemplateElement, 'qrSource' | 'qrCustom'>,
  ctx: RenderContext,
): string {
  const source = el.qrSource ?? 'upi_amount';
  if (source === 'custom') {
    return resolveText(el.qrCustom || '', ctx.values) || 'InvoiceStudio';
  }
  const upi = ctx.settings.business.upi?.trim();
  if (!upi) return '';
  const name = ctx.settings.business.name || '';
  if (source === 'upi') {
    return `upi://pay?pa=${enc(upi)}&pn=${enc(name)}&cu=INR`;
  }
  // upi_amount — scannable UPI intent prefilled with the invoice amount
  const amount = Number((ctx.values.grand_total || '0').replace(/[^0-9.]/g, '')) || 0;
  const note = ctx.values.invoice_no || '';
  return `upi://pay?pa=${enc(upi)}&pn=${enc(name)}&am=${amount.toFixed(2)}&cu=INR${note ? `&tn=${enc(note)}` : ''}`;
}

/* ---------------- page geometry ---------------- */

/**
 * Rendered height delta of the items table for a given row count.
 * On continuous-roll (thermal) templates every element below the table is
 * shifted by this delta — down when the bill has more rows than reserved,
 * up when it has fewer — so the receipt never overlaps itself.
 */
export function rollTableShift(template: Template, itemCount: number): number {
  if (!template.page.autoHeight) return 0;
  const table = template.elements.find((e) => e.type === 'table' && !e.hidden);
  if (!table) return 0;
  const actual = TABLE_HEADER_MM + Math.max(itemCount, 1) * (table.rowHeight ?? 7);
  return actual - (table.h ?? 0);
}

/** Content-driven page height for continuous-roll (thermal) templates. */
export function effectivePageHeight(template: Template, itemCount = 0): number {
  if (!template.page.autoHeight) return template.page.height;
  const bottom = template.elements
    .filter((e) => !e.hidden)
    .reduce<number>((max, e) => Math.max(max, (e.y ?? 0) + (e.h ?? 0)), 0);
  return Math.max(bottom + rollTableShift(template, itemCount) + template.page.margin.bottom, 40);
}

const KNOWN_ITEM_KEYS = new Set(['sr', 'desc', 'hsn', 'qty', 'unit', 'rate', 'disc', 'gst', 'amount']);

export function itemCellValue(item: BillItem, key: string, index: number): string {
  switch (key) {
    case 'sr':
      return String(index + 1);
    case 'desc':
      return String(item.desc ?? '');
    case 'hsn':
      return String(item.hsn ?? '');
    case 'qty':
      return fmtNum(Number(item.qty) || 0, 3);
    case 'unit':
      return String(item.unit ?? '');
    case 'rate':
      return fmtNum(Number(item.rate) || 0);
    case 'disc': {
      const d = Number(item.discPct) || 0;
      return d ? `${fmtNum(d, 2)}%` : '';
    }
    case 'gst':
      return item.gst ? `${fmtNum(Number(item.gst) || 0, 2)}%` : '';
    case 'amount':
      return fmtNum(itemAmount(item));
    default: {
      const custom = (item as Record<string, unknown>)[key];
      if (custom !== undefined && custom !== null && custom !== '') return String(custom);
      return '';
    }
  }
}

export { KNOWN_ITEM_KEYS };

/* ---------------- table pagination ----------------
 * Splits a template into pages when items overflow the table area:
 *  - page 1: all elements, table carries the first chunk of rows
 *  - middle pages: elements flagged `repeatOnPages` (letterhead/footers)
 *    + the table with the next chunk, filling down to the bottom margin
 *  - last page: repeat elements + below-table elements (totals, signature…)
 *    + remaining rows
 * ------------------------------------------------------ */

export interface TableSlice {
  start: number;
  end: number;
}

export interface PageSlice {
  pageNo: number;
  elements: TemplateElement[];
  tableSlice?: TableSlice;
}

export const TABLE_HEADER_MM = 6.2; // estimated column-header strip height

export function paginateTemplate(
  template: Template,
  itemCount: number,
): PageSlice[] {
  const sorted = [...template.elements]
    .filter((e) => !e.hidden)
    .sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0));
  const table = sorted.find((e) => e.type === 'table');

  // continuous roll (thermal): everything flows on a single auto-height page
  if (template.page.autoHeight) {
    return [{ pageNo: 1, elements: sorted, tableSlice: { start: 0, end: Math.max(itemCount, 0) } }];
  }

  if (!table || itemCount === 0) {
    return [{ pageNo: 1, elements: sorted, tableSlice: { start: 0, end: Math.max(itemCount, 0) } }];
  }

  // rows that fit on page 1: stop at the first element below the table (totals block etc.)
  const bottomLimit =
    sorted
      .filter((e) => e !== table && !e.repeatOnPages && (e.y ?? 0) > (table.y ?? 0) + 2)
      .reduce<number | null>((min, e) => (min === null ? e.y : Math.min(min, e.y)), null) ??
    template.page.height - template.page.margin.bottom;
  const cap1 = Math.max(
    1,
    Math.floor((Math.min(bottomLimit, template.page.height) - (table.y ?? 0) - TABLE_HEADER_MM) /
      Math.max(table.rowHeight ?? 7, 3)),
  );

  if (itemCount <= cap1) {
    return [{ pageNo: 1, elements: sorted, tableSlice: { start: 0, end: itemCount } }];
  }

  // continuation pages: table may run to the bottom margin
  const contBottom = template.page.height - template.page.margin.bottom;
  const capN = Math.max(
    1,
    Math.floor((contBottom - (table.y ?? 0) - TABLE_HEADER_MM) / Math.max(table.rowHeight ?? 7, 3)),
  );

  const repeatEls = sorted.filter((e) => e.repeatOnPages && e !== table);
  const afterEls = sorted.filter(
    (e) => e !== table && !e.repeatOnPages && (e.y ?? 0) > (table.y ?? 0) + 2,
  );

  const pages: PageSlice[] = [];
  let start = 0;
  let pageNo = 1;
  let cap = cap1;
  while (start < itemCount) {
    const end = Math.min(start + cap, itemCount);
    const isLast = end >= itemCount;
    const els: TemplateElement[] = pageNo === 1 ? sorted.filter((e) => e !== table) : [...repeatEls];
    if (isLast) {
      for (const e of afterEls) if (!els.includes(e)) els.push(e);
    }
    els.push({ ...table, id: `${table.id}__p${pageNo}` });
    els.sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0));
    pages.push({ pageNo, elements: els, tableSlice: { start, end } });
    start = end;
    pageNo += 1;
    cap = capN;
  }
  return pages;
}

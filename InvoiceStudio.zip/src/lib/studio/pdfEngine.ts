/* ============================================================
 * InvoiceStudio — server-side PDF engine (Node only)
 * Renders prepared HTML in headless Chromium (playwright-core,
 * reusing the sandbox's cached browser) and prints it to PDF.
 * A module-level singleton keeps one warm browser across jobs.
 * ============================================================ */
import fs from 'node:fs';
import type { ReactElement } from 'react';
// Bundler-resolved alias (next.config.ts) → node_modules/react-dom/server.node.js.
// Keeps ONE React copy between the rendered tree and the static renderer.
import { renderToStaticMarkup } from 'react-dom/server-static';
import { chromium, type Browser } from 'playwright-core';

const MM_PX = 3.7795275591; // px per mm @96dpi

/** Render a React tree to a static HTML string (server-only). */
export function renderStaticMarkup(node: ReactElement): string {
  return renderToStaticMarkup(node) as string;
}

let browserPromise: Promise<Browser> | null = null;

/** Locate a Chromium binary: env override -> Windows Edge/Chrome/Brave -> playwright cache -> Linux paths. */
function resolveChromiumPath(): string {
  const envPath = process.env.CHROME_PATH || process.env.CHROMIUM_PATH || process.env.PUPPETEER_EXECUTABLE_PATH;
  if (envPath && fs.existsSync(envPath)) {
    return envPath;
  }

  const candidates: string[] = [];

  // 1. Windows common browser paths (Edge is built-in on Windows 10/11)
  if (process.platform === 'win32') {
    const progFiles = process.env['ProgramFiles'] || 'C:\\Program Files';
    const progFilesX86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
    const localAppData = process.env['LOCALAPPDATA'] || '';

    candidates.push(
      `${progFilesX86}\\Microsoft\\Edge\\Application\\msedge.exe`,
      `${progFiles}\\Microsoft\\Edge\\Application\\msedge.exe`,
      `${localAppData}\\Microsoft\\Edge\\Application\\msedge.exe`,
      `${progFiles}\\Google\\Chrome\\Application\\chrome.exe`,
      `${progFilesX86}\\Google\\Chrome\\Application\\chrome.exe`,
      `${localAppData}\\Google\\Chrome\\Application\\chrome.exe`,
      `${progFiles}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`,
      `${progFilesX86}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`,
    );

    // Playwright cache on Windows
    const winPlaywrightCache = `${localAppData}\\ms-playwright`;
    try {
      if (fs.existsSync(winPlaywrightCache)) {
        for (const entry of fs.readdirSync(winPlaywrightCache)) {
          if (entry.startsWith('chromium_headless_shell-')) {
            candidates.push(`${winPlaywrightCache}\\${entry}\\chrome-headless-shell-win64\\chrome-headless-shell.exe`);
          } else if (entry.startsWith('chromium-')) {
            candidates.push(`${winPlaywrightCache}\\${entry}\\chrome-win64\\chrome.exe`);
            candidates.push(`${winPlaywrightCache}\\${entry}\\chrome-win\\chrome.exe`);
          }
        }
      }
    } catch { /* ignore */ }
  }

  // 2. macOS common browser paths
  if (process.platform === 'darwin') {
    candidates.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
    );
  }

  // 3. Linux / container Playwright cache & distribution binaries
  const home = process.env.HOME || '/home/z';
  const cacheDir = `${home}/.cache/ms-playwright`;
  try {
    if (fs.existsSync(cacheDir)) {
      for (const entry of fs.readdirSync(cacheDir)) {
        if (entry.startsWith('chromium_headless_shell-')) {
          candidates.push(`${cacheDir}/${entry}/chrome-headless-shell-linux64/chrome-headless-shell`);
        } else if (entry.startsWith('chromium-')) {
          candidates.push(`${cacheDir}/${entry}/chrome-linux64/chrome`);
        }
      }
    }
  } catch { /* no cache dir */ }

  candidates.push(
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/snap/bin/chromium',
  );

  for (const c of candidates) {
    if (c && fs.existsSync(c)) return c;
  }

  throw new Error('No Chromium executable found for PDF export. Please ensure Google Chrome, Microsoft Edge, or Chromium is installed.');
}

export async function getBrowser(): Promise<Browser> {
  if (!browserPromise) {
    browserPromise = chromium
      .launch({
        executablePath: resolveChromiumPath(),
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none', '--hide-scrollbars'],
      })
      .catch((err) => {
        browserPromise = null; // allow a retry on the next request
        throw err;
      });
  }
  return browserPromise;
}

import type { CustomFontDef } from './types';
import { generateFontCss, PRELOADED_GOOGLE_FONTS_HREF } from './fonts';

/** Wrap the prepared markup into a standalone print document. */
export function wrapPrintHtml(
  markup: string,
  opts: { pageCss: string; baseUrl?: string; customFonts?: CustomFontDef[] },
): string {
  const base = opts.baseUrl ? `<base href="${opts.baseUrl}">` : '';
  const customFontCss = generateFontCss(opts.customFonts);
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
${base}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${PRELOADED_GOOGLE_FONTS_HREF}">
<style>
  ${customFontCss}
  @page { margin: 0; ${opts.pageCss} }
  html, body {
    margin: 0 !important; padding: 0 !important;
    background: #ffffff !important;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  body { width: fit-content; }
  .print-page { page-break-after: always; break-after: page; }
  .print-page:last-child { page-break-after: auto; break-after: auto; }
  .print-copy { page-break-after: always; break-after: page; }
  .print-copy:last-child { page-break-after: auto; break-after: auto; }
</style>
</head>
<body>${markup}</body>
</html>`;
}

export interface PdfJob {
  html: string;
  widthMm: number;
  /** explicit physical page height — omit together with measureContent for rolls */
  heightMm?: number;
  /** measure the true content height (max painted element bottom) — used for
   *  continuous-roll documents whose rendered height can exceed the estimate */
  measureContent?: boolean;
}

/** Print one HTML document to PDF bytes. */
export async function htmlToPdf(job: PdfJob): Promise<Buffer> {
  const browser = await getBrowser();
  const context = await browser.newContext();
  try {
    const page = await context.newPage();
    await page.setContent(job.html, { waitUntil: 'networkidle', timeout: 45000 });
    await page.evaluate(() => (document.fonts ? document.fonts.ready.then(() => undefined) : Promise.resolve()));

    let heightMm = job.heightMm;
    if (!heightMm && job.measureContent) {
      heightMm = await page.evaluate(() => {
        const root = document.getElementById('print-root');
        if (!root) return 297;
        let maxBottom = 0;
        root.querySelectorAll('*').forEach((el) => {
          const r = (el as HTMLElement).getBoundingClientRect();
          if (r.height > 0) maxBottom = Math.max(maxBottom, r.bottom);
        });
        return Math.ceil((maxBottom / 3.7795275591) * 10) / 10 + 0.5;
      });
    }
    if (!heightMm) heightMm = 297;

    const bytes = await page.pdf({
      width: `${job.widthMm}mm`,
      height: `${heightMm}mm`,
      printBackground: true,
      margin: { top: 0, bottom: 0, left: 0, right: 0 },
    });
    return Buffer.from(bytes);
  } finally {
    await context.close();
  }
}

export { MM_PX };

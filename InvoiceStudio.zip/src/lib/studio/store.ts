/* ============================================================
 * InvoiceStudio — server-side store over JSON files
 * (server-only: uses node fs)
 * ============================================================ */
import { readJson, writeJson, updateJson } from './jsondb';
import { DEFAULT_SETTINGS, createDefaultTemplate, BUILTIN_BILL_VARS, markSeedRepeats, RESERVED_BUYER_KEYS } from './defaults';
import type { Bill, Buyer, BuyerFieldDef, ItemRecord, Settings, Template, VariableDef } from './types';

const TPL_FILE = 'templates.json';
const BILLS_FILE = 'bills.json';
const VARS_FILE = 'variables.json';
const SETTINGS_FILE = 'settings.json';
const BUYERS_FILE = 'buyers.json';
const ITEMS_FILE = 'items.json';

let seedPromise: Promise<void> | null = null;

async function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const settings = await readJson<Settings | null>(SETTINGS_FILE, null);
      if (!settings) {
        await writeJson(SETTINGS_FILE, DEFAULT_SETTINGS);
      }
      const templates = await readJson<Template[] | null>(TPL_FILE, null);
      if (!templates) {
        await writeJson(TPL_FILE, [createDefaultTemplate()]);
      }
      const vars = await readJson<VariableDef[] | null>(VARS_FILE, null);
      if (!vars) {
        await writeJson(VARS_FILE, []);
      }
      const bills = await readJson<Bill[] | null>(BILLS_FILE, null);
      if (!bills) {
        await writeJson(BILLS_FILE, []);
      }
      const buyers = await readJson<Buyer[] | null>(BUYERS_FILE, null);
      if (!buyers) {
        await writeJson(BUYERS_FILE, []);
      }
      const items = await readJson<ItemRecord[] | null>(ITEMS_FILE, null);
      if (!items) {
        await writeJson(ITEMS_FILE, []);
      }
      // one-time migration: flag repeat-on-page elements on the seeded invoice template
      const tpls = await readJson<Template[]>(TPL_FILE, []);
      if (tpls.length > 0 && !tpls.some((t) => t.elements.some((e) => e.repeatOnPages))) {
        await writeJson(
          TPL_FILE,
          tpls.map((t) => markSeedRepeats(JSON.parse(JSON.stringify(t)) as Template)),
        );
      }
    })();
  }
  await seedPromise;
}

/* ---------------- templates ---------------- */

export async function listTemplates(): Promise<Template[]> {
  await ensureSeed();
  return readJson<Template[]>(TPL_FILE, []);
}

export async function saveTemplates(templates: Template[]): Promise<void> {
  await writeJson(TPL_FILE, templates);
}

/** lock-protected read-modify-write for templates */
export async function mutateTemplates(
  mutate: (templates: Template[]) => Template[] | Promise<Template[]>,
): Promise<Template[]> {
  await ensureSeed();
  return updateJson<Template[]>(TPL_FILE, [], mutate);
}

/* ---------------- bills ---------------- */

export async function listBills(): Promise<Bill[]> {
  await ensureSeed();
  return readJson<Bill[]>(BILLS_FILE, []);
}

export async function saveBills(bills: Bill[]): Promise<void> {
  await writeJson(BILLS_FILE, bills);
}

/** Read → mutate → write under the per-file lock, so concurrent
 *  requests (bulk updates, simultaneous saves) never clobber each other. */
export async function mutateBills(
  mutate: (bills: Bill[]) => Bill[] | Promise<Bill[]>,
): Promise<Bill[]> {
  await ensureSeed();
  return updateJson<Bill[]>(BILLS_FILE, [], mutate);
}

/* ---------------- custom variables ---------------- */

export async function listVariables(): Promise<VariableDef[]> {
  await ensureSeed();
  return readJson<VariableDef[]>(VARS_FILE, []);
}

export async function saveVariables(vars: VariableDef[]): Promise<void> {
  await writeJson(VARS_FILE, vars);
}

/* ---------------- settings ---------------- */

export async function getSettings(): Promise<Settings> {
  await ensureSeed();
  const s = await readJson<Settings>(SETTINGS_FILE, DEFAULT_SETTINGS);
  // merge so settings saved by older versions gain new fields safely
  return { ...DEFAULT_SETTINGS, ...s, business: { ...DEFAULT_SETTINGS.business, ...s.business } };
}

export async function saveSettings(s: Settings): Promise<void> {
  await writeJson(SETTINGS_FILE, s);
}

/* ---------------- buyers ---------------- */

export async function listBuyers(): Promise<Buyer[]> {
  await ensureSeed();
  return readJson<Buyer[]>(BUYERS_FILE, []);
}

export async function saveBuyers(buyers: Buyer[]): Promise<void> {
  await writeJson(BUYERS_FILE, buyers);
}

/** lock-protected read-modify-write for buyers (upserts, edits, deletes) */
export async function mutateBuyers(
  mutate: (buyers: Buyer[]) => Buyer[] | Promise<Buyer[]>,
): Promise<Buyer[]> {
  await ensureSeed();
  return updateJson<Buyer[]>(BUYERS_FILE, [], mutate);
}

/* ---------------- items ---------------- */

export async function listItems(): Promise<ItemRecord[]> {
  await ensureSeed();
  return readJson<ItemRecord[]>(ITEMS_FILE, []);
}

export async function saveItems(items: ItemRecord[]): Promise<void> {
  await writeJson(ITEMS_FILE, items);
}

/** lock-protected read-modify-write for items (upserts, edits, deletes) */
export async function mutateItems(
  mutate: (items: ItemRecord[]) => ItemRecord[] | Promise<ItemRecord[]>,
): Promise<ItemRecord[]> {
  await ensureSeed();
  return updateJson<ItemRecord[]>(ITEMS_FILE, [], mutate);
}

/* ---------------- helpers ---------------- */

export function builtinVars(): VariableDef[] {
  return BUILTIN_BILL_VARS;
}

const MAX_BUYER_FIELDS = 12;
const FIELD_TYPES: BuyerFieldDef['type'][] = ['text', 'number', 'date'];

/** Validate/normalize a user-submitted buyerFields list (Settings save). */
export function sanitizeBuyerFields(raw: unknown): BuyerFieldDef[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>(RESERVED_BUYER_KEYS);
  const out: BuyerFieldDef[] = [];
  for (const item of raw.slice(0, MAX_BUYER_FIELDS)) {
    if (!item || typeof item !== 'object') continue;
    const def = item as Partial<BuyerFieldDef>;
    const label = String(def.label ?? '').trim().slice(0, 40);
    if (!label) continue;
    // key is provided when the field already exists (stable — values are keyed by it);
    // new fields get a slug derived from the label
    let key = String(def.key ?? '').trim().slice(0, 40) || slug(label);
    // resolve collisions with reserved keys / earlier fields deterministically
    if (seen.has(key)) key = `${key}_cf`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      key,
      label,
      type: FIELD_TYPES.includes(def.type as BuyerFieldDef['type']) ? (def.type as BuyerFieldDef['type']) : 'text',
    });
  }
  return out;
}

/** Keep only values whose keys match fields defined in Settings (values trimmed, ≤300 chars). */
export async function sanitizeBuyerCustom(raw: unknown): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  if (!raw || typeof raw !== 'object') return out;
  const settings = await getSettings();
  const allowed = new Set((settings.buyerFields ?? []).map((f) => f.key));
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (!allowed.has(k)) continue;
    const s = String(v ?? '').trim().slice(0, 300);
    if (s) out[k] = s;
  }
  return out;
}

function slug(label: string): string {
  const s = label
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
  return s || 'field';
}

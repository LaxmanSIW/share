/* ============================================================
 * InvoiceStudio — formatting helpers (client-safe, no node APIs)
 * ============================================================ */
import type { Bill, BillItem, BillStatus, BillTotals, DocType, RepeatCadence, Settings } from './types';

/** slugify a label into a stable storage key, e.g. "Credit Limit" → "credit_limit" */
export function slugKey(label: string): string {
  const s = label
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
  return s || 'field';
}

/** effective payment status (older bills predate the field) */
export function billStatus(b: Bill): BillStatus {
  return b.status ?? 'unpaid';
}

/** effective document type (older bills predate the field) */
export function docTypeOf(b: Bill): DocType {
  return b.docType ?? 'invoice';
}

/** display title for a document type */
export const DOC_TYPE_TITLE: Record<DocType, string> = {
  invoice: 'TAX INVOICE',
  proforma: 'PROFORMA INVOICE',
  quotation: 'QUOTATION',
  challan: 'DELIVERY CHALLAN',
  creditnote: 'CREDIT NOTE',
};

export const DOC_TYPE_META: Record<DocType, { label: string; short: string; cls: string }> = {
  invoice: { label: 'Invoice', short: 'INV', cls: 'border-[#d9a13b]/30 bg-[#d9a13b]/10 text-[#e8c064]' },
  proforma: { label: 'Proforma', short: 'PI', cls: 'border-sky-500/30 bg-sky-500/10 text-sky-300' },
  quotation: { label: 'Quotation', short: 'QT', cls: 'border-violet-500/30 bg-violet-500/10 text-violet-300' },
  challan: { label: 'Challan', short: 'DC', cls: 'border-teal-500/30 bg-teal-500/10 text-teal-300' },
  creditnote: { label: 'Credit Note', short: 'CN', cls: 'border-rose-500/30 bg-rose-500/10 text-rose-300' },
};

/** true when a document kind counts toward revenue / GST (tax invoices only) */
export function isRevenueDoc(b: Bill): boolean {
  return docTypeOf(b) === 'invoice';
}

/** total amount received against a bill — falls back to the legacy full-total convention */
export function paidAmount(b: Bill): number {
  if (b.payments && b.payments.length > 0) {
    return r2(b.payments.reduce((s, p) => s + (Number(p.amount) || 0), 0));
  }
  return billStatus(b) === 'paid' ? b.totals.grandTotal : 0;
}

/** balance still owed (cancelled bills owe nothing) */
export function dueAmount(b: Bill): number {
  if (billStatus(b) === 'cancelled') return 0;
  return Math.max(0, r2(b.totals.grandTotal - paidAmount(b)));
}

/** shared badge metadata for payment statuses */
export const STATUS_META: Record<BillStatus, { label: string; dot: string; cls: string }> = {
  unpaid: { label: 'Unpaid', dot: 'bg-amber-400', cls: 'border-amber-500/30 bg-amber-500/10 text-amber-300' },
  paid: { label: 'Paid', dot: 'bg-emerald-400', cls: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' },
  cancelled: { label: 'Cancelled', dot: 'bg-red-400', cls: 'border-red-500/30 bg-red-500/10 text-red-300' },
};

export function fmtMoney(n: number, currency = '₹'): string {
  const v = Number.isFinite(n) ? n : 0;
  const formatted = Math.abs(v).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${v < 0 ? '-' : ''}${currency}${formatted}`;
}

export function fmtNum(n: number, digits = 2): string {
  const v = Number.isFinite(n) ? n : 0;
  return v.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: digits });
}

export function fmtDate(iso: string): string {
  if (!iso) return '';
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

/* ---------------- amount in words (Indian system) ---------------- */

const ONES = [
  '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
  'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen',
];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function twoDigits(n: number): string {
  if (n < 20) return ONES[n];
  const t = Math.floor(n / 10);
  const o = n % 10;
  return `${TENS[t]}${o ? ` ${ONES[o]}` : ''}`;
}

function threeDigits(n: number): string {
  const h = Math.floor(n / 100);
  const rest = n % 100;
  const parts: string[] = [];
  if (h > 0) parts.push(`${ONES[h]} Hundred${rest ? ' ' : ''}`);
  if (rest > 0) parts.push(twoDigits(rest));
  return parts.join('').trim();
}

export function numberToWordsIndian(num: number): string {
  const n = Math.floor(Math.abs(num));
  if (n === 0) return 'Zero Rupees Only';
  const crore = Math.floor(n / 10000000);
  const lakh = Math.floor((n % 10000000) / 100000);
  const thousand = Math.floor((n % 100000) / 1000);
  const hundred = n % 1000;
  const parts: string[] = [];
  if (crore > 0) parts.push(`${threeDigits(crore)} Crore`);
  if (lakh > 0) parts.push(`${twoDigits(lakh)} Lakh`);
  if (thousand > 0) parts.push(`${twoDigits(thousand)} Thousand`);
  if (hundred > 0) parts.push(threeDigits(hundred));
  return `${parts.join(' ')} Rupees Only`;
}

export function amountInWords(total: number): string {
  const rupees = Math.floor(Math.abs(total));
  const paise = Math.round((Math.abs(total) - rupees) * 100);
  const base = numberToWordsIndian(rupees);
  if (paise > 0) {
    return `${base.replace(' Rupees Only', '')} Rupees and ${twoDigits(paise)} Paise Only`;
  }
  return base;
}

/* ---------------- bill totals ---------------- */

/** gross line value (qty × rate) before any discount */
export function itemGross(it: BillItem): number {
  return (Number(it.qty) || 0) * (Number(it.rate) || 0);
}

/** line value after the item's own discount percent */
export function itemAmount(it: BillItem): number {
  const gross = itemGross(it);
  const d = Math.max(0, Math.min(100, Number(it.discPct) || 0));
  return gross - gross * (d / 100);
}

export function computeTotals(
  items: BillItem[],
  discountPct: number,
  interState: boolean,
): BillTotals {
  const subtotal = items.reduce((s, it) => s + itemGross(it), 0);
  const itemDiscounts = items.reduce((s, it) => s + (itemGross(it) - itemAmount(it)), 0);
  const globalDiscount = (subtotal - itemDiscounts) * ((Number(discountPct) || 0) / 100);
  const discount = itemDiscounts + globalDiscount;
  const taxable = subtotal - discount;
  const gstTotal = items.reduce((s, it) => s + itemAmount(it) * ((Number(it.gst) || 0) / 100), 0);
  // GST applied exactly on the (already discounted) taxable lines
  const gstAmt = gstTotal;
  const cgst = !interState ? gstAmt / 2 : 0;
  const sgst = !interState ? gstAmt / 2 : 0;
  const igst = interState ? gstAmt : 0;
  const beforeRound = taxable + cgst + sgst + igst;
  const rounded = Math.round(beforeRound * 100) / 100;
  const roundOff = Math.round((rounded - beforeRound) * 100) / 100;
  const grandTotal = Math.round((beforeRound + roundOff) * 100) / 100;
  return {
    subtotal: r2(subtotal),
    discount: r2(discount),
    taxable: r2(taxable),
    cgst: r2(cgst),
    sgst: r2(sgst),
    igst: r2(igst),
    roundOff,
    grandTotal,
    totalQty: r2(items.reduce((s, it) => s + (Number(it.qty) || 0), 0)),
    itemCount: items.length,
  };
}

function r2(n: number): number {
  return Math.round((Number(n) || 0) * 100) / 100;
}

export function nextBillNo(settings: Settings): string {
  return `${settings.billNoPrefix || 'INV-'}${String(settings.billNoNext || 1).padStart(4, '0')}`;
}

export function uid(prefix = 'e'): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function todayISO(): string {
  const d = new Date();
  const tz = d.getTimezoneOffset();
  return new Date(d.getTime() - tz * 60000).toISOString().slice(0, 10);
}

/** Add one calendar month to a yyyy-mm-dd date (clamps to the month end, e.g. Jan 31 → Feb 28). */
export function addMonthsISO(iso: string, months = 1): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  const target = new Date(Date.UTC(y, m - 1 + months, 1));
  const lastDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(d, lastDay));
  return target.toISOString().slice(0, 10);
}

/** Add n days to a yyyy-mm-dd date. */
export function addDaysISO(iso: string, days = 1): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return t.toISOString().slice(0, 10);
}

/** Add n calendar years (clamps Feb 29 → Feb 28). */
export function addYearsISO(iso: string, years = 1): string {
  return addMonthsISO(iso, 12 * years);
}

/** display metadata for a recurring cadence */
export const REPEAT_META: Record<Exclude<RepeatCadence, 'none'>, { label: string; short: string; step: string }> = {
  weekly: { label: 'Weekly', short: 'W', step: 'week' },
  monthly: { label: 'Monthly', short: 'M', step: 'month' },
  yearly: { label: 'Yearly', short: 'Y', step: 'year' },
};

/** cadence of a bill's repeat flag ('none' when unset) */
export function repeatOf(b: Bill): RepeatCadence {
  return b.repeat && b.repeat !== 'none' ? b.repeat : 'none';
}

/** Next run date of a recurring bill (bill date + one cadence step). */
export function nextRepeatDate(b: Bill): string {
  switch (repeatOf(b)) {
    case 'weekly': return addDaysISO(b.date, 7);
    case 'yearly': return addYearsISO(b.date, 1);
    case 'monthly':
    default: return addMonthsISO(b.date, 1);
  }
}

/** true when a recurring bill's next occurrence is due today or overdue */
export function repeatDue(b: Bill): boolean {
  if (repeatOf(b) === 'none') return false;
  if (docTypeOf(b) !== 'invoice') return false;
  if (repeatEnded(b)) return false;
  return nextRepeatDate(b) <= todayISO();
}

/** true when the chain has run past its optional end date (no further copies) */
export function repeatEnded(b: Bill): boolean {
  const end = b.repeatEndDate?.trim();
  if (!end) return false;
  return nextRepeatDate(b) > end;
}

/** cadence-stepped next date, honouring a one-shot skip flag */
export function repeatSkipped(b: Bill): boolean {
  return b.repeatSkipNext === true;
}

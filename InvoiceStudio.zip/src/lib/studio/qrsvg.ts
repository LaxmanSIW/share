/* ============================================================
 * InvoiceStudio — QR code to inline SVG (isomorphic)
 * Server-safe: uses the `qrcode` package's synchronous create()
 * API and draws the module matrix ourselves. Produces the same
 * visual as qrcode.react (margin 0, square modules).
 * ============================================================ */
import QRCode from 'qrcode';

export interface QrSvgOptions {
  /** dark module color */
  fgColor?: string;
  /** light background color */
  bgColor?: string;
  /** error correction level */
  level?: 'L' | 'M' | 'Q' | 'H';
}

/** Render text into a self-contained inline <svg> string (synchronous). */
export function qrSvg(value: string, opts: QrSvgOptions = {}): string {
  if (!value) return '';
  let qr;
  try {
    qr = QRCode.create(value, { errorCorrectionLevel: opts.level ?? 'M' });
  } catch {
    return '';
  }
  const size = qr.modules.size;
  const data = qr.modules.data;
  const fg = opts.fgColor || '#1a1a1a';
  const bg = opts.bgColor || '#ffffff';

  const rects: string[] = [];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (data[y * size + x]) {
        rects.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${fg}"/>`);
      }
    }
  }
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" ` +
    `shape-rendering="crispEdges" role="img" aria-label="QR code">` +
    `<rect width="${size}" height="${size}" fill="${bg}"/>` +
    rects.join('') +
    `</svg>`
  );
}

/** true when running outside a browser (React effects are unavailable) */
export function isServerRender(): boolean {
  return typeof window === 'undefined';
}

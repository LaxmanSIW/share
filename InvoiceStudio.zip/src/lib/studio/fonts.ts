import type { CustomFontDef } from './types';

export interface FontOption {
  label: string;
  value: string;
  category: 'custom' | 'sans' | 'serif' | 'mono' | 'display';
  isCustom?: boolean;
}

export interface FontGroup {
  category: string;
  fonts: FontOption[];
}

export const BUILTIN_FONTS: FontOption[] = [
  // --- Sans-Serif ---
  { label: 'Inter', value: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", category: 'sans' },
  { label: 'Roboto', value: "'Roboto', 'Segoe UI', Arial, sans-serif", category: 'sans' },
  { label: 'Poppins', value: "'Poppins', 'Segoe UI', sans-serif", category: 'sans' },
  { label: 'Montserrat', value: "'Montserrat', 'Segoe UI', sans-serif", category: 'sans' },
  { label: 'Outfit', value: "'Outfit', 'Segoe UI', sans-serif", category: 'sans' },
  { label: 'Open Sans', value: "'Open Sans', 'Segoe UI', sans-serif", category: 'sans' },
  { label: 'Lato', value: "'Lato', 'Segoe UI', sans-serif", category: 'sans' },
  { label: 'Plus Jakarta Sans', value: "'Plus Jakarta Sans', sans-serif", category: 'sans' },
  { label: 'Arial', value: 'Arial, Helvetica, sans-serif', category: 'sans' },
  { label: 'Helvetica', value: 'Helvetica, Arial, sans-serif', category: 'sans' },
  { label: 'Segoe UI', value: "'Segoe UI', system-ui, sans-serif", category: 'sans' },
  { label: 'Trebuchet MS', value: "'Trebuchet MS', Helvetica, sans-serif", category: 'sans' },
  { label: 'Verdana', value: 'Verdana, Geneva, sans-serif', category: 'sans' },
  { label: 'Tahoma', value: 'Tahoma, Geneva, sans-serif', category: 'sans' },

  // --- Serif ---
  { label: 'Playfair Display', value: "'Playfair Display', Georgia, 'Times New Roman', serif", category: 'serif' },
  { label: 'Merriweather', value: "'Merriweather', Georgia, serif", category: 'serif' },
  { label: 'Times New Roman', value: '"Times New Roman", Times, serif', category: 'serif' },
  { label: 'Georgia', value: 'Georgia, serif', category: 'serif' },
  { label: 'Garamond', value: "Garamond, 'Times New Roman', serif", category: 'serif' },
  { label: 'Palatino', value: "'Palatino Linotype', Palatino, serif", category: 'serif' },

  // --- Monospace ---
  { label: 'Space Mono', value: "'Space Mono', 'Courier New', monospace", category: 'mono' },
  { label: 'JetBrains Mono', value: "'JetBrains Mono', monospace", category: 'mono' },
  { label: 'Courier New', value: "'Courier New', Courier, monospace", category: 'mono' },
  { label: 'Consolas', value: "Consolas, 'Courier New', monospace", category: 'mono' },

  // --- Display ---
  { label: 'Oswald', value: "'Oswald', 'Arial Black', sans-serif", category: 'display' },
  { label: 'Bebas Neue', value: "'Bebas Neue', 'Arial Black', sans-serif", category: 'display' },
  { label: 'Impact', value: 'Impact, Charcoal, sans-serif', category: 'display' },
];

/** Standard Google Fonts link included for high-performance zero-delay preview */
export const PRELOADED_GOOGLE_FONTS_HREF =
  'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&family=Lato:wght@300;400;700&family=Merriweather:ital,wght@0,300;0,400;0,700;1,300&family=Montserrat:wght@300;400;500;600;700;800&family=Open+Sans:wght@300;400;600;700&family=Oswald:wght@400;600;700&family=Outfit:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@400;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Roboto:wght@300;400;500;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap';

/** Generate standard Google Fonts CSS URL for any font name */
export function getGoogleFontCssUrl(name: string): string {
  const family = encodeURIComponent(name.trim()).replace(/%20/g, '+');
  return `https://fonts.googleapis.com/css2?family=${family}:ital,wght@0,300..900;1,300..900&display=swap`;
}

/** Sanitize font family name to safely use in CSS font-family string */
export function formatFontFamily(name: string, fallback = 'sans-serif'): string {
  const cleanName = name.replace(/['"]/g, '').trim();
  return `'${cleanName}', ${fallback}`;
}

/** Combine built-in fonts with user-installed custom fonts */
export function getAllFontOptions(customFonts?: CustomFontDef[]): FontOption[] {
  const customOpts: FontOption[] = (customFonts ?? []).map((cf) => ({
    label: cf.name,
    value: cf.family,
    category: 'custom' as const,
    isCustom: true,
  }));
  return [...customOpts, ...BUILTIN_FONTS];
}

/** Group all available fonts for grouped select dropdowns */
export function getAllFontGroups(customFonts?: CustomFontDef[]): FontGroup[] {
  const groups: FontGroup[] = [];

  if (customFonts && customFonts.length > 0) {
    groups.push({
      category: 'Custom Fonts (Your Uploads & Web Fonts)',
      fonts: customFonts.map((cf) => ({
        label: cf.name,
        value: cf.family,
        category: 'custom' as const,
        isCustom: true,
      })),
    });
  }

  groups.push(
    {
      category: 'Modern Sans-Serif',
      fonts: BUILTIN_FONTS.filter((f) => f.category === 'sans'),
    },
    {
      category: 'Classic Serif',
      fonts: BUILTIN_FONTS.filter((f) => f.category === 'serif'),
    },
    {
      category: 'Monospace & Receipts',
      fonts: BUILTIN_FONTS.filter((f) => f.category === 'mono'),
    },
    {
      category: 'Display & Headlines',
      fonts: BUILTIN_FONTS.filter((f) => f.category === 'display'),
    },
  );

  return groups;
}

/** Generate all CSS rules (@import and @font-face) for custom fonts */
export function generateFontCss(customFonts?: CustomFontDef[]): string {
  if (!customFonts || customFonts.length === 0) return '';

  const imports: string[] = [];
  const fontFaces: string[] = [];

  for (const font of customFonts) {
    if (font.source === 'google' || font.source === 'url') {
      const url = font.url || getGoogleFontCssUrl(font.name);
      imports.push(`@import url('${url}');`);
    } else if (font.source === 'upload') {
      const srcUrl = font.fileUrl || font.dataUrl;
      if (srcUrl) {
        const formatStr = font.format ? ` format('${font.format}')` : '';
        const cleanFamily = font.name.replace(/['"]/g, '').trim();
        fontFaces.push(`
@font-face {
  font-family: '${cleanFamily}';
  src: url('${srcUrl}')${formatStr};
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
        `.trim());
      }
    }
  }

  return [...imports, ...fontFaces].join('\n\n');
}

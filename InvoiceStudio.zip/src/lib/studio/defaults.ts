/* ============================================================
 * InvoiceStudio — defaults: variables, settings, seed template
 * ============================================================ */
import type { BuyerFieldDef, Settings, Template, TemplateElement, VariableDef } from './types';
import { uid } from './format';

export const BUILTIN_BILL_VARS: VariableDef[] = [
  { key: 'buyer_name', label: 'Buyer Name', type: 'text', builtin: true },
  { key: 'buyer_address', label: 'Buyer Address', type: 'text', builtin: true },
  { key: 'buyer_gst', label: 'Buyer GSTIN', type: 'text', builtin: true },
  { key: 'buyer_phone', label: 'Buyer Phone', type: 'text', builtin: true },
  { key: 'buyer_state', label: 'Buyer State (Place of Supply)', type: 'text', builtin: true },
  { key: 'po_no', label: 'PO / Order No', type: 'text', builtin: true },
  { key: 'transport_name', label: 'Transport Name', type: 'text', builtin: true },
  { key: 'vehicle_no', label: 'Vehicle No', type: 'text', builtin: true },
  { key: 'e_way_bill', label: 'E-Way Bill No', type: 'text', builtin: true },
];

export interface VarGroup {
  group: string;
  vars: { key: string; label: string }[];
}

/** Everything that can be dropped into a text element. */
export function variableGroups(custom: VariableDef[], buyerFields?: BuyerFieldDef[]): VarGroup[] {
  return [
    {
      group: 'Bill',
      vars: [
        { key: 'invoice_no', label: 'Invoice Number' },
        { key: 'invoice_date', label: 'Invoice Date' },
        { key: 'buyer_name', label: 'Buyer Name' },
        { key: 'buyer_address', label: 'Buyer Address' },
        { key: 'buyer_gst', label: 'Buyer GSTIN' },
        { key: 'buyer_phone', label: 'Buyer Phone' },
        { key: 'buyer_state', label: 'Buyer State' },
        { key: 'po_no', label: 'PO / Order No' },
        { key: 'transport_name', label: 'Transport Name' },
        { key: 'vehicle_no', label: 'Vehicle No' },
        { key: 'e_way_bill', label: 'E-Way Bill No' },
        { key: 'doc_type', label: 'Document Type (TAX INVOICE / PROFORMA / QUOTATION)' },
        { key: 'ref_invoice_no', label: 'Against Invoice # (credit notes)' },
        { key: 'credit_reason', label: 'Credit / Adjustment Reason' },
      ],
    },
    {
      group: 'Computed',
      vars: [
        { key: 'subtotal', label: 'Subtotal' },
        { key: 'discount', label: 'Discount' },
        { key: 'taxable', label: 'Taxable Value' },
        { key: 'cgst', label: 'CGST' },
        { key: 'sgst', label: 'SGST' },
        { key: 'igst', label: 'IGST' },
        { key: 'round_off', label: 'Round Off' },
        { key: 'grand_total', label: 'Grand Total' },
        { key: 'amount_in_words', label: 'Amount in Words' },
        { key: 'total_qty', label: 'Total Quantity' },
        { key: 'item_count', label: 'Item Count' },
        { key: 'paid_amount', label: 'Paid Amount' },
        { key: 'due_amount', label: 'Due Amount' },
        { key: 'payment_status', label: 'Payment Status (PAID/UNPAID)' },
        { key: 'page_no', label: 'Page No' },
        { key: 'page_count', label: 'Page Count' },
        { key: 'copy_label', label: 'Copy Label (Original/Duplicate…)' },
      ],
    },
    {
      group: 'My Business',
      vars: [
        { key: 'business_name', label: 'Business Name' },
        { key: 'business_address', label: 'Business Address' },
        { key: 'business_gst', label: 'Business GSTIN' },
        { key: 'business_phone', label: 'Business Phone' },
        { key: 'business_email', label: 'Business Email' },
        { key: 'business_state', label: 'Business State' },
        { key: 'terms', label: 'Terms & Conditions' },
      ],
    },
    {
      group: 'Bank',
      vars: [
        { key: 'bank_name', label: 'Bank Name' },
        { key: 'bank_account', label: 'Account No' },
        { key: 'bank_ifsc', label: 'IFSC' },
        { key: 'bank_upi', label: 'UPI ID' },
      ],
    },
    {
      group: 'Buyer fields',
      vars: buyerCustomVarDefs(buyerFields).map((v) => ({ key: v.key, label: v.label })),
    },
    {
      group: 'Custom',
      vars: custom.map((v) => ({ key: v.key, label: v.label })),
    },
  ].filter((g) => g.vars.length > 0);
}

/** variable definitions for the user's custom buyer fields — usable in templates as {{buyer_<key>}} */
export function buyerCustomVarDefs(fields: BuyerFieldDef[] | undefined): VariableDef[] {
  return (fields ?? []).map((f) => ({ key: `buyer_${f.key}`, label: f.label, type: f.type, builtin: true }));
}

/** keys reserved by the five built-in buyer columns (custom field keys can't collide with them) */
export const RESERVED_BUYER_KEYS = ['name', 'address', 'gst', 'phone', 'state'];

export const DEFAULT_ITEM_COLUMNS = [
  { key: 'sr', label: 'Sr', width: 7, align: 'center' as const },
  { key: 'desc', label: 'Description of Goods', width: 37, align: 'left' as const },
  { key: 'hsn', label: 'HSN', width: 12, align: 'center' as const },
  { key: 'qty', label: 'Qty', width: 9, align: 'right' as const },
  { key: 'unit', label: 'Unit', width: 9, align: 'center' as const },
  { key: 'rate', label: 'Rate', width: 12, align: 'right' as const },
  { key: 'gst', label: 'GST%', width: 7, align: 'right' as const },
  { key: 'amount', label: 'Amount', width: 14, align: 'right' as const },
];

export const DEFAULT_SETTINGS: Settings = {
  business: {
    name: 'SHREE TRADERS',
    address: '12, Industrial Estate, MG Road\nMumbai – 400001, Maharashtra',
    gstin: '27ABCDE1234F1Z5',
    phone: '+91 98200 12345',
    email: 'accounts@shreetraders.in',
    state: 'Maharashtra',
    stateCode: '27',
    logo: '',
    bankName: 'HDFC Bank, MG Road Branch',
    accountNo: '50200012345678',
    ifsc: 'HDFC0000123',
    upi: 'shreetraders@hdfcbank',
    terms:
      '1. Goods once sold will not be taken back.\n2. Interest @18% p.a. will be charged on overdue payments.\n3. Subject to Mumbai jurisdiction only.',
  },
  currency: '₹',
  interState: false,
  billNoPrefix: 'INV-',
  billNoNext: 1,
  printOffsetX: 0,
  printOffsetY: 0,
  statusStamp: true,
  autoRecurring: false,
  buyerFields: [],
};

/* ---------------- seed template ---------------- */

interface E extends Partial<TemplateElement> {
  type: TemplateElement['type'];
  x: number;
  y: number;
  w: number;
  h: number;
}

const SEED: E[] = [
  { type: 'rect', x: 0, y: 0, w: 210, h: 30, bg: '#f4f1ea', borderWidth: 0, borderRadius: 0 },
  { type: 'image', x: 8, y: 4, w: 26, h: 22, src: '', objectFit: 'contain' },
  { type: 'text', x: 40, y: 4, w: 110, h: 8, text: '{{business_name}}', fontSize: 17, fontWeight: 700, color: '#1a1a1a', letterSpacing: 1.2 },
  { type: 'text', x: 40, y: 12.5, w: 110, h: 10, text: '{{business_address}}', fontSize: 8, color: '#444444', lineHeight: 1.4 },
  { type: 'text', x: 40, y: 23.5, w: 130, h: 5, text: 'GSTIN: {{business_gst}}   |   Phone: {{business_phone}}   |   {{business_email}}', fontSize: 8, color: '#555555' },
  { type: 'rect', x: 0, y: 30, w: 210, h: 11, bg: '#1c1c1c' },
  { type: 'text', x: 0, y: 30, w: 210, h: 11, text: 'TAX INVOICE', fontSize: 12.5, fontWeight: 700, color: '#f4f1ea', align: 'center', vAlign: 'middle', letterSpacing: 4 },
  { type: 'rect', x: 0, y: 41, w: 128, h: 34, bg: '#fafafa', borderWidth: 0.3, borderColor: '#c9c4b8' },
  { type: 'text', x: 5, y: 44, w: 60, h: 4.5, text: 'BILL TO', fontSize: 8, fontWeight: 700, color: '#8a7a4a', letterSpacing: 2 },
  { type: 'text', x: 5, y: 49, w: 118, h: 6, text: '{{buyer_name}}', fontSize: 11.5, fontWeight: 700, color: '#1a1a1a' },
  { type: 'text', x: 5, y: 55.5, w: 118, h: 10, text: '{{buyer_address}}', fontSize: 8.5, color: '#444444', lineHeight: 1.4 },
  { type: 'text', x: 5, y: 66.5, w: 118, h: 5, text: 'GSTIN: {{buyer_gst}}   |   Ph: {{buyer_phone}}', fontSize: 8, color: '#555555' },
  { type: 'rect', x: 128, y: 41, w: 82, h: 34, bg: '#fafafa', borderWidth: 0.3, borderColor: '#c9c4b8' },
  { type: 'text', x: 133, y: 44, w: 34, h: 4.5, text: 'INVOICE DETAILS', fontSize: 8, fontWeight: 700, color: '#8a7a4a', letterSpacing: 2 },
  { type: 'text', x: 133, y: 49.5, w: 40, h: 5, text: 'Invoice No:', fontSize: 8.5, color: '#666666' },
  { type: 'text', x: 165, y: 49.5, w: 40, h: 5, text: '{{invoice_no}}', fontSize: 9.5, fontWeight: 700, align: 'right', color: '#1a1a1a' },
  { type: 'text', x: 133, y: 55, w: 40, h: 5, text: 'Date:', fontSize: 8.5, color: '#666666' },
  { type: 'text', x: 165, y: 55, w: 40, h: 5, text: '{{invoice_date}}', fontSize: 9, align: 'right', color: '#1a1a1a' },
  { type: 'text', x: 133, y: 60.5, w: 40, h: 5, text: 'PO No:', fontSize: 8.5, color: '#666666' },
  { type: 'text', x: 165, y: 60.5, w: 40, h: 5, text: '{{po_no}}', fontSize: 9, align: 'right', color: '#1a1a1a' },
  { type: 'text', x: 133, y: 66, w: 40, h: 5, text: 'Transport:', fontSize: 8.5, color: '#666666' },
  { type: 'text', x: 165, y: 66, w: 40, h: 5, text: '{{transport_name}}', fontSize: 8.5, align: 'right', color: '#1a1a1a' },
  { type: 'table', x: 0, y: 75, w: 210, h: 20, columns: DEFAULT_ITEM_COLUMNS, headerBg: '#efe9db', headerColor: '#1a1a1a', rowHeight: 7, fontSize: 8.5, borderStyle: 'grid', showZebra: true },
  { type: 'rect', x: 128, y: 175, w: 82, h: 40, bg: '#fafafa', borderWidth: 0.3, borderColor: '#c9c4b8' },
  { type: 'text', x: 133, y: 178.5, w: 45, h: 5, text: 'Subtotal', fontSize: 8.5, color: '#555555' },
  { type: 'text', x: 165, y: 178.5, w: 40, h: 5, text: '{{subtotal}}', fontSize: 9, align: 'right', fontWeight: 600 },
  { type: 'text', x: 133, y: 184.5, w: 45, h: 5, text: 'CGST', fontSize: 8.5, color: '#555555' },
  { type: 'text', x: 165, y: 184.5, w: 40, h: 5, text: '{{cgst}}', fontSize: 9, align: 'right' },
  { type: 'text', x: 133, y: 190.5, w: 45, h: 5, text: 'SGST', fontSize: 8.5, color: '#555555' },
  { type: 'text', x: 165, y: 190.5, w: 40, h: 5, text: '{{sgst}}', fontSize: 9, align: 'right' },
  { type: 'text', x: 133, y: 196.5, w: 45, h: 5, text: 'Round Off', fontSize: 8.5, color: '#555555' },
  { type: 'text', x: 165, y: 196.5, w: 40, h: 5, text: '{{round_off}}', fontSize: 9, align: 'right' },
  { type: 'rect', x: 130, y: 202.5, w: 78, h: 10, bg: '#1c1c1c' },
  { type: 'text', x: 133, y: 202.5, w: 45, h: 10, text: 'GRAND TOTAL', fontSize: 9.5, fontWeight: 700, color: '#f4f1ea', vAlign: 'middle', letterSpacing: 1 },
  { type: 'text', x: 165, y: 202.5, w: 40, h: 10, text: '{{grand_total}}', fontSize: 10.5, fontWeight: 700, color: '#f4f1ea', align: 'right', vAlign: 'middle' },
  { type: 'rect', x: 0, y: 175, w: 128, h: 14, bg: '#fafafa', borderWidth: 0.3, borderColor: '#c9c4b8' },
  { type: 'text', x: 5, y: 177, w: 60, h: 4.5, text: 'AMOUNT IN WORDS', fontSize: 7.5, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
  { type: 'text', x: 5, y: 182, w: 118, h: 6, text: '{{amount_in_words}}', fontSize: 9, italic: true, fontWeight: 600, color: '#1a1a1a' },
  { type: 'rect', x: 0, y: 189, w: 128, h: 26, bg: '#fafafa', borderWidth: 0.3, borderColor: '#c9c4b8' },
  { type: 'text', x: 5, y: 191, w: 60, h: 4.5, text: 'BANK DETAILS', fontSize: 7.5, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
  { type: 'text', x: 5, y: 196, w: 118, h: 18, text: 'Bank: {{bank_name}}\nA/C: {{bank_account}}    IFSC: {{bank_ifsc}}\nUPI: {{bank_upi}}', fontSize: 8, color: '#444444', lineHeight: 1.5 },
  { type: 'text', x: 0, y: 219, w: 128, h: 4.5, text: 'TERMS & CONDITIONS', fontSize: 7.5, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
  { type: 'text', x: 0, y: 224, w: 128, h: 24, text: '{{terms}}', fontSize: 7.5, color: '#555555', lineHeight: 1.5 },
  { type: 'line', x: 145, y: 258, w: 55, h: 0.4, borderWidth: 0.4, borderColor: '#1a1a1a' },
  { type: 'text', x: 132, y: 246, w: 78, h: 5, text: 'For {{business_name}}', fontSize: 9, fontWeight: 600, align: 'center' },
  { type: 'text', x: 132, y: 261, w: 78, h: 5, text: 'Authorised Signatory', fontSize: 8, align: 'center', color: '#555555' },
  { type: 'text', x: 0, y: 288, w: 210, h: 6, text: 'This is a computer generated invoice  •  {{copy_label}}  •  Page {{page_no}} of {{page_count}}', fontSize: 7, align: 'center', color: '#999999', repeatOnPages: true },
];

/** Elements at the very top (letterhead + title band) and the footer repeat on every printed page. */
export function markSeedRepeats(template: Template): Template {
  if (template.page.autoHeight) return template; // continuous rolls never paginate
  const height = template.page.height;
  template.elements = template.elements.map((e) => {
    if (e.repeatOnPages !== undefined) return e;
    const topZone = (e.y ?? 0) + (e.h ?? 0) <= 41.5 && e.type !== 'image';
    const footerZone = (e.y ?? 0) >= height - 10;
    return topZone || footerZone ? { ...e, repeatOnPages: true } : e;
  });
  return template;
}

export function createDefaultTemplate(): Template {
  return buildPresetTemplate('classic');
}

/* ---------------- template presets ---------------- */

export type PresetKey = 'classic' | 'modern' | 'compact-a5' | 'minimal' | 'thermal' | 'thermal58';

export interface PresetMeta {
  key: PresetKey;
  name: string;
  size: string;
  desc: string;
  accent: string; // css color for the gallery chip
}

export const TEMPLATE_PRESETS: PresetMeta[] = [
  {
    key: 'classic',
    name: 'GST Tax Invoice — Classic',
    size: 'A4',
    desc: 'Cream letterhead, dark title band, full GST split, bank details & terms — the all-round standard.',
    accent: '#d9a13b',
  },
  {
    key: 'modern',
    name: 'GST Tax Invoice — Modern',
    size: 'A4',
    desc: 'Bold charcoal header with gold accents, side-by-side totals — a crisp contemporary look.',
    accent: '#1c1c1c',
  },
  {
    key: 'compact-a5',
    name: 'Compact GST Invoice',
    size: 'A5',
    desc: 'Half-size A5 docket — great for counters, deliveries and short bills.',
    accent: '#0e7a5f',
  },
  {
    key: 'minimal',
    name: 'Minimal Invoice',
    size: 'A4',
    desc: 'Clean borderless layout with hairline rules — for businesses that like it plain.',
    accent: '#52525b',
  },
  {
    key: 'thermal',
    name: 'Thermal POS Receipt',
    size: '80mm roll',
    desc: 'Continuous 80 mm receipt with a scan-to-pay UPI QR — for counter-top thermal printers.',
    accent: '#b45309',
  },
  {
    key: 'thermal58',
    name: 'Thermal Mini Receipt',
    size: '58mm roll',
    desc: 'Ultra-compact 58 mm roll for pocket POS printers — QR, barcode and GST totals, nothing wasted.',
    accent: '#0d9488',
  },
];

function assembleTemplate(name: string, page: Template['page'], seed: E[]): Template {
  const now = new Date().toISOString();
  const tpl: Template = {
    id: uid('tpl'),
    name,
    page,
    elements: seed.map((e, i) => ({
      id: uid(),
      zIndex: i,
      fontFamily: 'Arial, Helvetica, sans-serif',
      fontSize: 10,
      fontWeight: 400,
      color: '#1a1a1a',
      align: 'left' as const,
      vAlign: 'top' as const,
      lineHeight: 1.25,
      padding: 0,
      borderWidth: 0,
      borderColor: '#1a1a1a',
      borderRadius: 0,
      opacity: 1,
      ...e,
    })) as TemplateElement[],
    createdAt: now,
    updatedAt: now,
  };
  return markSeedRepeats(tpl);
}

/** Build a ready-to-edit template from a gallery preset. */
export function buildPresetTemplate(key: PresetKey): Template {
  if (key === 'modern') {
    const seed: E[] = [
      { type: 'rect', x: 0, y: 0, w: 210, h: 26, bg: '#181818' },
      { type: 'rect', x: 0, y: 26, w: 210, h: 1.2, bg: '#d9a13b' },
      { type: 'image', x: 10, y: 5, w: 24, h: 16, src: '', objectFit: 'contain' },
      { type: 'text', x: 40, y: 5, w: 100, h: 8, text: '{{business_name}}', fontSize: 16, fontWeight: 700, color: '#f5f2ea', letterSpacing: 1 },
      { type: 'text', x: 40, y: 13.5, w: 100, h: 10, text: '{{business_address}}', fontSize: 8, color: '#b8b2a4', lineHeight: 1.4 },
      { type: 'text', x: 140, y: 5, w: 60, h: 6, text: '{{doc_type}}', fontSize: 13, fontWeight: 700, align: 'right', color: '#d9a13b', letterSpacing: 2 },
      { type: 'text', x: 140, y: 12, w: 60, h: 10, text: 'GSTIN: {{business_gst}}\nPh: {{business_phone}} · {{business_email}}', fontSize: 7.5, align: 'right', color: '#b8b2a4', lineHeight: 1.5 },
      { type: 'rect', x: 8, y: 34, w: 194, h: 30, bg: '#f7f5f0', borderWidth: 0.3, borderColor: '#d9d2c2' },
      { type: 'text', x: 12, y: 37, w: 90, h: 4.5, text: 'BILL TO', fontSize: 7.5, fontWeight: 700, color: '#8a7a4a', letterSpacing: 2 },
      { type: 'text', x: 12, y: 42, w: 90, h: 6, text: '{{buyer_name}}', fontSize: 11, fontWeight: 700 },
      { type: 'text', x: 12, y: 48.5, w: 90, h: 10, text: '{{buyer_address}}', fontSize: 8, color: '#444444', lineHeight: 1.4 },
      { type: 'text', x: 12, y: 59.5, w: 90, h: 4, text: 'GSTIN: {{buyer_gst}} · Ph: {{buyer_phone}}', fontSize: 7.5, color: '#555555' },
      { type: 'text', x: 110, y: 37, w: 40, h: 4, text: 'Invoice No', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 150, y: 37, w: 48, h: 4, text: '{{invoice_no}}', fontSize: 9, fontWeight: 700, align: 'right' },
      { type: 'text', x: 110, y: 42.5, w: 40, h: 4, text: 'Date', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 150, y: 42.5, w: 48, h: 4, text: '{{invoice_date}}', fontSize: 8.5, align: 'right' },
      { type: 'text', x: 110, y: 48, w: 40, h: 4, text: 'PO No', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 150, y: 48, w: 48, h: 4, text: '{{po_no}}', fontSize: 8.5, align: 'right' },
      { type: 'text', x: 110, y: 53.5, w: 40, h: 4, text: 'Place of Supply', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 150, y: 53.5, w: 48, h: 4, text: '{{buyer_state}}', fontSize: 8.5, align: 'right' },
      { type: 'table', x: 8, y: 70, w: 194, h: 20, columns: DEFAULT_ITEM_COLUMNS, headerBg: '#181818', headerColor: '#f5f2ea', rowHeight: 7, fontSize: 8.5, borderStyle: 'rows', showZebra: true },
      { type: 'text', x: 110, y: 185, w: 40, h: 5, text: 'Subtotal', fontSize: 9, color: '#555555' },
      { type: 'text', x: 152, y: 185, w: 46, h: 5, text: '{{subtotal}}', fontSize: 9.5, align: 'right', fontWeight: 600 },
      { type: 'text', x: 110, y: 191, w: 40, h: 5, text: 'CGST', fontSize: 9, color: '#555555' },
      { type: 'text', x: 152, y: 191, w: 46, h: 5, text: '{{cgst}}', fontSize: 9.5, align: 'right' },
      { type: 'text', x: 110, y: 197, w: 40, h: 5, text: 'SGST', fontSize: 9, color: '#555555' },
      { type: 'text', x: 152, y: 197, w: 46, h: 5, text: '{{sgst}}', fontSize: 9.5, align: 'right' },
      { type: 'rect', x: 110, y: 204, w: 88, h: 11, bg: '#181818' },
      { type: 'text', x: 114, y: 204, w: 40, h: 11, text: 'TOTAL', fontSize: 10, fontWeight: 700, color: '#d9a13b', vAlign: 'middle', letterSpacing: 1.5 },
      { type: 'text', x: 152, y: 204, w: 42, h: 11, text: '{{grand_total}}', fontSize: 11, fontWeight: 700, color: '#f5f2ea', align: 'right', vAlign: 'middle' },
      { type: 'text', x: 8, y: 185, w: 94, h: 4.5, text: 'AMOUNT IN WORDS', fontSize: 7, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
      { type: 'text', x: 8, y: 190, w: 94, h: 12, text: '{{amount_in_words}}', fontSize: 8.5, italic: true, lineHeight: 1.4 },
      { type: 'text', x: 8, y: 204, w: 94, h: 4.5, text: 'BANK DETAILS', fontSize: 7, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
      { type: 'text', x: 8, y: 209, w: 94, h: 16, text: '{{bank_name}}\nA/C {{bank_account}} · {{bank_ifsc}}\nUPI: {{bank_upi}}', fontSize: 7.5, color: '#444444', lineHeight: 1.5 },
      { type: 'text', x: 8, y: 228, w: 94, h: 4.5, text: 'TERMS', fontSize: 7, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1.5 },
      { type: 'text', x: 8, y: 233, w: 94, h: 20, text: '{{terms}}', fontSize: 7, color: '#555555', lineHeight: 1.5 },
      { type: 'line', x: 152, y: 252, w: 46, h: 0.4, borderWidth: 0.4 },
      { type: 'text', x: 140, y: 240, w: 60, h: 5, text: 'For {{business_name}}', fontSize: 8.5, fontWeight: 600, align: 'center' },
      { type: 'text', x: 140, y: 255, w: 60, h: 5, text: 'Authorised Signatory', fontSize: 7.5, align: 'center', color: '#555555' },
      { type: 'text', x: 0, y: 288, w: 210, h: 6, text: '{{copy_label}}  •  Page {{page_no}} of {{page_count}}', fontSize: 7, align: 'center', color: '#999999', repeatOnPages: true },
    ];
    return assembleTemplate('GST Tax Invoice — Modern', { sizeName: 'A4', width: 210, height: 297, orientation: 'portrait', margin: { top: 8, right: 8, bottom: 8, left: 8 } }, seed);
  }

  if (key === 'compact-a5') {
    const seed: E[] = [
      { type: 'text', x: 6, y: 5, w: 90, h: 7, text: '{{business_name}}', fontSize: 13, fontWeight: 700, letterSpacing: 0.5 },
      { type: 'text', x: 6, y: 12.5, w: 90, h: 9, text: '{{business_address}}', fontSize: 6.8, color: '#444444', lineHeight: 1.35 },
      { type: 'text', x: 6, y: 22, w: 90, h: 4, text: 'GSTIN: {{business_gst}} · Ph: {{business_phone}}', fontSize: 6.5, color: '#555555' },
      { type: 'text', x: 100, y: 5, w: 42, h: 6, text: '{{doc_type}}', fontSize: 11, fontWeight: 700, align: 'right', letterSpacing: 1.5 },
      { type: 'line', x: 6, y: 27.5, w: 136, h: 0.5, borderWidth: 0.6 },
      { type: 'text', x: 6, y: 30.5, w: 20, h: 4, text: 'Bill To', fontSize: 7, fontWeight: 700, color: '#8a7a4a' },
      { type: 'text', x: 6, y: 35, w: 76, h: 5, text: '{{buyer_name}}', fontSize: 9.5, fontWeight: 700 },
      { type: 'text', x: 6, y: 40.5, w: 76, h: 8, text: '{{buyer_address}}', fontSize: 7, color: '#444444', lineHeight: 1.35 },
      { type: 'text', x: 6, y: 49, w: 76, h: 4, text: 'GSTIN: {{buyer_gst}}', fontSize: 6.8, color: '#555555' },
      { type: 'text', x: 88, y: 30.5, w: 26, h: 4, text: 'No:', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 112, y: 30.5, w: 30, h: 4, text: '{{invoice_no}}', fontSize: 8.5, fontWeight: 700, align: 'right' },
      { type: 'text', x: 88, y: 35.5, w: 26, h: 4, text: 'Date:', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 112, y: 35.5, w: 30, h: 4, text: '{{invoice_date}}', fontSize: 8, align: 'right' },
      { type: 'text', x: 88, y: 40.5, w: 26, h: 4, text: 'Vehicle:', fontSize: 7.5, color: '#666666' },
      { type: 'text', x: 112, y: 40.5, w: 30, h: 4, text: '{{vehicle_no}}', fontSize: 8, align: 'right' },
      { type: 'table', x: 6, y: 56, w: 136, h: 20, columns: [
        { key: 'sr', label: '#', width: 7, align: 'center' as const },
        { key: 'desc', label: 'Description', width: 43, align: 'left' as const },
        { key: 'qty', label: 'Qty', width: 11, align: 'right' as const },
        { key: 'rate', label: 'Rate', width: 15, align: 'right' as const },
        { key: 'gst', label: 'GST%', width: 10, align: 'right' as const },
        { key: 'amount', label: 'Amount', width: 14, align: 'right' as const },
      ], headerBg: '#efe9db', headerColor: '#1a1a1a', rowHeight: 6, fontSize: 7.5, borderStyle: 'grid', showZebra: true },
      { type: 'text', x: 84, y: 130, w: 28, h: 4.5, text: 'Subtotal', fontSize: 7.5, color: '#555555' },
      { type: 'text', x: 114, y: 130, w: 28, h: 4.5, text: '{{subtotal}}', fontSize: 8, align: 'right', fontWeight: 600 },
      { type: 'text', x: 84, y: 135.5, w: 28, h: 4.5, text: 'CGST', fontSize: 7.5, color: '#555555' },
      { type: 'text', x: 114, y: 135.5, w: 28, h: 4.5, text: '{{cgst}}', fontSize: 8, align: 'right' },
      { type: 'text', x: 84, y: 141, w: 28, h: 4.5, text: 'SGST', fontSize: 7.5, color: '#555555' },
      { type: 'text', x: 114, y: 141, w: 28, h: 4.5, text: '{{sgst}}', fontSize: 8, align: 'right' },
      { type: 'rect', x: 82, y: 147, w: 60, h: 8, bg: '#1c1c1c' },
      { type: 'text', x: 84, y: 147, w: 28, h: 8, text: 'TOTAL', fontSize: 8, fontWeight: 700, color: '#f4f1ea', vAlign: 'middle' },
      { type: 'text', x: 112, y: 147, w: 28, h: 8, text: '{{grand_total}}', fontSize: 9, fontWeight: 700, color: '#f4f1ea', align: 'right', vAlign: 'middle' },
      { type: 'text', x: 6, y: 130, w: 74, h: 4.5, text: 'AMOUNT IN WORDS', fontSize: 6, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1 },
      { type: 'text', x: 6, y: 135, w: 74, h: 10, text: '{{amount_in_words}}', fontSize: 7, italic: true, lineHeight: 1.35 },
      { type: 'text', x: 6, y: 158, w: 74, h: 4, text: 'BANK', fontSize: 6, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1 },
      { type: 'text', x: 6, y: 162.5, w: 74, h: 12, text: '{{bank_name}} · A/C {{bank_account}}\nIFSC {{bank_ifsc}} · UPI {{bank_upi}}', fontSize: 6.5, color: '#444444', lineHeight: 1.45 },
      { type: 'text', x: 6, y: 176, w: 74, h: 4, text: 'TERMS', fontSize: 6, fontWeight: 700, color: '#8a7a4a', letterSpacing: 1 },
      { type: 'text', x: 6, y: 180.5, w: 74, h: 16, text: '{{terms}}', fontSize: 6, color: '#555555', lineHeight: 1.4 },
      { type: 'line', x: 106, y: 176, w: 36, h: 0.4, borderWidth: 0.4 },
      { type: 'text', x: 100, y: 168, w: 48, h: 4, text: 'For {{business_name}}', fontSize: 7.5, fontWeight: 600, align: 'center' },
      { type: 'text', x: 100, y: 178, w: 48, h: 4, text: 'Authorised Signatory', fontSize: 6.5, align: 'center', color: '#555555' },
      { type: 'text', x: 0, y: 201, w: 148, h: 5, text: '{{copy_label}} · Page {{page_no}}/{{page_count}}', fontSize: 6, align: 'center', color: '#999999', repeatOnPages: true },
    ];
    return assembleTemplate('Compact GST Invoice (A5)', { sizeName: 'A5', width: 148, height: 210, orientation: 'portrait', margin: { top: 6, right: 6, bottom: 6, left: 6 } }, seed);
  }

  if (key === 'minimal') {
    const seed: E[] = [
      { type: 'image', x: 8, y: 8, w: 22, h: 18, src: '', objectFit: 'contain' },
      { type: 'text', x: 8, y: 28, w: 100, h: 8, text: '{{business_name}}', fontSize: 15, fontWeight: 700 },
      { type: 'text', x: 8, y: 36.5, w: 100, h: 10, text: '{{business_address}}', fontSize: 8, color: '#555555', lineHeight: 1.4 },
      { type: 'text', x: 8, y: 47, w: 100, h: 4.5, text: 'GSTIN {{business_gst}} · {{business_phone}} · {{business_email}}', fontSize: 7.5, color: '#777777' },
      { type: 'text', x: 130, y: 28, w: 72, h: 7, text: '{{doc_type}}', fontSize: 14, fontWeight: 400, align: 'right', letterSpacing: 3, color: '#1a1a1a' },
      { type: 'text', x: 130, y: 36.5, w: 72, h: 4.5, text: '{{invoice_no}}', fontSize: 10, align: 'right' },
      { type: 'text', x: 130, y: 42, w: 72, h: 4.5, text: '{{invoice_date}}', fontSize: 8.5, align: 'right', color: '#555555' },
      { type: 'line', x: 8, y: 58, w: 194, h: 0.35, borderWidth: 0.35, borderColor: '#222222' },
      { type: 'text', x: 8, y: 63, w: 90, h: 4, text: 'BILL TO', fontSize: 7, fontWeight: 700, color: '#999999', letterSpacing: 2 },
      { type: 'text', x: 8, y: 68, w: 100, h: 6, text: '{{buyer_name}}', fontSize: 11, fontWeight: 600 },
      { type: 'text', x: 8, y: 74.5, w: 100, h: 10, text: '{{buyer_address}}', fontSize: 8, color: '#555555', lineHeight: 1.4 },
      { type: 'text', x: 8, y: 85, w: 100, h: 4.5, text: 'GSTIN {{buyer_gst}} · {{buyer_phone}}', fontSize: 7.5, color: '#777777' },
      { type: 'table', x: 8, y: 96, w: 194, h: 20, columns: DEFAULT_ITEM_COLUMNS, headerBg: '#ffffff', headerColor: '#1a1a1a', rowHeight: 7, fontSize: 8.5, borderStyle: 'rows', showZebra: false },
      { type: 'text', x: 130, y: 190, w: 40, h: 5, text: 'Subtotal', fontSize: 8.5, color: '#777777' },
      { type: 'text', x: 172, y: 190, w: 30, h: 5, text: '{{subtotal}}', fontSize: 9, align: 'right' },
      { type: 'text', x: 130, y: 196, w: 40, h: 5, text: 'CGST', fontSize: 8.5, color: '#777777' },
      { type: 'text', x: 172, y: 196, w: 30, h: 5, text: '{{cgst}}', fontSize: 9, align: 'right' },
      { type: 'text', x: 130, y: 202, w: 40, h: 5, text: 'SGST', fontSize: 8.5, color: '#777777' },
      { type: 'text', x: 172, y: 202, w: 30, h: 5, text: '{{sgst}}', fontSize: 9, align: 'right' },
      { type: 'line', x: 130, y: 209, w: 72, h: 0.35, borderWidth: 0.35, borderColor: '#222222' },
      { type: 'text', x: 130, y: 212, w: 40, h: 6, text: 'TOTAL', fontSize: 9.5, fontWeight: 700, letterSpacing: 1 },
      { type: 'text', x: 172, y: 212, w: 30, h: 6, text: '{{grand_total}}', fontSize: 10.5, fontWeight: 700, align: 'right' },
      { type: 'text', x: 8, y: 190, w: 100, h: 4.5, text: '{{amount_in_words}}', fontSize: 8, italic: true, color: '#444444' },
      { type: 'text', x: 8, y: 200, w: 100, h: 14, text: 'Bank {{bank_name}} · A/C {{bank_account}} · IFSC {{bank_ifsc}}\nUPI {{bank_upi}}', fontSize: 7.5, color: '#555555', lineHeight: 1.5 },
      { type: 'text', x: 8, y: 216, w: 100, h: 18, text: '{{terms}}', fontSize: 7, color: '#888888', lineHeight: 1.5 },
      { type: 'line', x: 150, y: 250, w: 52, h: 0.35, borderWidth: 0.35, borderColor: '#222222' },
      { type: 'text', x: 138, y: 238, w: 64, h: 5, text: 'For {{business_name}}', fontSize: 8.5, align: 'center' },
      { type: 'text', x: 138, y: 253, w: 64, h: 5, text: 'Authorised Signatory', fontSize: 7.5, align: 'center', color: '#777777' },
      { type: 'text', x: 0, y: 288, w: 210, h: 6, text: '{{copy_label}} · Page {{page_no}} of {{page_count}}', fontSize: 6.5, align: 'center', color: '#aaaaaa', repeatOnPages: true },
    ];
    return assembleTemplate('Minimal Invoice', { sizeName: 'A4', width: 210, height: 297, orientation: 'portrait', margin: { top: 8, right: 8, bottom: 8, left: 8 } }, seed);
  }

  if (key === 'thermal') {
    const seed: E[] = [
      { type: 'text', x: 4, y: 4, w: 72, h: 7, text: '{{business_name}}', fontSize: 12, fontWeight: 700, align: 'center', letterSpacing: 0.5 },
      { type: 'text', x: 4, y: 11.5, w: 72, h: 8, text: '{{business_address}}', fontSize: 6.2, align: 'center', color: '#444444', lineHeight: 1.35 },
      { type: 'text', x: 4, y: 20, w: 72, h: 4, text: 'GSTIN: {{business_gst}} · Ph: {{business_phone}}', fontSize: 6.2, align: 'center', color: '#555555' },
      { type: 'line', x: 4, y: 25.5, w: 72, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 4, y: 27.5, w: 36, h: 4, text: 'Invoice: {{invoice_no}}', fontSize: 7, fontWeight: 700 },
      { type: 'text', x: 40, y: 27.5, w: 36, h: 4, text: '{{invoice_date}}', fontSize: 7, align: 'right' },
      { type: 'text', x: 4, y: 32, w: 40, h: 4, text: '{{buyer_name}}', fontSize: 7.5, fontWeight: 700 },
      { type: 'text', x: 44, y: 32, w: 32, h: 4, text: '{{buyer_phone}}', fontSize: 7, align: 'right', color: '#555555' },
      { type: 'text', x: 4, y: 36, w: 72, h: 3.6, text: 'Vehicle: {{vehicle_no}}', fontSize: 6.5, color: '#666666', hideWhenBlank: true },
      // items table — reserves 4 sample rows (6.2 header + 4 × 4.8); on the roll,
      // elements below shift by the real row count automatically
      { type: 'table', x: 2, y: 41, w: 76, h: 25.4, columns: [
        { key: 'sr', label: '#', width: 6, align: 'center' as const },
        { key: 'desc', label: 'Item', width: 46, align: 'left' as const },
        { key: 'qty', label: 'Qty', width: 12, align: 'right' as const },
        { key: 'rate', label: 'Rate', width: 16, align: 'right' as const },
        { key: 'amount', label: 'Amt', width: 20, align: 'right' as const },
      ], headerBg: '#ffffff', headerColor: '#1a1a1a', rowHeight: 4.8, fontSize: 6.4, borderStyle: 'rows', showZebra: false },
      { type: 'text', x: 30, y: 68.5, w: 48, h: 4, text: 'Subtotal  {{subtotal}}', fontSize: 6.8, align: 'right', hideWhenBlank: true },
      { type: 'text', x: 38, y: 73, w: 22, h: 4, text: 'Tax (CGST + SGST)', fontSize: 6.8, color: '#555555' },
      { type: 'text', x: 60, y: 73, w: 18, h: 4, text: '{{cgst}}/{{sgst}}', fontSize: 6.8, align: 'right' },
      { type: 'line', x: 2, y: 78.5, w: 76, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 4, y: 80, w: 30, h: 6, text: 'TOTAL', fontSize: 10, fontWeight: 700, vAlign: 'middle' },
      { type: 'text', x: 34, y: 80, w: 44, h: 6, text: '{{grand_total}}', fontSize: 11, fontWeight: 700, align: 'right', vAlign: 'middle' },
      { type: 'text', x: 2, y: 87, w: 76, h: 3.6, text: '{{amount_in_words}}', fontSize: 5.8, italic: true, align: 'center', color: '#555555' },
      { type: 'qrcode', x: 29, y: 91.5, w: 22, h: 22, qrSource: 'upi_amount', qrColor: '#111111' },
      { type: 'text', x: 2, y: 114, w: 76, h: 3.6, text: 'Scan to pay via UPI — {{bank_upi}}', fontSize: 6.2, align: 'center', color: '#555555' },
      { type: 'line', x: 2, y: 119, w: 76, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 2, y: 121, w: 76, h: 4, text: 'Thank you! Please visit again.', fontSize: 7, align: 'center', fontWeight: 600 },
      { type: 'text', x: 2, y: 125.5, w: 76, h: 3.4, text: 'Goods once sold will not be taken back.', fontSize: 5.8, align: 'center', color: '#888888' },
      { type: 'barcode', x: 20, y: 130, w: 40, h: 10, barcodeData: '{{invoice_no}}', barcodeColor: '#111111', barcodeShowText: true },
    ];
    return assembleTemplate(
      'Thermal POS Receipt (80mm)',
      { sizeName: 'Thermal 80', width: 80, height: 132, orientation: 'portrait', margin: { top: 3, right: 2, bottom: 3, left: 2 }, autoHeight: true },
      seed,
    );
  }

  if (key === 'thermal58') {
    const seed: E[] = [
      { type: 'text', x: 2, y: 3, w: 54, h: 6, text: '{{business_name}}', fontSize: 9.5, fontWeight: 700, align: 'center', letterSpacing: 0.4 },
      { type: 'text', x: 2, y: 9.5, w: 54, h: 7, text: '{{business_address}}', fontSize: 5.2, align: 'center', color: '#444444', lineHeight: 1.3 },
      { type: 'text', x: 2, y: 17, w: 54, h: 3.4, text: 'GSTIN: {{business_gst}}', fontSize: 5.2, align: 'center', color: '#555555', hideWhenBlank: true },
      { type: 'line', x: 2, y: 21.5, w: 54, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 2, y: 23, w: 27, h: 3.6, text: '{{doc_type}}', fontSize: 5.8, fontWeight: 700 },
      { type: 'text', x: 29, y: 23, w: 27, h: 3.6, text: '{{invoice_date}}', fontSize: 5.8, align: 'right' },
      { type: 'text', x: 2, y: 27, w: 30, h: 3.6, text: 'Inv: {{invoice_no}}', fontSize: 6, fontWeight: 700 },
      { type: 'text', x: 2, y: 31, w: 54, h: 3.6, text: '{{buyer_name}}', fontSize: 6.2, fontWeight: 700, hideWhenBlank: true },
      { type: 'text', x: 2, y: 35, w: 54, h: 3.2, text: 'Ph: {{buyer_phone}}', fontSize: 5.4, color: '#555555', hideWhenBlank: true },
      { type: 'text', x: 2, y: 38.5, w: 54, h: 3.2, text: 'Vehicle: {{vehicle_no}}', fontSize: 5.4, color: '#666666', hideWhenBlank: true },
      // items table — reserves 4 sample rows (5.4 header + 4 × 4.4 = 23)
      { type: 'table', x: 1, y: 43, w: 56, h: 23, columns: [
        { key: 'sr', label: '#', width: 7, align: 'center' as const },
        { key: 'desc', label: 'Item', width: 55, align: 'left' as const },
        { key: 'qty', label: 'Qty', width: 13, align: 'right' as const },
        { key: 'amount', label: 'Amt', width: 25, align: 'right' as const },
      ], headerBg: '#ffffff', headerColor: '#1a1a1a', rowHeight: 4.4, fontSize: 5.4, borderStyle: 'rows', showZebra: false },
      { type: 'text', x: 22, y: 68, w: 34, h: 3.4, text: 'Subtotal  {{subtotal}}', fontSize: 5.6, align: 'right', hideWhenBlank: true },
      { type: 'text', x: 22, y: 72, w: 22, h: 3.4, text: 'Tax CGST+SGST', fontSize: 5.6, color: '#555555' },
      { type: 'text', x: 44, y: 72, w: 12, h: 3.4, text: '{{cgst}}', fontSize: 5.6, align: 'right' },
      { type: 'line', x: 2, y: 76.5, w: 54, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 2, y: 78, w: 22, h: 5.5, text: 'TOTAL', fontSize: 8, fontWeight: 700, vAlign: 'middle' },
      { type: 'text', x: 24, y: 78, w: 32, h: 5.5, text: '{{grand_total}}', fontSize: 9, fontWeight: 700, align: 'right', vAlign: 'middle' },
      { type: 'text', x: 1, y: 84.5, w: 56, h: 3.2, text: '{{amount_in_words}}', fontSize: 4.8, italic: true, align: 'center', color: '#555555' },
      { type: 'qrcode', x: 20, y: 88.5, w: 18, h: 18, qrSource: 'upi_amount', qrColor: '#111111' },
      { type: 'text', x: 1, y: 107.5, w: 56, h: 3.2, text: 'Scan to pay via UPI — {{bank_upi}}', fontSize: 5, align: 'center', color: '#555555', hideWhenBlank: true },
      { type: 'line', x: 2, y: 111.5, w: 54, h: 0.3, borderWidth: 0.3, borderColor: '#333333' },
      { type: 'text', x: 1, y: 113, w: 56, h: 3.6, text: 'Thank you! Please visit again.', fontSize: 6, align: 'center', fontWeight: 600 },
      { type: 'text', x: 1, y: 117, w: 56, h: 3, text: 'Goods once sold will not be taken back.', fontSize: 4.8, align: 'center', color: '#888888' },
      { type: 'barcode', x: 12, y: 121, w: 34, h: 8, barcodeData: '{{invoice_no}}', barcodeColor: '#111111', barcodeShowText: true },
    ];
    return assembleTemplate(
      'Thermal Mini Receipt (58mm)',
      { sizeName: 'Thermal 58', width: 58, height: 132, orientation: 'portrait', margin: { top: 2, right: 1, bottom: 2, left: 1 }, autoHeight: true },
      seed,
    );
  }

  // classic (original seed)
  return assembleTemplate('GST Tax Invoice — Classic', { sizeName: 'A4', width: 210, height: 297, orientation: 'portrait', margin: { top: 8, right: 8, bottom: 8, left: 8 } }, SEED);
}

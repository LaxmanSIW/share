/* ============================================================
 * InvoiceStudio — recurring-invoice auto-creation engine
 * (server-only: uses the JSON store)
 *
 * Lazy daily sweep: the first request after midnight creates the
 * next occurrence of every due recurring invoice. A marker in
 * db/meta.json keeps it to one run per day; a Settings switch
 * (autoRecurring) turns the feature on/off.
 * ============================================================ */
import { readJson, writeJson } from './jsondb';
import { getSettings, saveSettings, mutateBills } from './store';
import type { Bill, Settings } from './types';
import { amountInWords, computeTotals, docTypeOf, nextBillNo, nextRepeatDate, repeatOf, todayISO, uid } from './format';
import { sanitizeItems } from './sanitize';
const META_FILE = 'meta.json';

interface Meta {
  lastSweepDate?: string; // yyyy-mm-dd of the last auto-recurring sweep
}

async function readMeta(): Promise<Meta> {
  return readJson<Meta>(META_FILE, {});
}

export interface SweepResult {
  ran: boolean;          // false = skipped (feature off / already ran today)
  reason?: string;
  created: Bill[];       // invoices created by this sweep
  sourceNos: string[];   // bill numbers the new copies were rolled from
  skipped: string[];     // bill numbers whose next occurrence was skipped (skip-once flag)
  ended: string[];       // bill numbers whose chain passed its end date (flag cleared)
}

/** Roll one recurring bill forward: next number, cadence-stepped date
 *  (overdue → today), same buyer/items, fresh unpaid state.
 *  The optional end date carries over so chains stop automatically. */
function rollBill(source: Bill, counter: number, settings: Settings): Bill {
  const now = new Date().toISOString();
  const items = sanitizeItems(source.items);
  const totals = computeTotals(items, Number(source.discountPct) || 0, !!settings.interState);
  const due = nextRepeatDate(source);
  const date = todayISO() > due ? todayISO() : due;
  return {
    id: uid('bill'),
    billNo: `${settings.billNoPrefix || 'INV-'}${String(counter).padStart(4, '0')}`,
    date,
    templateId: source.templateId,
    templateName: source.templateName,
    variables: { ...source.variables },
    items,
    discountPct: Number(source.discountPct) || 0,
    totals,
    amountInWords: amountInWords(totals.grandTotal),
    notes: source.notes ?? '',
    printCount: 0,
    status: 'unpaid',
    docType: 'invoice',
    repeat: source.repeat && source.repeat !== 'none' ? source.repeat : 'monthly',
    repeatEndDate: source.repeatEndDate,
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Run the daily sweep (at most once per calendar day unless forced).
 * Creates the next occurrence for every due recurring invoice and
 * advances the bill-number counter. The source bill's repeat flag is
 * cleared under the bills write lock, so each chain keeps exactly one
 * open occurrence — concurrent sweeps can never duplicate a chain.
 */
export async function runRecurringSweep(force = false): Promise<SweepResult> {
  const settings = await getSettings();
  if (!settings.autoRecurring && !force) {
    return { ran: false, reason: 'auto-create is off', created: [], sourceNos: [], skipped: [], ended: [] };
  }
  const today = todayISO();
  const meta = await readMeta();
  if (!force && meta.lastSweepDate === today) {
    return { ran: false, reason: 'already ran today', created: [], sourceNos: [], skipped: [], ended: [] };
  }

  const created: Bill[] = [];
  const sourceNos: string[] = [];
  const skipped: string[] = [];
  const ended: string[] = [];

  const changed = await mutateBills((bills) => {
    let counter = settings.billNoNext || 1;
    const rolled: Bill[] = [];
    // source bills to clear/advance: cleared repeat after a roll, or date-rolled after a skip
    const patch = new Map<string, Partial<Bill>>();
    for (const b of bills) {
      if (repeatOf(b) === 'none' || docTypeOf(b) !== 'invoice') continue;
      const due = nextRepeatDate(b);
      // chain past its end date? clear the flag so it stops nagging
      if (b.repeatEndDate && due > b.repeatEndDate) {
        patch.set(b.id, { repeat: 'none', repeatEndDate: undefined, repeatSkipNext: false, updatedAt: new Date().toISOString() });
        ended.push(b.billNo);
        continue;
      }
      if (due > today) continue; // not due yet
      // one-shot skip: roll the source date forward one cadence, create nothing
      if (b.repeatSkipNext) {
        patch.set(b.id, { date: due, repeatSkipNext: false, updatedAt: new Date().toISOString() });
        skipped.push(b.billNo);
        continue;
      }
      rolled.push(rollBill(b, counter, settings));
      counter += 1;
      patch.set(b.id, { repeat: 'none' as const, updatedAt: new Date().toISOString() });
      sourceNos.push(b.billNo);
    }
    if (rolled.length === 0 && patch.size === 0) return bills;
    const now = new Date().toISOString();
    const out = bills.map((b) => (patch.has(b.id) ? { ...b, ...patch.get(b.id), updatedAt: now } : b)).concat(rolled);
    created.push(...rolled);
    return out;
  });

  if (changed) {
    // advance the bill-number counter past every number consumed by the sweep
    const fresh = await getSettings();
    const usedUpTo = (settings.billNoNext || 1) + created.length;
    if ((fresh.billNoNext || 1) < usedUpTo) {
      fresh.billNoNext = usedUpTo;
      await saveSettings(fresh);
    }
  }

  // mark the day either way so we don't rescan on every request
  await writeJson<Meta>(META_FILE, { ...meta, lastSweepDate: today });

  return { ran: true, created, sourceNos, skipped, ended };
}

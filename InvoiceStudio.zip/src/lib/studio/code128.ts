/* ============================================================
 * InvoiceStudio — CODE128-B barcode encoder (pure, isomorphic)
 * Produces an inline <svg> string identical in spirit to what
 * JsBarcode draws in the browser — used by the server-side PDF
 * export where React effects never run.
 * ============================================================ */

/** Bar/space widths for values 0..106 (11 modules each; stop has 13). */
const PATTERNS = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213',
  '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132',
  '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211',
  '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
  '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331',
  '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111',
  '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
  '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
  '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
  '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141',
  '114131', '311141', '411131', '211412', '211214', '211232', '2331112',
];

const START_B = 104;
const STOP = 106;

export interface Code128Options {
  /** bar ink color */
  color?: string;
  /** draw the human-readable value under the bars */
  showText?: boolean;
  /** font family for the human-readable value */
  font?: string;
  /** font size (px) for the human-readable value */
  fontSize?: number;
  /** bar height (px) */
  barHeight?: number;
  /** quiet-zone modules on each side */
  quietZone?: number;
}

/**
 * Encode text into a self-contained inline SVG string (CODE128-B).
 * Characters outside ASCII 32..126 are ignored (same rule as the browser path).
 * The viewBox stretches to whatever box the host environment gives it.
 */
export function code128Svg(value: string, opts: Code128Options = {}): string {
  const data = (value || '').replace(/[^\x20-\x7e]/g, '');
  if (!data) return '';

  const color = opts.color || '#1a1a1a';
  const showText = opts.showText !== false;
  const font = opts.font || 'Arial, Helvetica, sans-serif';
  const fontSize = opts.fontSize ?? 13;
  const barHeight = opts.barHeight ?? 46;
  const quiet = opts.quietZone ?? 10; // modules
  const textMargin = 1;
  const fontY = barHeight + textMargin + fontSize * 0.85;

  // ---- sequence of symbols ----
  const codes: number[] = [START_B];
  let sum = START_B;
  for (let i = 0; i < data.length; i++) {
    const v = data.charCodeAt(i) - 32; // CODE128-B value for ASCII 32..126
    codes.push(v);
    sum += v * (i + 1);
  }
  codes.push(sum % 103);
  codes.push(STOP);

  // ---- widths → rect list ----
  let x = quiet;
  const rects: string[] = [];
  for (const code of codes) {
    const pattern = PATTERNS[code];
    let isBar = true;
    for (const ch of pattern) {
      const w = Number(ch);
      if (isBar) rects.push(`<rect x="${x}" y="0" width="${w}" height="${barHeight}" fill="${color}"/>`);
      x += w;
      isBar = !isBar;
    }
  }
  const totalW = x + quiet;
  const totalH = showText ? fontY + 2 : barHeight;

  const text = showText
    ? `<text x="${totalW / 2}" y="${fontY}" font-family="${font}" font-size="${fontSize}" fill="${color}" text-anchor="middle">${data
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')}</text>`
    : '';

  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalW} ${totalH}" ` +
    `preserveAspectRatio="none" role="img" aria-label="Barcode ${data.replace(/"/g, '')}">` +
    rects.join('') + text + `</svg>`
  );
}

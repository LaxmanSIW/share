/* ============================================================
 * InvoiceStudio — tiny isomorphic CSV toolkit
 * RFC4180-style parser (quoted fields, "" escapes, embedded
 * commas / newlines), serializer + buyer-row validation helpers.
 * Safe for both client bundles and API routes (no node imports).
 * ============================================================ */

import type { BuyerFieldDef } from './types';

/** Escape a single cell for CSV output (quotes when needed). */
export function csvCell(v: string | number): string {
  const s = String(v ?? '');
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Join a row of cells and append CRLF (Excel-friendly). */
export function csvRow(cells: (string | number)[]): string {
  return cells.map(csvCell).join(',') + '\r\n';
}

/**
 * Parse CSV text into a matrix of string cells.
 * - strips a leading UTF-8 BOM
 * - handles quoted fields, "" escapes, commas & newlines inside quotes
 * - tolerates \r\n and \n line endings
 */
export function parseCsv(text: string): string[][] {
  const src = text.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (inQuotes) {
      if (c === '"') {
        if (src[i + 1] === '"') { field += '"'; i += 2; continue; }
        inQuotes = false; i++; continue;
      }
      field += c; i++; continue;
    }
    if (c === '"') { inQuotes = true; i++; continue; }
    if (c === ',') { row.push(field); field = ''; i++; continue; }
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }
    if (c === '\r') { i++; continue; }
    field += c; i++;
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  return rows;
}

/* ---------------- buyer CSV schema ---------------- */

export const BUYER_CSV_COLUMNS = ['name', 'address', 'gst', 'phone', 'state'] as const;

/** alternate header spellings accepted for each canonical column */
const HEADER_ALIASES: Record<(typeof BUYER_CSV_COLUMNS)[number], string[]> = {
  name: ['name', 'buyer name', 'buyer', 'party', 'party name', 'customer', 'customer name', 'buyername'],
  address: ['address', 'billing address', 'buyer address'],
  gst: ['gst', 'gstin', 'gst no', 'gst number', 'gstno', 'gst number.', 'gst no.'],
  phone: ['phone', 'mobile', 'phone no', 'mobile no', 'contact', 'contact no', 'phone number', 'mobile number'],
  state: ['state', 'place of supply', 'buyer state'],
};

/** Does this first row look like a header (not a real buyer)? */
export function looksLikeHeader(row: string[]): boolean {
  const cells = row.map((c) => c.trim().toLowerCase());
  return cells.some((c) => HEADER_ALIASES.name.includes(c)) ||
    cells.filter((c) => Object.values(HEADER_ALIASES).flat().includes(c)).length >= 2;
}

/**
 * Map a header row to canonical column indexes.
 * Unknown columns are ignored (their data is dropped) unless they match a
 * custom buyer field's label or key → { custom: key }.
 */
export type BuyerColMap = (typeof BUYER_CSV_COLUMNS)[number] | { custom: string } | null;

export function mapBuyerHeader(header: string[], buyerFields: BuyerFieldDef[]): BuyerColMap[] {
  return header.map((cell) => {
    const key = cell.trim().toLowerCase();
    for (const col of BUYER_CSV_COLUMNS) {
      if (HEADER_ALIASES[col].includes(key)) return col;
    }
    for (const f of buyerFields) {
      if (!f.key) continue;
      if (key === f.label.trim().toLowerCase() || key === f.key.toLowerCase()) return { custom: f.key };
    }
    return null;
  });
}

/** Loose GSTIN check: 2 digits + 5 letters + 4 digits + letter + alnum + Z + alnum. */
export function isValidGstin(gst: string): boolean {
  return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gst.trim().toUpperCase());
}

/** Indian mobile check: 10 digits (optionally 0 / 91 prefixed). */
export function normalizePhone(phone: string): string {
  return phone.replace(/[^0-9+]/g, '');
}

export function isValidPhone(phone: string): boolean {
  const d = phone.replace(/[^0-9]/g, '');
  return /^([6-9]\d{9}|0[6-9]\d{9}|91[6-9]\d{9})$/.test(d);
}

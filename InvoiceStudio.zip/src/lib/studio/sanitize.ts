/* ============================================================
 * InvoiceStudio — server-side input normalizers
 * Bills can arrive from the UI, from conversions, or from raw
 * API calls; every item/payment gets a stable shape so the UI
 * (React keys, arithmetic, CSV export) never sees junk.
 * ============================================================ */
import type { BillItem, BillPayment, PaymentMethod } from './types';
import { uid } from './format';

type Raw = Record<string, unknown>;

const num = (v: unknown, d = 0): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const str = (v: unknown, d = ''): string => {
  if (typeof v === 'string') return v;
  if (v == null) return d;
  return String(v);
};

const VALID_METHODS = ['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Card', 'Other'];

/** True when a row carries no data at all (the always-present blank entry row).
 *  `unit` is ignored — the items editor prefills it (e.g. "PCS") on every new row. */
function isEmptyItem(o: Raw): boolean {
  const has = (k: string) => {
    const v = o[k];
    if (typeof v === 'number') return v !== 0;
    if (typeof v === 'string') return v.trim() !== '';
    return false;
  };
  return !has('desc') && !has('description') && !has('name') && !has('hsn')
    && !num(o.qty) && !num(o.rate) && !num(o.amount);
}

/** Coerce arbitrary input into a well-formed BillItem (id always present). */
export function sanitizeItem(raw: unknown): BillItem | null {
  const o = (raw ?? {}) as Raw;
  // silently drop completely empty rows (blank entry line in the items editor)
  if (isEmptyItem(o)) return null;
  const item: BillItem = {
    id: str(o.id) || uid('it'),
    desc: str(o.desc ?? o.description ?? o.name),
    hsn: str(o.hsn),
    qty: num(o.qty),
    unit: str(o.unit, 'PCS'),
    rate: num(o.rate),
    gst: Math.max(0, Math.min(50, num(o.gst, 0))),
    discPct: Math.max(0, Math.min(100, num(o.discPct, 0))),
  };
  // preserve template-defined custom columns (string/number extras)
  for (const [k, v] of Object.entries(o)) {
    if (k in item && k !== 'discPct') continue;
    if (typeof v === 'string' || typeof v === 'number') item[k] = v;
  }
  return item;
}

export function sanitizeItems(raw: unknown): BillItem[] {
  if (!Array.isArray(raw)) return [];
  return raw.map(sanitizeItem).filter((it): it is BillItem => it !== null);
}

export function sanitizePayment(raw: unknown): BillPayment {
  const o = (raw ?? {}) as Raw;
  const method = str(o.method, 'Cash');
  const matched = VALID_METHODS.find((m) => m.toLowerCase() === method.toLowerCase());
  return {
    id: str(o.id) || uid('pay'),
    date: str(o.date) || new Date().toISOString().slice(0, 10),
    amount: Math.max(0, num(o.amount)),
    method: (matched ?? 'Other') as PaymentMethod,
    reference: o.reference ? str(o.reference) : undefined,
    note: o.note ? str(o.note) : undefined,
  };
}

export function sanitizePayments(raw: unknown): BillPayment[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  return raw.map(sanitizePayment);
}

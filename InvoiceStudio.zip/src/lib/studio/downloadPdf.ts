'use client';

/* ============================================================
 * InvoiceStudio — client helper for server-side PDF export
 * Posts to /api/pdf and saves the response as a download.
 * ============================================================ */

export interface PdfRequestBody {
  kind: 'bill' | 'receipt' | 'statement';
  billId?: string;
  paymentId?: string;
  receiptNo?: string;
  copies?: number;
  includeStamp?: boolean;
  buyerName?: string;
  buyerId?: string;
  from?: string;
  to?: string;
}

/** POST /api/pdf and trigger a browser download of the returned file.
 *  Throws an Error with a user-safe message on failure. */
export async function downloadPdf(body: PdfRequestBody, filename: string): Promise<void> {
  let res: Response;
  try {
    res = await fetch('/api/pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error('Could not reach the PDF service.');
  }
  if (!res.ok) {
    let msg = `PDF export failed (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch { /* keep default */ }
    throw new Error(msg);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

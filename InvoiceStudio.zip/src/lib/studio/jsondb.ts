/* ============================================================
 * InvoiceStudio — JSON file database
 * Simple, dependency-free persistence in /db/*.json
 * Uses per-file write locks + atomic tmp/rename writes.
 * ============================================================ */
import { promises as fs } from 'fs';
import path from 'path';

const DATA_DIR = path.join(process.cwd(), 'db');

const locks = new Map<string, Promise<unknown>>();

async function ensureDir(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

export async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(path.join(DATA_DIR, file), 'utf-8');
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/** Serialize writes per file; atomic rename so readers never see partial data. */
export async function writeJson<T>(file: string, value: T): Promise<void> {
  await ensureDir();
  const filePath = path.join(DATA_DIR, file);
  const prev = locks.get(file) ?? Promise.resolve();
  const next = prev.then(async () => {
    // unique tmp name: pid + time + random — concurrent writers never collide
    const tmp = `${filePath}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2, 8)}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(value, null, 2), 'utf-8');
    await fs.rename(tmp, filePath);
  });
  // keep chain alive even if a write fails
  locks.set(file, next.catch(() => undefined));
  await next;
}

/** Mutate helper: read -> transform -> write under the same lock. */
export async function updateJson<T>(
  file: string,
  fallback: T,
  mutate: (current: T) => T | Promise<T>,
): Promise<T> {
  await ensureDir();
  const filePath = path.join(DATA_DIR, file);
  const prev = locks.get(file) ?? Promise.resolve();
  const run = async (): Promise<T> => {
    let current = fallback;
    try {
      current = JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
    } catch {
      /* first run or corrupt file -> fallback */
    }
    const nextVal = await mutate(current);
    const tmp = `${filePath}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2, 8)}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(nextVal, null, 2), 'utf-8');
    await fs.rename(tmp, filePath);
    return nextVal;
  };
  const next = prev.then(run, run);
  locks.set(file, next.catch(() => undefined));
  return next;
}

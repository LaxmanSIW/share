/* Type declarations for the bundler alias defined in next.config.ts:
 * 'react-dom/server-static' → next/dist/compiled/react-dom/server.node.js
 * (used by the server-side PDF engine to render React trees to HTML). */
declare module 'react-dom/server-static' {
  import type { ReactNode } from 'react';
  export function renderToString(node: ReactNode): string;
  export function renderToStaticMarkup(node: ReactNode): string;
  export const version: string;
}

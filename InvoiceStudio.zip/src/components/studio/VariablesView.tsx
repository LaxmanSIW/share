'use client';

/* ============================================================
 * InvoiceStudio — custom variables manager
 * ============================================================ */
import React, { useState } from 'react';
import { Plus, Trash2, Variable } from 'lucide-react';
import type { BuyerFieldDef, VariableDef } from '@/lib/studio/types';
import { BUILTIN_BILL_VARS } from '@/lib/studio/defaults';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface Props {
  customVars: VariableDef[];
  buyerFields?: BuyerFieldDef[];
  onReload: () => void;
}

export default function VariablesView({ customVars, buyerFields, onReload }: Props) {
  const { toast } = useToast();
  const [label, setLabel] = useState('');
  const [key, setKey] = useState('');
  const [type, setType] = useState<VariableDef['type']>('text');
  const [busy, setBusy] = useState(false);

  const slugify = (s: string) =>
    s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');

  const add = async () => {
    const k = (key || slugify(label)).trim();
    if (!k || !label.trim()) {
      toast({ title: 'Missing fields', description: 'Enter a label (and key or auto-generate it).', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/variables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: k, label: label.trim(), type }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'failed');
      toast({ title: 'Variable added', description: `{{${k}}} is now available in every template.` });
      setLabel(''); setKey(''); setType('text');
      onReload();
    } catch (e) {
      toast({ title: 'Could not add variable', description: e instanceof Error ? e.message : 'Error', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (k: string) => {
    const res = await fetch(`/api/variables/${k}`, { method: 'DELETE' });
    if (res.ok) {
      toast({ title: 'Variable removed', description: `{{${k}}} deleted.` });
      onReload();
    } else {
      toast({ title: 'Delete failed', variant: 'destructive' });
    }
  };

  return (
    <div className="studio-scroll flex-1 overflow-y-auto p-5">
      <div className="mx-auto max-w-3xl space-y-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-zinc-100">Variables</h1>
          <p className="mt-0.5 text-xs text-zinc-500">
            Variables are placeholders you drop into templates — they get filled with real values when a bill is created.
          </p>
        </div>

        {/* add form */}
        <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Add custom variable</h2>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="flex-1">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Label *</Label>
              <Input
                className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]"
                placeholder="e.g. Delivery Date"
                value={label}
                onChange={(e) => {
                  setLabel(e.target.value);
                  if (!key) setKey(slugify(e.target.value));
                }}
              />
            </div>
            <div className="flex-1">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Key (placeholder)</Label>
              <div className="mt-1 flex items-center gap-1.5">
                <span className="text-xs text-zinc-600">{'{{'}</span>
                <Input
                  className="h-9 border-[#2a3342] bg-[#0d1117] font-mono text-xs"
                  placeholder="delivery_date"
                  value={key}
                  onChange={(e) => setKey(e.target.value.replace(/[^a-z0-9_]/g, '_').toLowerCase())}
                />
                <span className="text-xs text-zinc-600">{'}' + '}'}</span>
              </div>
            </div>
            <div className="w-full sm:w-32">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Type</Label>
              <Select value={type} onValueChange={(v) => setType(v as VariableDef['type'])}>
                <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                  <SelectItem value="text" className="text-xs">Text</SelectItem>
                  <SelectItem value="number" className="text-xs">Number</SelectItem>
                  <SelectItem value="date" className="text-xs">Date</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="h-9 gap-1.5 bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055]" disabled={busy} onClick={add}>
              <Plus className="h-4 w-4" /> Add
            </Button>
          </div>
        </div>

        {/* built-in list */}
        <div className="overflow-hidden rounded-lg border border-[#232b38]">
          <div className="border-b border-[#232b38] bg-[#12161d] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
            Built-in bill variables
          </div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-2 bg-[#10141b] p-4 sm:grid-cols-2 lg:grid-cols-3">
            {BUILTIN_BILL_VARS.map((v) => (
              <div key={v.key} className="flex items-center justify-between gap-2 text-xs">
                <span className="text-zinc-300">{v.label}</span>
                <code className="rounded bg-[#1a212c] px-1.5 py-0.5 font-mono text-[10px] text-[#d9a13b]">{`{{${v.key}}}`}</code>
              </div>
            ))}
          </div>
          <div className="border-t border-[#232b38] bg-[#10141b] px-4 py-2 text-[10px] text-zinc-600">
            Plus computed totals: {'{{subtotal}} {{cgst}} {{sgst}} {{igst}} {{grand_total}} {{amount_in_words}} {{invoice_no}} {{invoice_date}}…'}
          </div>
        </div>

        {/* buyer custom fields (read-only, defined in Settings) */}
        {(buyerFields ?? []).length > 0 && (
          <div className="overflow-hidden rounded-lg border border-[#232b38]">
            <div className="border-b border-[#232b38] bg-[#12161d] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
              Buyer custom fields · {(buyerFields ?? []).length} <span className="ml-1 normal-case tracking-normal text-zinc-600">(defined in Settings)</span>
            </div>
            <div className="grid grid-cols-1 gap-x-6 gap-y-2 bg-[#10141b] p-4 sm:grid-cols-2 lg:grid-cols-3">
              {(buyerFields ?? []).map((f) => (
                <div key={f.key} className="flex items-center justify-between gap-2 text-xs">
                  <span className="text-zinc-300">{f.label} <span className="text-[9px] uppercase text-zinc-600">{f.type}</span></span>
                  <code className="rounded bg-[#1a212c] px-1.5 py-0.5 font-mono text-[10px] text-[#d9a13b]">{`{{buyer_${f.key}}}`}</code>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* custom list */}
        <div className="overflow-hidden rounded-lg border border-[#232b38]">
          <div className="border-b border-[#232b38] bg-[#12161d] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
            Your custom variables · {customVars.length}
          </div>
          {customVars.length === 0 ? (
            <div className="flex flex-col items-center gap-2 p-8 text-center">
              <Variable className="h-7 w-7 text-zinc-700" />
              <p className="text-xs text-zinc-600">No custom variables yet. Add one above — it will appear in the designer and in the bill form.</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <tbody>
                {customVars.map((v) => (
                  <tr key={v.key} className="border-b border-[#1a212c] last:border-0 hover:bg-[#151b25]">
                    <td className="px-4 py-2.5 text-zinc-200">{v.label}</td>
                    <td className="px-4 py-2.5">
                      <code className="rounded bg-[#1a212c] px-1.5 py-0.5 font-mono text-[10px] text-[#d9a13b]">{`{{${v.key}}}`}</code>
                    </td>
                    <td className="px-4 py-2.5 text-[10px] uppercase tracking-wider text-zinc-600">{v.type}</td>
                    <td className="px-4 py-2.5 text-right">
                      <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-red-400" onClick={() => remove(v.key)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

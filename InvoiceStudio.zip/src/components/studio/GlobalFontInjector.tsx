'use client';

import { useEffect } from 'react';
import type { CustomFontDef } from '@/lib/studio/types';
import { generateFontCss } from '@/lib/studio/fonts';

interface Props {
  customFonts?: CustomFontDef[];
}

export default function GlobalFontInjector({ customFonts }: Props) {
  useEffect(() => {
    const css = generateFontCss(customFonts);
    let el = document.getElementById('invoicestudio-dynamic-fonts') as HTMLStyleElement | null;

    if (!css) {
      if (el) el.remove();
      return;
    }

    if (!el) {
      el = document.createElement('style');
      el.id = 'invoicestudio-dynamic-fonts';
      document.head.appendChild(el);
    }

    el.textContent = css;
  }, [customFonts]);

  return null;
}

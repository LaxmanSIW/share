'use client';

/* ============================================================
 * InvoiceStudio — buyer master
 * Saved buyers with billing stats, search, add/edit/delete
 * ============================================================ */
import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle, Building2, CheckCircle2, Download, FileDown, FileSpreadsheet,
  HandCoins, ListPlus, Loader2, NotebookText, Pencil, Plus, Search, Trash2, Upload, X, XCircle,
} from 'lucide-react';
import type { Bill, Buyer, BuyerFieldDef } from '@/lib/studio/types';
import { billStatus, docTypeOf, DOC_TYPE_META, dueAmount, fmtDate, fmtMoney, paidAmount, STATUS_META } from '@/lib/studio/format';
import { downloadPdf } from '@/lib/studio/downloadPdf';
import {
  BUYER_CSV_COLUMNS, isValidGstin, isValidPhone, looksLikeHeader, mapBuyerHeader, parseCsv,
} from '@/lib/studio/csv';
import type { BuyerColMap } from '@/lib/studio/csv';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

interface Props {
  buyers: Buyer[];
  bills: Bill[];
  currency: string;
  buyerFields: BuyerFieldDef[];
  onChanged: () => void;
}

interface BuyerForm {
  name: string;
  address: string;
  gst: string;
  phone: string;
  state: string;
  custom: Record<string, string>;
}

const EMPTY: BuyerForm = { name: '', address: '', gst: '', phone: '', state: '', custom: {} };

/* ---------------- bulk CSV import ---------------- */

type ImportStep = 'pick' | 'review' | 'done';
type RowStatus = 'ok' | 'warn' | 'error';
type BuyerCol = (typeof BUYER_CSV_COLUMNS)[number];

interface PreviewRow {
  line: number; // 1-based row number as it appears in the spreadsheet
  name: string;
  address: string;
  gst: string;
  phone: string;
  state: string;
  custom: Record<string, string>; // custom buyer-field values keyed by field key
  saved: boolean; // matches an already-saved buyer
  status: RowStatus;
  messages: string[];
}

interface ImportCounts {
  created: number;
  updated: number;
  skipped: number;
  failed: number;
  errors: { row: number; name: string; reason: string }[];
}

export default function BuyersView({ buyers, bills, currency, buyerFields, onChanged }: Props) {
  const { toast } = useToast();
  const [q, setQ] = useState('');
  const [editing, setEditing] = useState<Buyer | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<BuyerForm>(EMPTY);
  const [deleting, setDeleting] = useState<Buyer | null>(null);
  const [saving, setSaving] = useState(false);
  const [ledgerFor, setLedgerFor] = useState<Buyer | null>(null);
  const [statementBusy, setStatementBusy] = useState(false);

  /* bulk CSV import state */
  const [importOpen, setImportOpen] = useState(false);
  const [importStep, setImportStep] = useState<ImportStep>('pick');
  const [importFile, setImportFile] = useState('');
  const [importNote, setImportNote] = useState<string | null>(null);
  const [previewRows, setPreviewRows] = useState<PreviewRow[]>([]);
  const [parseError, setParseError] = useState<string | null>(null);
  const [importMode, setImportMode] = useState<'skip' | 'update'>('skip');
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportCounts | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  /** server-side PDF export of the buyer's full account statement */
  const exportStatement = async () => {
    if (!ledgerFor) return;
    setStatementBusy(true);
    try {
      await downloadPdf({ kind: 'statement', buyerName: ledgerFor.name }, `Statement-${ledgerFor.name}.pdf`);
      toast({ title: 'Statement PDF downloaded', description: `${ledgerFor.name} · all documents with balances & aging` });
    } catch (e) {
      toast({ title: 'Statement export failed', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setStatementBusy(false);
    }
  };

  /* ---------------- bulk CSV import ---------------- */

  const resetImport = () => {
    setImportStep('pick');
    setImportFile('');
    setImportNote(null);
    setPreviewRows([]);
    setParseError(null);
    setImportMode('skip');
    setImportResult(null);
    setDragOver(false);
  };

  const openImport = () => { resetImport(); setImportOpen(true); };

  /** parse CSV text → validated preview rows (client-side convenience; the server re-validates) */
  const buildPreview = (text: string): { rows: PreviewRow[]; note?: string } => {
    const matrix = parseCsv(text).filter((r) => r.some((c) => c.trim() !== ''));
    if (matrix.length === 0) return { rows: [] };
    let cols: BuyerColMap[] | null = null;
    let note: string | undefined;
    let dataRows = matrix;
    if (looksLikeHeader(matrix[0])) {
      cols = mapBuyerHeader(matrix[0], buyerFields);
      dataRows = matrix.slice(1);
      const unknown = matrix[0].filter((c, i) => !cols![i] && c.trim() !== '').length;
      const customCols = cols.filter((c) => typeof c === 'object' && c !== null).length;
      if (customCols > 0) {
        note = `${customCols} custom field column${customCols > 1 ? 's' : ''} matched — values will be saved on each buyer.`
          + (unknown > 0 ? ` ${unknown} unrecognised column${unknown > 1 ? 's were' : ' was'} ignored.` : '');
      } else if (unknown > 0) {
        note = `${unknown} unrecognised column${unknown > 1 ? 's were' : ' was'} ignored.`;
      }
      if (!cols.some((c) => c === 'name')) {
        note = 'Header row has no “name” column — every row will fail validation.';
      }
    }
    if (dataRows.length > 1000) {
      setParseError(`Too many rows — the limit is 1,000 buyers per import (file has ${dataRows.length}).`);
      return { rows: [] };
    }
    const savedNames = new Set(buyers.map((b) => b.name.trim().toLowerCase()));
    const seen = new Map<string, number>();
    const rows: PreviewRow[] = [];
    for (let i = 0; i < dataRows.length; i++) {
      const cells = dataRows[i];
      const custom: Record<string, string> = {};
      const get = (col: BuyerCol) => {
        if (!cols) return (cells[BUYER_CSV_COLUMNS.indexOf(col)] ?? '').trim();
        const idx = cols.indexOf(col);
        return idx >= 0 ? (cells[idx] ?? '').trim() : '';
      };
      // collect custom-field values by their keys
      if (cols) {
        cols.forEach((c, ci) => {
          if (c && typeof c === 'object') {
            const v = (cells[ci] ?? '').trim();
            if (v) custom[c.custom] = v;
          }
        });
      }
      const name = get('name');
      const gst = get('gst').toUpperCase();
      const phone = get('phone');
      const messages: string[] = [];
      let status: RowStatus = 'ok';
      if (!name) {
        status = 'error';
        messages.push('Buyer name is required');
      } else if (gst && !isValidGstin(gst)) {
        status = 'error';
        messages.push('Invalid GSTIN format');
      } else {
        if (phone && !isValidPhone(phone)) {
          status = 'warn';
          messages.push('Phone doesn’t look like an Indian mobile number');
        }
        const key = name.toLowerCase();
        const firstIdx = seen.get(key);
        if (firstIdx !== undefined) {
          const first = rows[firstIdx];
          if (!first.messages.some((m) => m.startsWith('Duplicate name'))) {
            first.messages.unshift('Duplicate name in file — only the last row is imported');
            if (first.status === 'ok') first.status = 'warn';
          }
          messages.push('Duplicate name — this row overrides the earlier one');
          if (status === 'ok') status = 'warn';
        } else {
          seen.set(key, rows.length);
        }
      }
      rows.push({
        line: i + (cols ? 2 : 1),
        name,
        address: get('address'),
        gst,
        phone,
        state: get('state'),
        custom,
        saved: savedNames.has(name.toLowerCase()),
        status,
        messages,
      });
    }
    return { rows, note };
  };

  const loadFile = async (file: File) => {
    setParseError(null);
    if (file.size > 2 * 1024 * 1024) {
      setParseError('File is too large — maximum 2 MB.');
      return;
    }
    try {
      const text = await file.text();
      const { rows, note } = buildPreview(text);
      if (rows.length === 0) {
        setParseError((p) => p ?? 'No buyer rows found in this file.');
        return;
      }
      setImportFile(file.name);
      setImportNote(note ?? null);
      setPreviewRows(rows);
      setImportStep('review');
    } catch {
      setParseError('Could not read this file — make sure it is a plain .csv file.');
    }
  };

  const counts = useMemo(() => {
    let ok = 0, warn = 0, error = 0, saved = 0;
    for (const r of previewRows) {
      if (r.status === 'ok') ok++;
      else if (r.status === 'warn') warn++;
      else error++;
      if (r.saved) saved++;
    }
    return { ok, warn, error, saved, total: previewRows.length, importable: ok + warn };
  }, [previewRows]);

  const runImport = async () => {
    const rows = previewRows
      .filter((r) => r.status !== 'error')
      .map((r) => ({ name: r.name, address: r.address, gst: r.gst, phone: r.phone, state: r.state, custom: r.custom }));
    if (rows.length === 0) return;
    setImporting(true);
    try {
      const res = await fetch('/api/buyers/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows, mode: importMode }),
      });
      const data = (await res.json()) as ImportCounts & { error?: string };
      if (!res.ok) throw new Error(data.error || 'Import failed');
      setImportResult(data);
      setImportStep('done');
      onChanged();
      toast({
        title: `Import finished — ${data.created} created, ${data.updated} updated`,
        description: data.skipped + data.failed > 0 ? `${data.skipped} skipped · ${data.failed} failed` : undefined,
      });
    } catch (e) {
      toast({ title: 'Import failed', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setImporting(false);
    }
  };

  const stats = useMemo(() => {
    const map = new Map<string, { count: number; amount: number; last: string }>();
    for (const b of bills) {
      const name = (b.variables['buyer_name'] ?? '').trim();
      if (!name) continue;
      const cur = map.get(name.toLowerCase()) ?? { count: 0, amount: 0, last: b.date };
      map.set(name.toLowerCase(), {
        count: cur.count + 1,
        amount: cur.amount + b.totals.grandTotal,
        last: b.date > cur.last ? b.date : cur.last,
      });
    }
    return map;
  }, [bills]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return buyers;
    return buyers.filter((b) =>
      [b.name, b.gst, b.phone, b.address, b.state].join(' ').toLowerCase().includes(needle),
    );
  }, [buyers, q]);

  /** the ledger buyer's invoices (newest first) + totals */
  const ledger = useMemo(() => {
    if (!ledgerFor) return null;
    const docs = bills
      .filter((b) => (b.variables['buyer_name'] ?? '').trim().toLowerCase() === ledgerFor.name.trim().toLowerCase())
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    const invoices = docs.filter((b) => docTypeOf(b) === 'invoice' && billStatus(b) !== 'cancelled');
    return {
      docs,
      billed: invoices.reduce((s, b) => s + b.totals.grandTotal, 0),
      received: invoices.reduce((s, b) => s + paidAmount(b), 0),
      outstanding: invoices.reduce((s, b) => s + dueAmount(b), 0),
    };
  }, [ledgerFor, bills]);

  const openCreate = () => { setForm(EMPTY); setCreating(true); };
  const openEdit = (b: Buyer) => {
    setForm({ name: b.name, address: b.address, gst: b.gst, phone: b.phone, state: b.state, custom: { ...b.custom } });
    setEditing(b);
  };

  const save = async () => {
    if (!form.name.trim()) {
      toast({ title: 'Name is required', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(editing ? `/api/buyers/${editing.id}` : '/api/buyers', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, custom: form.custom }),
      });
      if (!res.ok) throw new Error();
      toast({ title: editing ? 'Buyer updated' : 'Buyer added', description: form.name });
      setEditing(null);
      setCreating(false);
      onChanged();
    } catch {
      toast({ title: 'Save failed', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async () => {
    if (!deleting) return;
    const res = await fetch(`/api/buyers/${deleting.id}`, { method: 'DELETE' });
    if (res.ok) {
      toast({ title: 'Buyer removed', description: `${deleting.name} deleted from the buyer list.` });
      onChanged();
    } else {
      toast({ title: 'Delete failed', variant: 'destructive' });
    }
    setDeleting(null);
  };

  const dialogOpen = creating || !!editing;

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#232b38] bg-[#0f1319] px-4 py-2.5">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-600" />
          <Input
            className="h-8 w-64 border-[#2a3342] bg-[#0d1117] pl-8 text-xs"
            placeholder="Search buyers…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          {q && (
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-300" onClick={() => setQ('')}>
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
        <span className="text-xs text-zinc-500">{filtered.length} buyers</span>
        <div className="ml-auto flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-8 gap-1.5 border-[#d9a13b]/40 bg-transparent text-xs text-[#e8c064] hover:bg-[#d9a13b]/10 hover:text-[#e8c064]"
            title="Bulk-add buyers from a CSV file — sample included"
            onClick={openImport}
          >
            <Upload className="h-3.5 w-3.5" /> Import CSV
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 gap-1.5 border-[#2a3342] bg-transparent text-xs text-zinc-400 hover:bg-[#1a212c] hover:text-zinc-200"
            disabled={buyers.length === 0}
            title="Export every buyer as CSV — edit in Excel and re-import"
            onClick={() => window.open('/api/buyers/export', '_blank', 'noopener')}
          >
            <Download className="h-3.5 w-3.5" /> Export
          </Button>
          <Button size="sm" className="h-8 gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]" onClick={openCreate}>
            <Plus className="h-3.5 w-3.5" /> Add buyer
          </Button>
        </div>
      </div>

      {/* list */}
      <div className="studio-scroll flex-1 overflow-auto p-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-[#2a3342] py-16 text-center">
            <Building2 className="h-10 w-10 text-zinc-700" />
            <div>
              <p className="text-sm font-medium text-zinc-300">No buyers yet</p>
              <p className="mt-1 text-xs text-zinc-600">
                Buyers are saved automatically when you tick “save buyer” while billing — add one
                here, or import your whole list from a CSV file.
              </p>
            </div>
            <div className="mt-1 flex items-center gap-2">
              <Button size="sm" className="gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]" onClick={openCreate}>
                <Plus className="h-3.5 w-3.5" /> Add your first buyer
              </Button>
              <Button size="sm" variant="outline" className="gap-1.5 border-[#d9a13b]/40 bg-transparent text-xs text-[#e8c064] hover:bg-[#d9a13b]/10" onClick={openImport}>
                <Upload className="h-3.5 w-3.5" /> Import CSV
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((b) => {
              const st = stats.get(b.name.trim().toLowerCase());
              return (
                <div
                  key={b.id}
                  className="group rounded-lg border border-[#232b38] bg-[#12161d] p-4 transition-all hover:-translate-y-0.5 hover:border-[#39445a] hover:shadow-[0_6px_24px_rgba(0,0,0,0.35)]"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded bg-[#1d2430] text-[11px] font-bold text-[#d9a13b]">
                        {b.name.slice(0, 2).toUpperCase()}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-zinc-100">{b.name}</p>
                        <p className="font-mono text-[10px] text-zinc-600">{b.gst || 'No GSTIN'}</p>
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-0.5 opacity-60 transition-opacity group-hover:opacity-100">
                      <Button variant="ghost" size="icon" className="h-7 w-7" title="Edit" onClick={() => openEdit(b)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-red-400" title="Delete" onClick={() => setDeleting(b)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  {b.address && (
                    <p className="mt-2.5 line-clamp-2 whitespace-pre-wrap text-[11px] leading-relaxed text-zinc-500">{b.address}</p>
                  )}
                  {(() => {
                    const filled = buyerFields.filter((f) => (b.custom?.[f.key] ?? '').trim() !== '');
                    if (filled.length === 0) return null;
                    return (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {filled.slice(0, 3).map((f) => (
                          <span key={f.key} className="rounded border border-[#2a3342] bg-[#0f1319] px-1.5 py-0.5 text-[9px] text-zinc-400" title={`${f.label}: ${b.custom?.[f.key]}`}>
                            <span className="text-zinc-600">{f.label}:</span> <span className="text-zinc-300">{b.custom?.[f.key]}</span>
                          </span>
                        ))}
                        {filled.length > 3 && (
                          <span className="rounded border border-[#2a3342] bg-[#0f1319] px-1.5 py-0.5 text-[9px] text-zinc-500" title={filled.slice(3).map((f) => `${f.label}: ${b.custom?.[f.key]}`).join('\n')}>
                            +{filled.length - 3} more
                          </span>
                        )}
                      </div>
                    );
                  })()}
                  <div className="mt-3 flex items-center gap-3 border-t border-[#1a212c] pt-3">
                    <div>
                      <p className="text-[9px] uppercase tracking-wider text-zinc-600">Bills</p>
                      <p className="tabular text-xs font-semibold text-zinc-200">{st?.count ?? 0}</p>
                    </div>
                    <div>
                      <p className="text-[9px] uppercase tracking-wider text-zinc-600">Billed</p>
                      <p className="tabular text-xs font-semibold text-[#d9a13b]">{fmtMoney(st?.amount ?? 0, currency)}</p>
                    </div>
                    <div className="ml-auto text-right">
                      <p className="text-[9px] uppercase tracking-wider text-zinc-600">Phone</p>
                      <p className="text-xs text-zinc-400">{b.phone || '—'}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md border border-[#2a3342] py-1.5 text-[11px] font-medium text-zinc-400 transition-colors hover:border-[#d9a13b]/50 hover:bg-[#d9a13b]/5 hover:text-[#e8c064]"
                    onClick={() => setLedgerFor(b)}
                  >
                    <NotebookText className="h-3.5 w-3.5" /> Open ledger
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* add / edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { if (!o) { setEditing(null); setCreating(false); } }}>
        <DialogContent className="max-w-lg border-[#2a3342] bg-[#12161d] text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] pb-3">
            <DialogTitle className="text-sm">{editing ? `Edit ${editing.name}` : 'Add buyer'}</DialogTitle>
            <DialogDescription className="sr-only">
              Buyer details are reused to autofill the bill form.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Buyer name *</Label>
              <Input className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Address</Label>
              <Textarea className="mt-1 min-h-[56px] border-[#2a3342] bg-[#0d1117] text-sm" value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} />
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">GSTIN</Label>
              <Input className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] font-mono text-sm uppercase" value={form.gst} onChange={(e) => setForm((f) => ({ ...f, gst: e.target.value.toUpperCase() }))} />
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Phone</Label>
              <Input className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">State (place of supply)</Label>
              <Input className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]" value={form.state} onChange={(e) => setForm((f) => ({ ...f, state: e.target.value }))} />
            </div>
            {buyerFields.length > 0 && (
              <div className="sm:col-span-2">
                <Separator className="my-1 bg-[#232b38]" />
                <p className="mb-2 mt-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                  <ListPlus className="h-3 w-3 text-[#d9a13b]" /> Custom fields
                  <span className="ml-auto font-normal normal-case tracking-normal text-zinc-600">defined in Settings → Buyer Custom Fields</span>
                </p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {buyerFields.map((f) => (
                    <div key={f.key}>
                      <Label className="text-[10px] uppercase tracking-wider text-zinc-500">{f.label}</Label>
                      <Input
                        type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                        inputMode={f.type === 'number' ? 'decimal' : undefined}
                        aria-label={f.label}
                        className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm"
                        value={form.custom[f.key] ?? ''}
                        onChange={(e) => setForm((s) => ({ ...s, custom: { ...s.custom, [f.key]: e.target.value } }))}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center justify-end gap-2 border-t border-[#232b38] pt-3">
            <Button variant="outline" className="h-8 border-[#2a3342] text-xs" onClick={() => { setEditing(null); setCreating(false); }}>
              Cancel
            </Button>
            <Button className="h-8 gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]" disabled={saving} onClick={save}>
              {editing ? 'Save changes' : 'Add buyer'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* buyer ledger */}
      <Dialog open={!!ledgerFor} onOpenChange={(o) => !o && setLedgerFor(null)}>
        <DialogContent className="max-h-[88vh] max-w-2xl border-[#2a3342] bg-[#12161d] p-0 text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] px-5 py-3">
            <DialogTitle className="flex items-center justify-between gap-3 text-sm">
              <span className="flex min-w-0 items-center gap-2">
                <NotebookText className="h-4 w-4 text-[#d9a13b]" /> Ledger — {ledgerFor?.name}
                {ledgerFor?.gst && <span className="font-mono text-[10px] font-normal text-zinc-600">{ledgerFor.gst}</span>}
              </span>
              {ledgerFor && (
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1.5 border-sky-500/40 text-xs text-sky-300 hover:bg-sky-500/10"
                  title="Download a PDF account statement — all documents, receipts, balances & aging"
                  disabled={statementBusy}
                  onClick={exportStatement}
                >
                  <FileDown className={`h-3.5 w-3.5 ${statementBusy ? 'animate-pulse' : ''}`} /> Statement PDF
                </Button>
              )}
            </DialogTitle>
            <DialogDescription className="sr-only">
              All documents for this buyer with balances, receipts and aging.
            </DialogDescription>
          </DialogHeader>
          <div className="studio-scroll max-h-[calc(88vh-4rem)] overflow-auto p-5">
            {ledger && (
              <>
                <div className="grid grid-cols-3 gap-3">
                  <LedgerTile label="Total billed" value={fmtMoney(ledger.billed, currency)} tone="gold" />
                  <LedgerTile label="Received" value={fmtMoney(ledger.received, currency)} tone="green" />
                  <LedgerTile label="Outstanding" value={fmtMoney(ledger.outstanding, currency)} tone="amber" />
                </div>
                <div className="mt-4 overflow-hidden rounded-lg border border-[#232b38]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#232b38] bg-[#10141b] text-left text-[9px] uppercase tracking-wider text-zinc-500">
                        <th className="px-3 py-2 font-medium">Doc</th>
                        <th className="px-3 py-2 font-medium">Date</th>
                        <th className="px-3 py-2 text-center font-medium">Status</th>
                        <th className="px-3 py-2 text-right font-medium">Total</th>
                        <th className="px-3 py-2 text-right font-medium">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ledger.docs.length === 0 && (
                        <tr>
                          <td colSpan={5} className="px-3 py-6 text-center text-xs text-zinc-600">No bills for this buyer yet.</td>
                        </tr>
                      )}
                      {ledger.docs.map((b) => {
                        const st = billStatus(b);
                        const meta = STATUS_META[st];
                        const dmeta = DOC_TYPE_META[docTypeOf(b)];
                        const due = dueAmount(b);
                        return (
                          <tr key={b.id} className="border-b border-[#1a212c] last:border-0">
                            <td className="px-3 py-2">
                              <div className="flex items-center gap-1.5">
                                <span className={`inline-flex shrink-0 items-center rounded border px-1.5 py-px font-mono text-[8px] font-bold uppercase tracking-wider ${dmeta.cls}`}>
                                  {dmeta.short}
                                </span>
                                <span className="font-mono text-[11px] font-semibold text-[#e8c064]">{b.billNo}</span>
                              </div>
                            </td>
                            <td className="px-3 py-2 text-[11px] text-zinc-400">{fmtDate(b.date)}</td>
                            <td className="px-3 py-2 text-center">
                              <span className={`inline-flex items-center gap-1 rounded-full border px-1.5 py-px text-[8px] font-semibold uppercase tracking-wider ${meta.cls}`}>
                                <span className={`h-1 w-1 rounded-full ${meta.dot}`} /> {meta.label}
                              </span>
                            </td>
                            <td className="tabular px-3 py-2 text-right text-[11px] font-semibold text-zinc-200">
                              {fmtMoney(b.totals.grandTotal, currency)}
                            </td>
                            <td className={`tabular px-3 py-2 text-right text-[11px] font-semibold ${docTypeOf(b) === 'invoice' && due > 0 ? 'text-amber-300' : 'text-emerald-400'}`}>
                              {docTypeOf(b) === 'invoice' ? fmtMoney(due, currency) : '—'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                {/* receipts timeline */}
                {ledger.docs.some((b) => (b.payments?.length ?? 0) > 0) && (
                  <div className="mt-4">
                    <p className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                      <HandCoins className="h-3.5 w-3.5 text-emerald-400" /> Receipts
                    </p>
                    <div className="space-y-1.5">
                      {ledger.docs.flatMap((b) =>
                        (b.payments ?? []).map((p) => (
                          <div
                            key={p.id}
                            className="flex items-center gap-3 rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-1.5 text-[11px]"
                          >
                            <span className="w-20 shrink-0 text-zinc-500">{fmtDate(p.date)}</span>
                            <span className="font-semibold text-zinc-200">{p.method}</span>
                            {p.reference && <span className="truncate font-mono text-[10px] text-zinc-600">{p.reference}</span>}
                            <span className="ml-auto shrink-0 text-zinc-600">{b.billNo}</span>
                            <span className="tabular w-24 shrink-0 text-right font-semibold text-emerald-300">
                              {fmtMoney(p.amount, currency)}
                            </span>
                          </div>
                        )),
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* bulk CSV import wizard */}
      <Dialog open={importOpen} onOpenChange={(o) => { if (!o) { setImportOpen(false); resetImport(); } }}>
        <DialogContent className="max-h-[90vh] w-[calc(100vw-2rem)] sm:max-w-3xl overflow-y-auto border-[#2a3342] bg-[#12161d] text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] pb-3">
            <DialogTitle className="flex items-center gap-2 text-sm">
              <Upload className="h-4 w-4 text-[#d9a13b]" /> Import buyers from CSV
            </DialogTitle>
            <DialogDescription>
              Bulk-add buyers from a spreadsheet — review before import, then skip or update existing ones.
            </DialogDescription>
          </DialogHeader>

          {importStep === 'pick' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {/* format guide */}
                <div className="rounded-lg border border-[#232b38] bg-[#0f1319] p-3">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">File format</p>
                  <ul className="mt-2 space-y-1 text-[11px] leading-relaxed text-zinc-400">
                    <li><span className="font-mono text-[#e8c064]">name</span> <span className="text-amber-400">*</span> — required</li>
                    <li><span className="font-mono text-[#e8c064]">address</span> — wrap commas in “quotes”</li>
                    <li><span className="font-mono text-[#e8c064]">gst</span> — 15-character GSTIN</li>
                    <li><span className="font-mono text-[#e8c064]">phone</span> — 10-digit mobile</li>
                    <li><span className="font-mono text-[#e8c064]">state</span> — place of supply</li>
                  </ul>
                  {buyerFields.length > 0 && (
                    <p className="mt-2 text-[10px] leading-relaxed text-amber-300/70">
                      Custom columns by label also import: <span className="font-mono">{buyerFields.map((f) => f.label).join(', ')}</span>
                    </p>
                  )}
                  <p className="mt-2 text-[10px] leading-relaxed text-zinc-600">
                    Column order doesn’t matter when a header row is present — common aliases
                    like <span className="font-mono">GSTIN</span> / <span className="font-mono">mobile</span> are recognised.
                  </p>
                </div>
                {/* sample file */}
                <div className="flex flex-col justify-between gap-3 rounded-lg border border-[#232b38] bg-[#0f1319] p-3">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">Start from a sample</p>
                    <p className="mt-1.5 text-[11px] leading-relaxed text-zinc-500">
                      Download the sample file, replace the demo rows with your buyers in Excel
                      or Google Sheets, then import it back here.
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="h-8 w-full gap-1.5 border-[#d9a13b]/40 bg-transparent text-xs text-[#e8c064] hover:bg-[#d9a13b]/10 hover:text-[#e8c064]"
                    onClick={() => window.open('/api/buyers/sample', '_blank', 'noopener')}
                  >
                    <FileDown className="h-3.5 w-3.5" /> Download sample CSV
                  </Button>
                </div>
              </div>

              {/* drop zone */}
              <div
                role="button"
                tabIndex={0}
                aria-label="Upload a CSV file with buyers"
                className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-4 py-8 text-center transition-colors outline-none focus-visible:ring-2 focus-visible:ring-[#d9a13b]/60 ${
                  dragOver ? 'border-[#d9a13b] bg-[#d9a13b]/5' : 'border-[#2a3342] hover:border-[#39445a]'
                }`}
                onClick={() => fileInputRef.current?.click()}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInputRef.current?.click(); } }}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files?.[0]; if (f) void loadFile(f); }}
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#1d2430]">
                  <Upload className={`h-4 w-4 ${dragOver ? 'text-[#e8c064]' : 'text-zinc-500'}`} />
                </span>
                <p className="text-sm font-medium text-zinc-200">Drop your CSV file here</p>
                <p className="text-[11px] text-zinc-600">or click to browse — up to 1,000 buyers per file</p>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,text/csv,.txt"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void loadFile(f);
                  e.target.value = '';
                }}
              />

              {parseError && (
                <div className="flex items-start gap-2 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {parseError}
                </div>
              )}
            </div>
          )}

          {importStep === 'review' && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex items-center gap-1.5 rounded-md border border-[#2a3342] bg-[#0f1319] px-2 py-1 font-mono text-[11px] text-zinc-300">
                  <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-400" /> {importFile}
                </span>
                <span className="text-[11px] text-zinc-500">{counts.total} rows</span>
                <span className="flex items-center gap-1 text-[11px] text-emerald-400"><CheckCircle2 className="h-3 w-3" /> {counts.ok} ready</span>
                {counts.warn > 0 && <span className="flex items-center gap-1 text-[11px] text-amber-400"><AlertTriangle className="h-3 w-3" /> {counts.warn} warnings</span>}
                {counts.error > 0 && <span className="flex items-center gap-1 text-[11px] text-red-400"><XCircle className="h-3 w-3" /> {counts.error} errors</span>}
                {counts.saved > 0 && <span className="text-[11px] text-zinc-500">· {counts.saved} already saved</span>}
              </div>
              {importNote && (
                <p className="rounded-md border border-amber-500/25 bg-amber-500/5 px-3 py-1.5 text-[11px] text-amber-300/90">{importNote}</p>
              )}

              {/* import mode */}
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <ModeCard
                  active={importMode === 'skip'}
                  title="Skip existing buyers"
                  hint="Rows matching a saved buyer’s name are left untouched."
                  onClick={() => setImportMode('skip')}
                />
                <ModeCard
                  active={importMode === 'update'}
                  title="Update existing buyers"
                  hint="Non-empty CSV values overwrite the saved details."
                  onClick={() => setImportMode('update')}
                />
              </div>
              {counts.saved > 0 && (
                <p className="text-[11px] text-zinc-600">
                  {counts.saved} row{counts.saved > 1 ? 's' : ''} match saved buyers — they will be {importMode === 'skip' ? 'skipped' : 'updated'}.
                </p>
              )}

              {/* preview table */}
              <div className="studio-scroll max-h-60 overflow-auto rounded-lg border border-[#232b38]">
                <table className="w-full text-[11px]">
                  <thead className="sticky top-0 z-10">
                    <tr className="bg-[#10141b] text-left text-[9px] uppercase tracking-wider text-zinc-500">
                      <th className="px-2.5 py-2 font-medium">Row</th>
                      <th className="px-2.5 py-2 font-medium">Buyer</th>
                      <th className="px-2.5 py-2 font-medium">GSTIN</th>
                      <th className="px-2.5 py-2 font-medium">Phone</th>
                      <th className="px-2.5 py-2 font-medium">State</th>
                      {buyerFields.length > 0 && <th className="px-2.5 py-2 font-medium">Custom</th>}
                      <th className="px-2.5 py-2 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewRows.map((r) => (
                      <tr
                        key={r.line}
                        title={r.messages.length ? r.messages.join('\n') : undefined}
                        className={`border-b border-[#1a212c] last:border-0 ${
                          r.status === 'error' ? 'bg-red-500/5' : r.status === 'warn' ? 'bg-amber-500/5' : ''
                        }`}
                      >
                        <td className="px-2.5 py-1.5 font-mono text-[10px] text-zinc-600">{r.line}</td>
                        <td className="max-w-[140px] truncate px-2.5 py-1.5 font-medium text-zinc-200">
                          {r.name || <span className="text-red-400">(blank)</span>}
                          {r.saved && <span className="ml-1.5 rounded border border-[#2a3342] px-1 py-px text-[8px] uppercase tracking-wider text-zinc-500">saved</span>}
                        </td>
                        <td className="max-w-[120px] truncate px-2.5 py-1.5 font-mono text-[10px] text-zinc-500">{r.gst || '—'}</td>
                        <td className="px-2.5 py-1.5 text-zinc-500">{r.phone || '—'}</td>
                        <td className="max-w-[80px] truncate px-2.5 py-1.5 text-zinc-500">{r.state || '—'}</td>
                        {buyerFields.length > 0 && (() => {
                          const entries = buyerFields
                            .filter((f) => (r.custom[f.key] ?? '') !== '')
                            .map((f) => `${f.label}: ${r.custom[f.key]}`);
                          return (
                            <td className="max-w-[150px] truncate px-2.5 py-1.5 text-zinc-500" title={entries.join(' · ')}>
                              {entries.length ? entries.join(' · ') : '—'}
                            </td>
                          );
                        })()}
                        <td className="max-w-[180px] px-2.5 py-1.5">
                          {r.status === 'ok' ? (
                            <span className="flex items-center gap-1 text-emerald-400"><CheckCircle2 className="h-3 w-3 shrink-0" /> Ready</span>
                          ) : r.status === 'warn' ? (
                            <span className="flex items-center gap-1 text-amber-400"><AlertTriangle className="h-3 w-3 shrink-0" /> <span className="truncate">{r.messages[0]}</span></span>
                          ) : (
                            <span className="flex items-center gap-1 text-red-400"><XCircle className="h-3 w-3 shrink-0" /> <span className="truncate">{r.messages[0]}</span></span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {counts.error > 0 && (
                <p className="text-[11px] text-zinc-500">
                  {counts.error} invalid row{counts.error > 1 ? 's' : ''} will be skipped during import.
                </p>
              )}
            </div>
          )}

          {importStep === 'done' && importResult && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-2">
                <ResultTile label="Created" value={importResult.created} tone="emerald" />
                <ResultTile label="Updated" value={importResult.updated} tone="sky" />
                <ResultTile label="Skipped" value={importResult.skipped} tone="zinc" />
                <ResultTile label="Failed" value={importResult.failed} tone="red" />
              </div>
              {importResult.errors.length > 0 && (
                <div>
                  <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-zinc-500">Row problems</p>
                  <div className="studio-scroll max-h-40 space-y-1 overflow-auto rounded-md border border-[#2a3342] bg-[#0f1319] p-2">
                    {importResult.errors.map((e) => (
                      <p key={e.row} className="flex items-start gap-2 text-[11px]">
                        <span className="shrink-0 font-mono text-zinc-600">Row {e.row}</span>
                        <span className="truncate text-zinc-300">{e.name}</span>
                        <span className="ml-auto shrink-0 pl-2 text-right text-red-400">{e.reason}</span>
                      </p>
                    ))}
                  </div>
                </div>
              )}
              {importResult.skipped > 0 && (
                <p className="text-[11px] leading-relaxed text-zinc-500">
                  {importResult.skipped} existing buyer{importResult.skipped > 1 ? 's were' : ' was'} skipped to protect saved details —
                  re-import the same file in <span className="text-[#e8c064]">Update existing buyers</span> mode to refresh them.
                </p>
              )}
              <p className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" /> Buyer list refreshed — imported buyers are now available in the bill form.
              </p>
            </div>
          )}

          {/* footer */}
          <div className="flex items-center justify-between gap-2 border-t border-[#232b38] pt-3">
            <div>
              {importStep === 'review' && (
                <Button variant="ghost" className="h-8 text-xs text-zinc-400 hover:bg-[#1a212c]" onClick={() => { resetImport(); setImportOpen(true); }}>
                  Choose another file
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2">
              {importStep !== 'done' && (
                <Button variant="outline" className="h-8 border-[#2a3342] text-xs" onClick={() => { setImportOpen(false); resetImport(); }}>
                  Cancel
                </Button>
              )}
              {importStep === 'review' && (
                <Button
                  className="h-8 gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]"
                  disabled={importing || counts.importable === 0}
                  onClick={runImport}
                >
                  {importing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
                  {importing ? 'Importing…' : `Import ${counts.importable} buyer${counts.importable === 1 ? '' : 's'}`}
                </Button>
              )}
              {importStep === 'done' && (
                <>
                  <Button variant="ghost" className="h-8 text-xs text-zinc-400 hover:bg-[#1a212c]" onClick={() => { resetImport(); setImportOpen(true); }}>
                    Import another file
                  </Button>
                  <Button className="h-8 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]" onClick={() => { setImportOpen(false); resetImport(); }}>
                    Done
                  </Button>
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {deleting?.name}?</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              The buyer will be removed from the saved list. Past bills in history are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2a3342] bg-transparent text-zinc-300 hover:bg-[#1a212c]">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 text-white hover:bg-red-500" onClick={doDelete}>
              Remove buyer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function LedgerTile({ label, value, tone }: { label: string; value: string; tone: 'gold' | 'green' | 'amber' }) {
  const cls =
    tone === 'gold'
      ? 'text-[#e8c064]'
      : tone === 'green'
        ? 'text-emerald-300'
        : 'text-amber-300';
  return (
    <div className="rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2.5 text-center">
      <p className="text-[9px] uppercase tracking-wider text-zinc-600">{label}</p>
      <p className={`tabular mt-1 text-sm font-bold ${cls}`}>{value}</p>
    </div>
  );
}

/** radio-style option card for the import dialog (skip vs update mode) */
function ModeCard({ active, title, hint, onClick }: { active: boolean; title: string; hint: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-lg border p-3 text-left transition-all ${
        active
          ? 'border-[#d9a13b]/70 bg-[#d9a13b]/10 ring-1 ring-[#d9a13b]/40'
          : 'border-[#2a3342] bg-[#0f1319] hover:border-[#39445a]'
      }`}
    >
      <span className="flex items-center gap-2">
        <span className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full border ${active ? 'border-[#d9a13b]' : 'border-zinc-600'}`}>
          {active && <span className="h-1.5 w-1.5 rounded-full bg-[#d9a13b]" />}
        </span>
        <span className={`text-xs font-semibold ${active ? 'text-[#e8c064]' : 'text-zinc-200'}`}>{title}</span>
      </span>
      <span className="mt-1 block pl-[22px] text-[10px] leading-relaxed text-zinc-500">{hint}</span>
    </button>
  );
}

/** result counter for the import summary */
function ResultTile({ label, value, tone }: { label: string; value: number; tone: 'emerald' | 'sky' | 'zinc' | 'red' }) {
  const cls =
    tone === 'emerald'
      ? 'text-emerald-300'
      : tone === 'sky'
        ? 'text-sky-300'
        : tone === 'red'
          ? 'text-red-300'
          : 'text-zinc-300';
  return (
    <div className="rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2.5 text-center">
      <p className="text-[9px] uppercase tracking-wider text-zinc-600">{label}</p>
      <p className={`tabular mt-1 text-lg font-bold ${cls}`}>{value}</p>
    </div>
  );
}

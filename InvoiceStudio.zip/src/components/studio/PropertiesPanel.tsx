'use client';

/* ============================================================
 * InvoiceStudio — element properties panel
 * ============================================================ */
import React, { useMemo } from 'react';
import {
  AlignCenter, AlignEndHorizontal, AlignHorizontalDistributeCenter, AlignLeft,
  AlignRight, AlignStartHorizontal, AlignVerticalDistributeCenter, ArrowDown,
  ArrowUp, Copy, Lock, LockOpen, Maximize2, Minimize2, MousePointerSquareDashed,
  PanelRightClose, Plus, Trash2, Type as TypeIcon, Upload, X,
} from 'lucide-react';
import type { Align, BuyerFieldDef, CustomFontDef, TableColumn, TemplateElement, VariableDef, VAlign } from '@/lib/studio/types';
import { variableGroups } from '@/lib/studio/defaults';
import { uid } from '@/lib/studio/format';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { KNOWN_ITEM_KEYS } from '@/lib/studio/render';
import NumStepper from './NumStepper';
import { getAllFontGroups, type FontGroup } from '@/lib/studio/fonts';

interface Props {
  el: TemplateElement | null;
  multiCount?: number;
  customVars: VariableDef[];
  buyerFields?: BuyerFieldDef[];
  customFonts?: CustomFontDef[];
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  onCollapse?: () => void;
  onChange: (patch: Partial<TemplateElement>) => void;
  onZ: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onAlign?: (mode: 'left' | 'cx' | 'right' | 'top' | 'cy' | 'bottom') => void;
  onDistribute?: (axis: 'h' | 'v') => void;
  onOpenSettings?: () => void;
}

/* ---------- tiny field helpers ---------- */

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="px-4 py-3">
      <div className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">{title}</div>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

function NumField({
  label, value, onChange, step = 1, shiftStep, min, max, suffix, labelWidth,
}: {
  label: string; value: number; onChange: (v: number) => void;
  step?: number; shiftStep?: number; min?: number; max?: number; suffix?: string; labelWidth?: string;
}) {
  return (
    <NumStepper
      label={label}
      value={value}
      onChange={onChange}
      step={step}
      shiftStep={shiftStep}
      min={min}
      max={max}
      suffix={suffix}
      labelWidth={labelWidth}
    />
  );
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center gap-2">
      <Label className="w-14 shrink-0 text-[11px] text-zinc-400">{label}</Label>
      <div className="flex flex-1 items-center gap-1.5">
        <input
          type="color"
          value={value || '#000000'}
          onChange={(e) => onChange(e.target.value)}
          className="h-7 w-8 cursor-pointer rounded border border-[#2a3342] bg-[#0d1117] p-0.5"
          aria-label={label}
        />
        <Input
          className="h-7 border-[#2a3342] bg-[#0d1117] font-mono text-[11px]"
          value={value ?? ''}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
    </div>
  );
}

function SegBtns<T extends string>({
  value, options, onChange,
}: {
  value: T; options: { v: T; icon: React.ReactNode; title: string }[]; onChange: (v: T) => void;
}) {
  return (
    <div className="flex flex-1 overflow-hidden rounded border border-[#2a3342]">
      {options.map((o) => (
        <button
          key={o.v}
          type="button"
          title={o.title}
          onClick={() => onChange(o.v)}
          className={`flex h-7 flex-1 items-center justify-center text-[11px] transition-colors ${
            value === o.v ? 'bg-[#d9a13b] text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
          }`}
        >
          {o.icon}
        </button>
      ))}
    </div>
  );
}

function FontSelect({
  value,
  fontGroups,
  onChange,
  onOpenSettings,
}: {
  value?: string;
  fontGroups: FontGroup[];
  onChange: (v: string) => void;
  onOpenSettings?: () => void;
}) {
  const currentValue = value ?? fontGroups[0]?.fonts[0]?.value ?? 'Arial, Helvetica, sans-serif';

  return (
    <div className="flex items-center gap-2">
      <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Font</Label>
      <Select value={currentValue} onValueChange={onChange}>
        <SelectTrigger className="h-7 flex-1 border-[#2a3342] bg-[#0d1117] text-xs">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200 max-h-80">
          {fontGroups.map((group) => (
            <SelectGroup key={group.category}>
              <SelectLabel className="text-[10px] uppercase font-bold text-[#d9a13b] tracking-wider py-1 px-2">
                {group.category}
              </SelectLabel>
              {group.fonts.map((f) => (
                <SelectItem key={f.value} value={f.value} className="text-xs" style={{ fontFamily: f.value }}>
                  {f.label}
                </SelectItem>
              ))}
            </SelectGroup>
          ))}
          {onOpenSettings && (
            <>
              <Separator className="bg-[#232b38] my-1" />
              <button
                type="button"
                className="w-full text-left px-2 py-1.5 text-xs text-[#d9a13b] hover:bg-[#181f2a] rounded flex items-center gap-1.5 transition-colors"
                onClick={onOpenSettings}
              >
                + Manage Custom Fonts in Settings...
              </button>
            </>
          )}
        </SelectContent>
      </Select>
    </div>
  );
}

/* ---------- main panel ---------- */

export default function PropertiesPanel({
  el,
  multiCount = 1,
  customVars,
  buyerFields,
  customFonts,
  isExpanded = false,
  onToggleExpand,
  onCollapse,
  onChange,
  onZ,
  onDuplicate,
  onDelete,
  onAlign,
  onDistribute,
  onOpenSettings,
}: Props) {
  if (!el) {
    return (
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between border-b border-[#232b38] bg-[#12161d] px-3 py-2">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
            Properties
          </span>
          <div className="flex items-center gap-0.5">
            {onToggleExpand && (
              <Button
                variant="ghost"
                size="icon"
                className={`h-7 w-7 transition-colors ${
                  isExpanded ? 'text-[#d9a13b] bg-[#d9a13b]/10' : 'text-zinc-400 hover:text-[#d9a13b]'
                }`}
                title={isExpanded ? 'Standard width' : 'Expand panel'}
                onClick={onToggleExpand}
              >
                {isExpanded ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
              </Button>
            )}
            {onCollapse && (
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-zinc-400 hover:text-zinc-100"
                title="Collapse panel"
                onClick={onCollapse}
              >
                <PanelRightClose className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
        <div className="flex flex-1 items-center justify-center p-6 text-center">
          <div>
            <TypeIcon className="mx-auto mb-3 h-8 w-8 text-zinc-700" />
            <p className="text-xs text-zinc-500">Select an element on the canvas<br />to edit its properties</p>
          </div>
        </div>
      </div>
    );
  }

  const isMulti = multiCount > 1;

  const groups = variableGroups(customVars, buyerFields);
  const fontGroups = useMemo(() => getAllFontGroups(customFonts), [customFonts]);
  const isText = el.type === 'text';
  const hasAppearance = el.type === 'text' || el.type === 'rect' || el.type === 'table' || el.type === 'image';

  const insertVar = (key: string) => {
    onChange({ text: `${el.text ?? ''}{{${key}}}` });
  };

  const updateColumn = (i: number, patch: Partial<TableColumn>) => {
    const cols = (el.columns ?? []).map((c, ci) => (ci === i ? { ...c, ...patch } : c));
    onChange({ columns: cols });
  };

  const onLogoUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => onChange({ src: String(reader.result) });
    reader.readAsDataURL(file);
  };

  return (
    <div className="studio-scroll h-full overflow-y-auto pb-8">
      {/* element header */}
      <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#232b38] bg-[#12161d] px-3 py-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="rounded bg-[#d9a13b]/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#d9a13b] shrink-0">
            {el.type}
          </span>
          <span className="font-mono text-[10px] text-zinc-500 truncate">#{el.id.slice(-5)}</span>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <Button variant="ghost" size="icon" className="h-7 w-7 text-zinc-400 hover:text-zinc-100" title="Bring forward" onClick={() => onZ(1)}>
            <ArrowUp className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-zinc-400 hover:text-zinc-100" title="Send backward" onClick={() => onZ(-1)}>
            <ArrowDown className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-zinc-400 hover:text-zinc-100" title="Duplicate" onClick={onDuplicate}>
            <Copy className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-zinc-400 hover:text-zinc-100"
            title={el.locked ? 'Unlock' : 'Lock'}
            onClick={() => onChange({ locked: !el.locked })}
          >
            {el.locked ? <Lock className="h-3.5 w-3.5 text-red-400" /> : <LockOpen className="h-3.5 w-3.5" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-zinc-400 hover:text-red-400" title="Delete" onClick={onDelete}>
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
          {onToggleExpand && (
            <Button
              variant="ghost"
              size="icon"
              className={`h-7 w-7 transition-colors ${
                isExpanded ? 'text-[#d9a13b] bg-[#d9a13b]/10' : 'text-zinc-400 hover:text-[#d9a13b]'
              }`}
              title={isExpanded ? 'Shrink side panel width' : 'Expand side panel width (or drag left border)'}
              onClick={onToggleExpand}
            >
              {isExpanded ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </Button>
          )}
          {onCollapse && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-zinc-400 hover:text-zinc-100"
              title="Collapse panel"
              onClick={onCollapse}
            >
              <PanelRightClose className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </div>

      {/* ---------- multi-select toolbar ---------- */}
      {isMulti && (
        <>
          <div className="border-b border-[#232b38] bg-gradient-to-r from-[#d9a13b]/12 to-transparent px-4 py-3">
            <div className="mb-2 flex items-center gap-2">
              <MousePointerSquareDashed className="h-3.5 w-3.5 text-[#d9a13b]" />
              <span className="text-[11px] font-semibold text-[#e8b954]">
                {multiCount} elements selected
              </span>
              <span className="ml-auto font-mono text-[9px] text-zinc-600">Shift+click to add</span>
            </div>
            <div className="mb-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Align</div>
            <div className="mb-2.5 grid grid-cols-6 gap-1">
              {([
                { m: 'left', icon: <AlignLeft className="h-3.5 w-3.5" />, t: 'Align left edges' },
                { m: 'cx', icon: <AlignCenter className="h-3.5 w-3.5" />, t: 'Center horizontally' },
                { m: 'right', icon: <AlignRight className="h-3.5 w-3.5" />, t: 'Align right edges' },
                { m: 'top', icon: <AlignStartHorizontal className="h-3.5 w-3.5" />, t: 'Align top edges' },
                { m: 'cy', icon: <AlignEndHorizontal className="h-3.5 w-3.5" />, t: 'Center vertically' },
                { m: 'bottom', icon: <AlignEndHorizontal className="h-3.5 w-3.5 rotate-180" />, t: 'Align bottom edges' },
              ] as const).map((b) => (
                <button
                  key={b.m}
                  type="button"
                  title={b.t}
                  disabled={!onAlign}
                  onClick={() => onAlign?.(b.m)}
                  className="flex h-7 items-center justify-center rounded border border-[#2a3342] bg-[#0d1117] text-zinc-400 transition-colors hover:border-[#d9a13b]/50 hover:bg-[#171d27] hover:text-[#d9a13b] disabled:opacity-40"
                >
                  {b.icon}
                </button>
              ))}
            </div>
            <div className="mb-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Distribute</div>
            <div className="grid grid-cols-2 gap-1">
              {([
                { a: 'h' as const, icon: <AlignHorizontalDistributeCenter className="h-3.5 w-3.5" />, t: 'Distribute horizontally' },
                { a: 'v' as const, icon: <AlignVerticalDistributeCenter className="h-3.5 w-3.5" />, t: 'Distribute vertically' },
              ]).map((b) => (
                <button
                  key={b.a}
                  type="button"
                  title={multiCount < 3 ? `${b.t} (needs 3+)` : b.t}
                  disabled={!onDistribute || multiCount < 3}
                  onClick={() => onDistribute?.(b.a)}
                  className="flex h-7 items-center justify-center gap-1.5 rounded border border-[#2a3342] bg-[#0d1117] text-[10px] text-zinc-400 transition-colors hover:border-[#d9a13b]/50 hover:bg-[#171d27] hover:text-[#d9a13b] disabled:opacity-40"
                >
                  {b.icon}
                  {b.a === 'h' ? 'Horizontal' : 'Vertical'}
                </button>
              ))}
            </div>
            {multiCount < 3 && (
              <p className="mt-2 text-[9px] leading-relaxed text-zinc-600">
                Select 3+ elements to enable even distribution. Group actions apply to all unlocked elements.
              </p>
            )}
          </div>
          <Separator className="bg-[#232b38]" />
        </>
      )}

      <Section title="Position & Size (mm)">
        <div className="grid grid-cols-2 gap-x-2.5 gap-y-2">
          <NumField label="X" value={el.x} onChange={(v) => onChange({ x: v })} step={1} shiftStep={5} min={0} suffix="mm" labelWidth="w-5" />
          <NumField label="Y" value={el.y} onChange={(v) => onChange({ y: v })} step={1} shiftStep={5} min={0} suffix="mm" labelWidth="w-5" />
          <NumField label="W" value={el.w} onChange={(v) => onChange({ w: Math.max(0.4, v) })} step={1} shiftStep={5} min={0.4} suffix="mm" labelWidth="w-5" />
          <NumField label="H" value={el.h} onChange={(v) => onChange({ h: Math.max(0.4, v) })} step={1} shiftStep={5} min={0.4} suffix="mm" labelWidth="w-5" />
        </div>
        {el.type !== 'table' && (
          <div className="space-y-1.5 pt-1">
            <NumField
              label="Rotate"
              value={el.rotation ?? 0}
              onChange={(v) => onChange({ rotation: Math.max(-180, Math.min(180, Math.round(v))) })}
              step={15}
              shiftStep={45}
              min={-180}
              max={180}
              suffix="°"
              labelWidth="w-12"
            />
            <div className="flex items-center gap-1 pl-13">
              {[0, 90, 180, -90].map((deg) => (
                <button
                  key={deg}
                  type="button"
                  onClick={() => onChange({ rotation: deg })}
                  className={`h-5 px-1.5 rounded text-[10px] font-mono transition-colors ${
                    (el.rotation ?? 0) === deg
                      ? 'bg-[#d9a13b] font-semibold text-black'
                      : 'bg-[#0d1117] text-zinc-400 hover:bg-[#1a2332] hover:text-zinc-200 border border-[#2a3342]'
                  }`}
                >
                  {deg}°
                </button>
              ))}
            </div>
          </div>
        )}
        <button
          type="button"
          onClick={() => onChange({ repeatOnPages: !el.repeatOnPages })}
          title="Print this element again on every continuation page (letterheads, footers)"
          className={`h-6 w-full rounded text-[10px] ${
            el.repeatOnPages ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
          }`}
        >
          Repeat on every page
        </button>
        {(['text', 'image', 'qrcode', 'barcode'] as TemplateElement['type'][]).includes(el.type) && (
          <button
            type="button"
            onClick={() => onChange({ hideWhenBlank: !el.hideWhenBlank })}
            title="Skip this element in the printed bill when its content resolves blank or ₹0 (e.g. Vehicle line, zero Subtotal)"
            className={`h-6 w-full rounded text-[10px] ${
              el.hideWhenBlank ? 'bg-sky-600 font-semibold text-white' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
            }`}
          >
            Hide when blank {el.hideWhenBlank ? '✓' : ''}
          </button>
        )}
      </Section>

      {/* ---------- text content ---------- */}
      {isText && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Content">
            <Textarea
              className="min-h-[72px] border-[#2a3342] bg-[#0d1117] text-xs"
              value={el.text ?? ''}
              placeholder="Type text or insert variables…"
              onChange={(e) => onChange({ text: e.target.value })}
            />
            <div>
              <Label className="mb-1 block text-[10px] text-zinc-500">Insert dynamic variable</Label>
              <Select onValueChange={(v) => { if (v !== '__none') insertVar(v); }} value="__none">
                <SelectTrigger className="h-7 border-[#2a3342] bg-[#0d1117] text-xs">
                  <span className="text-zinc-400">+ Add variable…</span>
                </SelectTrigger>
                <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                  {groups.map((g) => (
                    <SelectGroup key={g.group}>
                      <SelectLabel className="text-[10px] uppercase tracking-wider text-zinc-500">{g.group}</SelectLabel>
                      {g.vars.map((v) => (
                        <SelectItem key={v.key} value={v.key} className="text-xs">
                          {v.label} <span className="font-mono text-[9px] text-[#d9a13b]">{`{{${v.key}}}`}</span>
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </Section>

          <Separator className="bg-[#232b38]" />
          <Section title="Typography">
            <FontSelect
              value={el.fontFamily}
              fontGroups={fontGroups}
              onChange={(v) => onChange({ fontFamily: v })}
              onOpenSettings={onOpenSettings}
            />
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-2">
              <NumField label="Size" value={el.fontSize ?? 10} onChange={(v) => onChange({ fontSize: Math.max(4, v) })} step={1} shiftStep={4} min={4} max={120} suffix="pt" labelWidth="w-10" />
              <NumField label="Spacing" value={el.letterSpacing ?? 0} onChange={(v) => onChange({ letterSpacing: v })} step={0.1} shiftStep={0.5} min={-2} max={20} suffix="pt" labelWidth="w-12" />
            </div>
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-2">
              <NumField label="Weight" value={el.fontWeight ?? 400} onChange={(v) => onChange({ fontWeight: Math.max(100, Math.min(900, Math.round(v / 100) * 100)) })} step={100} shiftStep={200} min={100} max={900} labelWidth="w-10" />
              <NumField label="Line H" value={el.lineHeight ?? 1.25} onChange={(v) => onChange({ lineHeight: Math.max(0.8, v) })} step={0.05} shiftStep={0.25} min={0.8} max={3} labelWidth="w-12" />
            </div>
            <ColorField label="Color" value={el.color ?? '#1a1a1a'} onChange={(v) => onChange({ color: v })} />
            <div className="flex items-center gap-2">
              <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Align</Label>
              <SegBtns<Align>
                value={el.align ?? 'left'}
                onChange={(v) => onChange({ align: v })}
                options={[
                  { v: 'left', icon: <AlignLeft className="h-3.5 w-3.5" />, title: 'Left' },
                  { v: 'center', icon: <AlignCenter className="h-3.5 w-3.5" />, title: 'Center' },
                  { v: 'right', icon: <AlignRight className="h-3.5 w-3.5" />, title: 'Right' },
                ]}
              />
              <SegBtns<VAlign>
                value={el.vAlign ?? 'top'}
                onChange={(v) => onChange({ vAlign: v })}
                options={[
                  { v: 'top', icon: <span className="text-[9px]">TOP</span>, title: 'Top' },
                  { v: 'middle', icon: <span className="text-[9px]">MID</span>, title: 'Middle' },
                  { v: 'bottom', icon: <span className="text-[9px]">BOT</span>, title: 'Bottom' },
                ]}
              />
            </div>
            <div className="flex gap-2 pt-0.5">
              {(
                [
                  ['italic', 'Italic'],
                  ['underline', 'Underline'],
                  ['uppercase', 'Uppercase'],
                ] as const
              ).map(([k, label]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => onChange({ [k]: !el[k] })}
                  className={`h-6 rounded px-2 text-[10px] ${
                    el[k] ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </Section>
        </>
      )}

      {/* ---------- image ---------- */}
      {el.type === 'image' && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Image / Logo">
            <div className="flex items-center gap-2">
              <label className="flex h-7 flex-1 cursor-pointer items-center justify-center gap-1.5 rounded bg-[#d9a13b] text-[11px] font-semibold text-black hover:bg-[#e5b055]">
                <Upload className="h-3 w-3" /> Upload image
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) onLogoUpload(f);
                    e.target.value = '';
                  }}
                />
              </label>
              {el.src && (
                <Button variant="outline" size="sm" className="h-7 border-[#2a3342] px-2 text-[11px] hover:text-red-400" onClick={() => onChange({ src: '' })}>
                  <X className="h-3 w-3" /> Clear
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Fit</Label>
              <SegBtns<'contain' | 'cover' | 'fill'>
                value={el.objectFit ?? 'contain'}
                onChange={(v) => onChange({ objectFit: v })}
                options={[
                  { v: 'contain', icon: <span className="text-[9px]">CONTAIN</span>, title: 'Contain' },
                  { v: 'cover', icon: <span className="text-[9px]">COVER</span>, title: 'Cover' },
                  { v: 'fill', icon: <span className="text-[9px]">FILL</span>, title: 'Fill' },
                ]}
              />
            </div>
            <button
              type="button"
              onClick={() => onChange({ useBusinessLogo: !el.useBusinessLogo })}
              title="Use the logo uploaded in Settings when no image is set here"
              className={`h-6 w-full rounded text-[10px] ${
                el.useBusinessLogo ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
              }`}
            >
              Use business logo (from Settings)
            </button>
            {el.src && (
              <div className="rounded border border-[#2a3342] bg-white p-1">
                { }
                <img src={el.src} alt="Preview" className="mx-auto max-h-16 object-contain" />
              </div>
            )}
          </Section>
        </>
      )}

      {/* ---------- qrcode ---------- */}
      {el.type === 'qrcode' && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="QR Code Content">
            <div className="flex items-center gap-2">
              <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Source</Label>
              <Select value={el.qrSource ?? 'upi_amount'} onValueChange={(v) => onChange({ qrSource: v as 'upi_amount' | 'upi' | 'custom' })}>
                <SelectTrigger className="h-7 flex-1 border-[#2a3342] bg-[#0d1117] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                  <SelectItem value="upi_amount" className="text-xs">UPI pay + amount (per bill)</SelectItem>
                  <SelectItem value="upi" className="text-xs">UPI pay (no amount)</SelectItem>
                  <SelectItem value="custom" className="text-xs">Custom text / link</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {el.qrSource === 'custom' && (
              <>
                <Textarea
                  className="min-h-[56px] border-[#2a3342] bg-[#0d1117] text-xs"
                  value={el.qrCustom ?? ''}
                  placeholder="Text, URL, UPI id… {{variables}} supported"
                  onChange={(e) => onChange({ qrCustom: e.target.value })}
                />
                <Select onValueChange={(v) => { if (v !== '__none') onChange({ qrCustom: `${el.qrCustom ?? ''}{{${v}}}` }); }} value="__none">
                  <SelectTrigger className="h-7 border-[#2a3342] bg-[#0d1117] text-xs">
                    <span className="text-zinc-400">+ Insert variable…</span>
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {groups.map((g) => (
                      <SelectGroup key={g.group}>
                        <SelectLabel className="text-[10px] uppercase tracking-wider text-zinc-500">{g.group}</SelectLabel>
                        {g.vars.map((v) => (
                          <SelectItem key={v.key} value={v.key} className="text-xs">
                            {v.label} <span className="font-mono text-[9px] text-[#d9a13b]">{`{{${v.key}}}`}</span>
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
              </>
            )}
            {(el.qrSource ?? 'upi_amount') !== 'custom' && (
              <p className="text-[10px] leading-relaxed text-zinc-500">
                Encodes the UPI id from Settings → Business (Bank UPI). Scanning opens any UPI app
                {el.qrSource === 'upi' ? ' without a prefilled amount.' : ` with the invoice total prefilled.`}
              </p>
            )}
            <ColorField label="Color" value={el.qrColor ?? '#1a1a1a'} onChange={(v) => onChange({ qrColor: v })} />
            <p className="text-[10px] leading-relaxed text-zinc-600">
              Keep the QR at least 18 mm square for reliable phone scanning on print.
            </p>
          </Section>
        </>
      )}

      {/* ---------- barcode ---------- */}
      {el.type === 'barcode' && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Barcode Content (CODE128)">
            <Textarea
              className="min-h-[52px] border-[#2a3342] bg-[#0d1117] text-xs"
              value={el.barcodeData ?? ''}
              placeholder="{{invoice_no}} — variables supported"
              onChange={(e) => onChange({ barcodeData: e.target.value })}
            />
            <Select onValueChange={(v) => { if (v !== '__none') onChange({ barcodeData: `${el.barcodeData ?? ''}{{${v}}}` }); }} value="__none">
              <SelectTrigger className="h-7 border-[#2a3342] bg-[#0d1117] text-xs">
                <span className="text-zinc-400">+ Insert variable…</span>
              </SelectTrigger>
              <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                {groups.map((g) => (
                  <SelectGroup key={g.group}>
                    <SelectLabel className="text-[10px] uppercase tracking-wider text-zinc-500">{g.group}</SelectLabel>
                    {g.vars.map((v) => (
                      <SelectItem key={v.key} value={v.key} className="text-xs">
                        {v.label} <span className="font-mono text-[9px] text-[#d9a13b]">{`{{${v.key}}}`}</span>
                      </SelectItem>
                    ))}
                  </SelectGroup>
                ))}
              </SelectContent>
            </Select>
            <ColorField label="Ink" value={el.barcodeColor ?? '#1a1a1a'} onChange={(v) => onChange({ barcodeColor: v })} />
            <button
              type="button"
              onClick={() => onChange({ barcodeShowText: !(el.barcodeShowText ?? true) })}
              title="Print the human-readable value under the bars"
              className={`h-6 w-full rounded text-[10px] ${
                (el.barcodeShowText ?? true) ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
              }`}
            >
              Show value under bars
            </button>
            <p className="text-[10px] leading-relaxed text-zinc-600">
              CODE128 — ideal for invoice numbers on transport/e-way copies. Keep at least
              30 mm wide for reliable scanner pickup; non-ASCII characters are stripped automatically.
            </p>
          </Section>
        </>
      )}

      {/* ---------- line ---------- */}
      {el.type === 'line' && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Line">
            <div className="flex items-center gap-2">
              <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Dir</Label>
              <SegBtns<'h' | 'v'>
                value={el.direction ?? 'h'}
                onChange={(v) => onChange({ direction: v })}
                options={[
                  { v: 'h', icon: <span className="text-[10px]">— H</span>, title: 'Horizontal' },
                  { v: 'v', icon: <span className="text-[10px]">| V</span>, title: 'Vertical' },
                ]}
              />
            </div>
            <NumField label="Thick" value={el.borderWidth ?? 0.4} onChange={(v) => onChange({ borderWidth: Math.max(0.1, v) })} step={0.1} shiftStep={0.5} min={0.1} suffix="mm" labelWidth="w-12" />
            <ColorField label="Color" value={el.borderColor ?? '#1a1a1a'} onChange={(v) => onChange({ borderColor: v })} />
          </Section>
        </>
      )}

      {/* ---------- table ---------- */}
      {el.type === 'table' && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Table Columns">
            <div className="space-y-2">
              {(el.columns ?? []).map((c, i) => (
                <div key={i} className="rounded border border-[#2a3342] bg-[#0d1117] p-2">
                  <div className="mb-1.5 flex items-center gap-1.5">
                    <Input
                      className="h-6 flex-1 border-[#2a3342] bg-[#12161d] text-[11px]"
                      value={c.label}
                      placeholder="Column label"
                      onChange={(e) => updateColumn(i, { label: e.target.value })}
                    />
                    <Input
                      className="h-6 w-24 border-[#2a3342] bg-[#12161d] font-mono text-[10px]"
                      value={c.key}
                      list="item-keys"
                      placeholder="field"
                      onChange={(e) => updateColumn(i, { key: e.target.value.replace(/[^a-z0-9_]/gi, '_').toLowerCase() })}
                    />
                    <button
                      type="button"
                      className="text-zinc-600 hover:text-red-400"
                      title="Remove column"
                      onClick={() => onChange({ columns: (el.columns ?? []).filter((_, ci) => ci !== i) })}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <NumField label="Width" value={c.width} onChange={(v) => updateColumn(i, { width: Math.max(2, Math.min(100, v)) })} step={1} shiftStep={5} min={2} max={100} suffix="%" labelWidth="w-12" />
                    <SegBtns<Align>
                      value={c.align}
                      onChange={(v) => updateColumn(i, { align: v })}
                      options={[
                        { v: 'left', icon: <AlignLeft className="h-3 w-3" />, title: 'Left' },
                        { v: 'center', icon: <AlignCenter className="h-3 w-3" />, title: 'Center' },
                        { v: 'right', icon: <AlignRight className="h-3 w-3" />, title: 'Right' },
                      ]}
                    />
                  </div>
                </div>
              ))}
              <datalist id="item-keys">
                {Array.from(KNOWN_ITEM_KEYS).map((k) => (
                  <option key={k} value={k} />
                ))}
              </datalist>
              <Button
                variant="outline"
                size="sm"
                className="h-7 w-full border-dashed border-[#2a3342] text-[11px]"
                onClick={() =>
                  onChange({
                    columns: [...(el.columns ?? []), { key: 'desc', label: 'New Column', width: 15, align: 'left' }],
                  })
                }
              >
                <Plus className="mr-1 h-3 w-3" /> Add column
              </Button>
            </div>
          </Section>
          <Separator className="bg-[#232b38]" />
          <Section title="Table Style">
            <FontSelect
              value={el.fontFamily}
              fontGroups={fontGroups}
              onChange={(v) => onChange({ fontFamily: v })}
              onOpenSettings={onOpenSettings}
            />
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-2">
              <NumField label="Row H" value={el.rowHeight ?? 7} onChange={(v) => onChange({ rowHeight: Math.max(3, v) })} step={0.5} shiftStep={2} min={3} max={40} suffix="mm" labelWidth="w-12" />
              <NumField label="Size" value={el.fontSize ?? 9} onChange={(v) => onChange({ fontSize: Math.max(4, v) })} step={0.5} shiftStep={2} min={4} max={30} suffix="pt" labelWidth="w-10" />
            </div>
            <div className="flex gap-3">
              <ColorField label="Head BG" value={el.headerBg ?? '#efe9db'} onChange={(v) => onChange({ headerBg: v })} />
            </div>
            <ColorField label="Head TX" value={el.headerColor ?? '#1a1a1a'} onChange={(v) => onChange({ headerColor: v })} />
            <div className="flex items-center gap-2">
              <Label className="w-14 shrink-0 text-[11px] text-zinc-400">Border</Label>
              <SegBtns<'grid' | 'rows' | 'none'>
                value={el.borderStyle ?? 'grid'}
                onChange={(v) => onChange({ borderStyle: v })}
                options={[
                  { v: 'grid', icon: <span className="text-[9px]">GRID</span>, title: 'Grid' },
                  { v: 'rows', icon: <span className="text-[9px]">ROWS</span>, title: 'Rows only' },
                  { v: 'none', icon: <span className="text-[9px]">NONE</span>, title: 'None' },
                ]}
              />
            </div>
            <button
              type="button"
              onClick={() => onChange({ showZebra: !el.showZebra })}
              className={`h-6 rounded px-2 text-[10px] ${
                el.showZebra ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
              }`}
            >
              Zebra stripes
            </button>
          </Section>
        </>
      )}

      {/* ---------- appearance ---------- */}
      {hasAppearance && (
        <>
          <Separator className="bg-[#232b38]" />
          <Section title="Appearance">
            <ColorField label="BG" value={el.bg ?? '#ffffff'} onChange={(v) => onChange({ bg: v })} />
            {el.type !== 'image' && (
              <>
                <NumField label="Border" value={el.borderWidth ?? 0} onChange={(v) => onChange({ borderWidth: Math.max(0, v) })} step={0.1} shiftStep={0.5} min={0} max={20} suffix="mm" labelWidth="w-12" />
                <ColorField label="Border" value={el.borderColor ?? '#1a1a1a'} onChange={(v) => onChange({ borderColor: v })} />
              </>
            )}
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-2">
              <NumField label="Radius" value={el.borderRadius ?? 0} onChange={(v) => onChange({ borderRadius: Math.max(0, v) })} step={0.5} shiftStep={2} min={0} max={50} suffix="mm" labelWidth="w-12" />
              <NumField label="Padding" value={el.padding ?? 0} onChange={(v) => onChange({ padding: Math.max(0, v) })} step={0.5} shiftStep={2} min={0} max={50} suffix="mm" labelWidth="w-14" />
            </div>
            <div className="space-y-1.5">
              <NumField label="Opacity" value={Math.round((el.opacity ?? 1) * 100)} onChange={(v) => onChange({ opacity: Math.max(5, Math.min(100, v)) / 100 })} step={5} shiftStep={20} min={5} max={100} suffix="%" labelWidth="w-12" />
              <div className="flex items-center gap-1 pl-13">
                {[25, 50, 75, 100].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => onChange({ opacity: pct / 100 })}
                    className={`h-5 px-1.5 rounded text-[10px] font-mono transition-colors ${
                      Math.round((el.opacity ?? 1) * 100) === pct
                        ? 'bg-[#d9a13b] font-semibold text-black'
                        : 'bg-[#0d1117] text-zinc-400 hover:bg-[#1a2332] hover:text-zinc-200 border border-[#2a3342]'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>
          </Section>
        </>
      )}
    </div>
  );
}

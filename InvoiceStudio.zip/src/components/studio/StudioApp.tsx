'use client';

/* ============================================================
 * InvoiceStudio — application shell
 * ============================================================ */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  History, LayoutDashboard, Package, Plus, ReceiptText,
  Settings as SettingsIcon, Shapes, Users, Variable as VariableIcon,
} from 'lucide-react';
import type { Bill, Buyer, ItemRecord, Settings, Template, VariableDef } from '@/lib/studio/types';
import { nextBillNo, nextRepeatDate, todayISO } from '@/lib/studio/format';
import { useToast } from '@/hooks/use-toast';
import DashboardView from './DashboardView';
import TemplatesView from './TemplatesView';
import TemplateDesigner from './TemplateDesigner';
import CreateBillView from './CreateBillView';
import HistoryView from './HistoryView';
import BuyersView from './BuyersView';
import ItemsView from './ItemsView';
import VariablesView from './VariablesView';
import SettingsView from './SettingsView';
import GlobalFontInjector from './GlobalFontInjector';
import PrintManager, { type PrintJob, type ReceiptJob, type CalibrationJob } from './PrintManager';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

type View = 'dashboard' | 'templates' | 'designer' | 'new' | 'history' | 'buyers' | 'items' | 'variables' | 'settings';

const NAV: { id: View; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-3.5 w-3.5" /> },
  { id: 'templates', label: 'Templates', icon: <Shapes className="h-3.5 w-3.5" /> },
  { id: 'new', label: 'Create Bill', icon: <ReceiptText className="h-3.5 w-3.5" /> },
  { id: 'history', label: 'History', icon: <History className="h-3.5 w-3.5" /> },
  { id: 'buyers', label: 'Buyers', icon: <Users className="h-3.5 w-3.5" /> },
  { id: 'items', label: 'Items', icon: <Package className="h-3.5 w-3.5" /> },
  { id: 'variables', label: 'Variables', icon: <VariableIcon className="h-3.5 w-3.5" /> },
  { id: 'settings', label: 'Settings', icon: <SettingsIcon className="h-3.5 w-3.5" /> },
];

export default function StudioApp() {
  const { toast } = useToast();
  const [view, setView] = useState<View>('dashboard');
  const [loading, setLoading] = useState(true);

  const [templates, setTemplates] = useState<Template[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [customVars, setCustomVars] = useState<VariableDef[]>([]);
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [catalogItems, setCatalogItems] = useState<ItemRecord[]>([]);

  const [designerId, setDesignerId] = useState<string | null>(null);
  const [editBill, setEditBill] = useState<Bill | null>(null);
  const [duplicateFrom, setDuplicateFrom] = useState<Bill | null>(null);
  const [initialTemplateId, setInitialTemplateId] = useState<string | null>(null);
  const [initialItem, setInitialItem] = useState<ItemRecord | null>(null);
  const [printJob, setPrintJob] = useState<PrintJob | null>(null);
  const [receiptJob, setReceiptJob] = useState<ReceiptJob | null>(null);
  const [calibrateJob, setCalibrateJob] = useState<CalibrationJob | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  /** the auto-recurring sweep only fires once per browser session */
  const sweepDoneRef = useRef(false);

  const loadAll = useCallback(async (attempt = 0): Promise<void> => {
    try {
      const [tRes, bRes, sRes, vRes, byrRes, itmRes] = await Promise.all([
        fetch('/api/templates'),
        fetch('/api/bills'),
        fetch('/api/settings'),
        fetch('/api/variables'),
        fetch('/api/buyers'),
        fetch('/api/items'),
      ]);
      if (!tRes.ok || !bRes.ok || !sRes.ok || !vRes.ok || !byrRes.ok || !itmRes.ok) {
        throw new Error('one or more collections failed');
      }
      const [t, b, s, v, byr, itm] = await Promise.all([
        tRes.json(),
        bRes.json(),
        sRes.json(),
        vRes.json(),
        byrRes.json(),
        itmRes.json(),
      ]);
      setTemplates(t as Template[]);
      setBills(b as Bill[]);
      setSettings(s as Settings);
      setCustomVars(v.custom as VariableDef[]);
      setBuyers(byr as Buyer[]);
      setCatalogItems((itm as ItemRecord[]) ?? []);
      setLoadError(null);
    } catch {
      if (attempt < 2) {
        setTimeout(() => {
          void loadAll(attempt + 1);
        }, 700);
      } else {
        setLoadError('Could not load data from the local JSON store.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  /** Lazy daily cron: ask the server to create due recurring invoices
   *  (server-side marker keeps it to one run per day). Runs once per
   *  session after the first successful load. */
  useEffect(() => {
    if (loading || loadError || sweepDoneRef.current) return;
    sweepDoneRef.current = true;
    (async () => {
      try {
        const res = await fetch('/api/recurring/sweep', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}),
        });
        if (!res.ok) return;
        const out = (await res.json()) as { createdCount: number; created: { billNo: string; buyer: string }[]; skipped?: string[]; ended?: string[] };
        if (out.createdCount > 0) {
          const names = out.created.map((b) => `${b.billNo}${b.buyer ? ` — ${b.buyer}` : ''}`).join(', ');
          toast({ title: `Recurring: ${out.createdCount} invoice${out.createdCount === 1 ? '' : 's'} auto-created`, description: names });
          await reloadBillsRef.current?.();
        }
        if (out.skipped?.length) {
          toast({ title: `Recurring: skipped ${out.skipped.join(', ')}`, description: 'Skip-next flag consumed — the cadence rolled forward one step.' });
        }
        if (out.ended?.length) {
          toast({ title: `Recurring chain ended: ${out.ended.join(', ')}`, description: 'Passed its end date — no further copies will be created.' });
          await reloadBillsRef.current?.();
        }
      } catch { /* non-blocking */ }
    })();
  }, [loading, loadError, toast]);

  /** late-bound reloadBills so the sweep effect stays dependency-free */
  const reloadBillsRef = useRef<(() => Promise<void>) | null>(null);

  const reloadTemplates = useCallback(async () => {
    const res = await fetch('/api/templates');
    setTemplates((await res.json()) as Template[]);
  }, []);

  const reloadBills = useCallback(async () => {
    const res = await fetch('/api/bills');
    setBills((await res.json()) as Bill[]);
  }, []);

  useEffect(() => {
    reloadBillsRef.current = reloadBills;
  }, [reloadBills]);

  const reloadVars = useCallback(async () => {
    const res = await fetch('/api/variables');
    const data = await res.json();
    setCustomVars(data.custom as VariableDef[]);
  }, []);

  const reloadBuyers = useCallback(async () => {
    const res = await fetch('/api/buyers');
    if (res.ok) setBuyers((await res.json()) as Buyer[]);
  }, []);

  const reloadItems = useCallback(async () => {
    const res = await fetch('/api/items');
    if (res.ok) setCatalogItems((await res.json()) as ItemRecord[]);
  }, []);

  /* ---------- navigation helpers ---------- */

  const openDesigner = (t: Template) => { setDesignerId(t.id); setView('designer'); };

  const startNewBill = (templateId?: string, item?: ItemRecord) => {
    setEditBill(null);
    setDuplicateFrom(null);
    setInitialTemplateId(templateId ?? null);
    setInitialItem(item ?? null);
    setView('new');
  };

  const editBillFn = (b: Bill) => {
    setDuplicateFrom(null);
    setEditBill(b);
    setInitialTemplateId(null);
    setInitialItem(null);
    setView('new');
  };

  const duplicateBillFn = (b: Bill) => {
    setEditBill(null);
    setDuplicateFrom({ ...b, id: '', billNo: nextBillNo(settings ?? ({ billNoPrefix: 'INV-', billNoNext: 1 } as Settings)) });
    setInitialTemplateId(null);
    setInitialItem(null);
    setView('new');
  };

  /** one-click convert a quotation / proforma into a tax invoice:
   *  carries buyer + items, gets the next invoice number and today's date,
   *  starts fresh as an unpaid invoice with no receipts. */
  const convertBillFn = (b: Bill) => {
    setEditBill(null);
    setDuplicateFrom({
      ...b,
      id: '',
      billNo: nextBillNo(settings ?? ({ billNoPrefix: 'INV-', billNoNext: 1 } as Settings)),
      date: new Date().toISOString().slice(0, 10),
      docType: 'invoice',
      status: 'unpaid',
      paidAt: undefined,
      payments: undefined,
      printCount: 0,
    });
    setInitialTemplateId(null);
    setInitialItem(null);
    setView('new');
  };

  /** create the next occurrence of a recurring invoice: same buyer/items, next
   *  bill number, date rolled one cadence step forward (or today when overdue),
   *  fresh unpaid state. */
  const repeatBillFn = (b: Bill) => {
    setEditBill(null);
    setDuplicateFrom({
      ...b,
      id: '',
      billNo: nextBillNo(settings ?? ({ billNoPrefix: 'INV-', billNoNext: 1 } as Settings)),
      date: todayISO() > nextRepeatDate(b) ? todayISO() : nextRepeatDate(b),
      status: 'unpaid',
      paidAt: undefined,
      payments: undefined,
      printCount: 0,
      docType: 'invoice',
      repeat: b.repeat && b.repeat !== 'none' ? b.repeat : 'monthly',
    });
    setInitialTemplateId(null);
    setInitialItem(null);
    setView('new');
  };

  const designerTemplate = templates.find((t) => t.id === designerId) ?? null;

  /* ---------- print flow ---------- */

  const handlePrint = (template: Template, bill: Bill, copies: number) => {
    setPrintJob({ template, bill, copies });
  };

  const handlePrintDone = async (billId: string) => {
    setPrintJob(null);
    try {
      await fetch(`/api/bills/${billId}/print`, { method: 'POST' });
      await reloadBills();
    } catch { /* non-blocking */ }
  };

  const handleReceiptPrint = (j: ReceiptJob) => setReceiptJob(j);

  /** flip Settings → auto-create recurring invoices (dashboard CTA + settings switch) */
  const handleToggleAutoRepeat = useCallback(async (on: boolean) => {
    if (!settings) return;
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...settings, autoRecurring: on }),
      });
      if (!res.ok) throw new Error();
      const saved = (await res.json()) as Settings;
      setSettings(saved);
      toast({
        title: on ? 'Auto-create enabled' : 'Auto-create paused',
        description: on
          ? 'Due recurring invoices will be created automatically each day when the app opens.'
          : 'Recurring invoices will wait for a manual “Create next”.',
      });
    } catch {
      toast({ title: 'Could not update the setting', variant: 'destructive' });
    }
  }, [settings, toast]);

  /* ---------- render ---------- */

  if (loading || !settings) {
    if (loadError) {
      return (
        <div className="flex h-full min-h-screen flex-col items-center justify-center gap-3 bg-[#0b0e13] text-zinc-300">
          <p className="text-sm text-red-400">{loadError}</p>
          <Button className="bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055]" onClick={() => { setLoading(true); setLoadError(null); loadAll(); }}>
            Retry
          </Button>
        </div>
      );
    }
    return (
      <div className="flex h-full flex-col bg-[#0b0e13]">
        <div className="flex h-14 items-center gap-3 border-b border-[#232b38] px-5">
          <Skeleton className="h-7 w-7 rounded bg-[#1d2430]" />
          <Skeleton className="h-4 w-36 bg-[#1d2430]" />
        </div>
        <div className="flex-1 space-y-4 p-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-28 rounded-lg bg-[#151b25]" />
            ))}
          </div>
          <Skeleton className="h-64 rounded-lg bg-[#151b25]" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-[#0b0e13] text-zinc-100">
      <GlobalFontInjector customFonts={settings.customFonts} />
      {/* ---------- header ---------- */}
      <header className="sticky top-0 z-40 relative flex h-14 shrink-0 items-center gap-4 border-b border-[#232b38] bg-[#0b0e13]/95 px-4 backdrop-blur">
        <button
          type="button"
          onClick={() => setView('dashboard')}
          className="group flex cursor-pointer items-center gap-2.5 rounded-lg p-1 text-left transition-all duration-150 active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d9a13b]/50"
          title="Back to Dashboard"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[#d9a13b] text-zinc-950 shadow-sm transition-transform duration-150 group-hover:scale-105 group-hover:bg-[#e8b459]">
            <ReceiptText className="h-4.5 w-4.5" strokeWidth={2.2} />
          </div>
          <div className="leading-none">
            <div className="text-sm font-bold tracking-tight text-zinc-100 transition-colors group-hover:text-white">
              Invoice<span className="text-[#d9a13b] transition-colors group-hover:text-[#e8b459]">Studio</span>
            </div>
            <div className="mt-0.5 text-[9px] uppercase tracking-[0.22em] text-zinc-400">Bill design & print</div>
          </div>
        </button>

        <nav className="no-scrollbar ml-2 flex flex-1 items-center gap-1 overflow-x-auto py-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" aria-label="Main">
          {NAV.map((n) => {
            const active = view === n.id || (view === 'designer' && n.id === 'templates');
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => {
                  if (n.id === 'new') startNewBill();
                  else setView(n.id);
                }}
                className={`group relative flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-md px-3 text-xs font-medium transition-all duration-150 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d9a13b]/60 active:scale-[0.96] ${
                  active
                    ? 'bg-[#1e2634] text-[#f2ca6b] shadow-xs hover:bg-[#253042] hover:text-[#ffd97d] active:bg-[#2a374b]'
                    : 'text-zinc-400 hover:bg-[#161d27] hover:text-zinc-100 active:bg-[#1d2634] active:text-zinc-50'
                }`}
                aria-current={active ? 'page' : undefined}
              >
                <span className={`transition-colors duration-150 ${active ? 'text-[#f2ca6b]' : 'text-zinc-400 group-hover:text-zinc-200'}`}>
                  {n.icon}
                </span>
                <span>{n.label}</span>
                {active && (
                  <span className="pointer-events-none absolute inset-x-2.5 -bottom-[6px] h-[2px] rounded-full bg-gradient-to-r from-[#d9a13b]/0 via-[#d9a13b] to-[#d9a13b]/0 shadow-[0_0_8px_rgba(217,161,59,0.7)]" />
                )}
              </button>
            );
          })}
        </nav>

        <button
          type="button"
          onClick={() => startNewBill()}
          className="group relative inline-flex h-8 shrink-0 cursor-pointer items-center justify-center gap-1.5 rounded-md bg-[#d9a13b] px-3.5 text-xs font-semibold text-zinc-950 shadow-sm transition-all duration-150 hover:bg-[#e8b459] hover:text-black hover:shadow-[0_0_14px_rgba(217,161,59,0.35)] active:scale-[0.96] active:bg-[#c48e2e] active:text-black focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d9a13b] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0b0e13]"
        >
          <Plus className="h-3.5 w-3.5 stroke-[2.5] transition-transform duration-150 group-hover:rotate-90" />
          <span>New Bill</span>
        </button>
        <div className="pointer-events-none absolute inset-x-0 -bottom-px h-px bg-gradient-to-r from-transparent via-[#d9a13b]/50 to-transparent" />
      </header>

      {/* ---------- main ---------- */}
      <main key={view} className="studio-view flex min-h-0 flex-1 flex-col" aria-label="Workspace">
        {view === 'dashboard' && (
          <DashboardView
            bills={bills}
            settings={settings}
            onNewBill={() => startNewBill()}
            onOpenHistory={() => setView('history')}
            onRepeat={repeatBillFn}
            autoRecurring={settings.autoRecurring === true}
            onToggleAutoRepeat={handleToggleAutoRepeat}
          />
        )}

        {view === 'templates' && (
          <TemplatesView
            templates={templates}
            settings={settings}
            onEdit={openDesigner}
            onCreateBill={(t) => startNewBill(t.id)}
            onChanged={reloadTemplates}
          />
        )}

        {view === 'designer' && designerTemplate && (
          <TemplateDesigner
            template={designerTemplate}
            customVars={customVars}
            buyerFields={settings.buyerFields ?? []}
            customFonts={settings.customFonts ?? []}
            currency={settings.currency}
            globalOffset={{ x: settings.printOffsetX, y: settings.printOffsetY }}
            onSaved={reloadTemplates}
            onBack={() => setView('templates')}
            onOpenSettings={() => setView('settings')}
          />
        )}

        {view === 'new' && (
          <CreateBillView
            templates={templates}
            settings={settings}
            customVars={customVars}
            buyers={buyers}
            bills={bills}
            catalogItems={catalogItems}
            initialItem={initialItem}
            onReloadCatalog={reloadItems}
            editBill={editBill}
            duplicateFrom={duplicateFrom}
            initialTemplateId={initialTemplateId}
            onSaved={() => loadAll()}
            onPrint={handlePrint}
            onBack={() => setView('history')}
          />
        )}

        {view === 'history' && (
          <HistoryView
            bills={bills}
            templates={templates}
            settings={settings}
            onEdit={editBillFn}
            onDuplicate={duplicateBillFn}
            onConvert={convertBillFn}
            onRepeat={repeatBillFn}
            onDeleted={(id) => setBills((bs) => bs.filter((b) => b.id !== id))}
            onUpdated={(u) => setBills((bs) => bs.map((b) => (b.id === u.id ? u : b)))}
            onPrint={handlePrint}
            onPrintReceipt={handleReceiptPrint}
            onNewBill={() => startNewBill()}
          />
        )}

        {view === 'buyers' && (
          <BuyersView
            buyers={buyers}
            bills={bills}
            currency={settings.currency}
            buyerFields={settings.buyerFields ?? []}
            onChanged={reloadBuyers}
          />
        )}

        {view === 'items' && (
          <ItemsView
            items={catalogItems}
            bills={bills}
            currency={settings.currency}
            onChanged={reloadItems}
            onNewBillWithItem={(item) => startNewBill(undefined, item)}
          />
        )}

        {view === 'variables' && <VariablesView customVars={customVars} buyerFields={settings.buyerFields ?? []} onReload={reloadVars} />}

        {view === 'settings' && (
          <SettingsView
            settings={settings}
            onSaved={setSettings}
            onPrintCalibration={() => setCalibrateJob({})}
          />
        )}
      </main>

      {/* ---------- footer ---------- */}
      <footer className="mt-auto flex h-10 shrink-0 items-center justify-between border-t border-[#232b38] bg-[#0d1015] px-4 text-[10px] text-zinc-600">
        <span>
          InvoiceStudio v1.2 · Local JSON storage (<code className="font-mono text-[9px] text-zinc-500">/db</code>)
        </span>
        <span className="tabular">
          {bills.length} bills · {templates.length} templates · {buyers.length} buyers · {catalogItems.length} items · {customVars.length} custom variables
        </span>
      </footer>

      {/* ---------- print root ---------- */}
      <PrintManager
        job={printJob}
        receiptJob={receiptJob}
        calibrateJob={calibrateJob}
        settings={settings}
        onDone={handlePrintDone}
        onReceiptDone={() => setReceiptJob(null)}
        onCalibrateDone={() => setCalibrateJob(null)}
      />
    </div>
  );
}

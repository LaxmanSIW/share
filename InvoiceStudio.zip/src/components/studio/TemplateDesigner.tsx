'use client';

/* ============================================================
 * InvoiceStudio — template designer (WYSIWYG editor)
 * ============================================================ */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Barcode, Check, ChevronLeft, FileDown, Grid3X3, Hash, Image as ImageIcon, Keyboard, Magnet, Minus, QrCode, Redo2, Rows3, Save,
  Square, Table2, Type as TypeIcon, Undo2,
} from 'lucide-react';
import type { BuyerFieldDef, CustomFontDef, PageSizeName, PageConfig, Template, TemplateElement, VariableDef } from '@/lib/studio/types';
import { PAGE_SIZES } from '@/lib/studio/types';
import { DEFAULT_ITEM_COLUMNS } from '@/lib/studio/defaults';
import { effectivePageHeight, rollTableShift } from '@/lib/studio/render';
import { uid } from '@/lib/studio/format';
import DesignerCanvas from './DesignerCanvas';
import PropertiesPanel from './PropertiesPanel';
import LayersPanel from './LayersPanel';
import NumStepper from './NumStepper';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface Props {
  template: Template;
  customVars: VariableDef[];
  buyerFields?: BuyerFieldDef[];
  customFonts?: CustomFontDef[];
  currency: string;
  /** global print offsets from Settings — shown as the fallback placeholder */
  globalOffset?: { x: number; y: number };
  onSaved: (t: Template) => void;
  onBack: () => void;
  onOpenSettings?: () => void;
}

function newElement(type: TemplateElement['type'], z: number): TemplateElement {
  const base: TemplateElement = {
    id: uid(),
    type,
    x: 20,
    y: 20,
    w: 60,
    h: 8,
    zIndex: z,
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontSize: 10,
    fontWeight: 400,
    color: '#1a1a1a',
    align: 'left',
    vAlign: 'top',
    lineHeight: 1.25,
    letterSpacing: 0,
    padding: 0,
    borderWidth: 0,
    borderColor: '#1a1a1a',
    borderRadius: 0,
    opacity: 1,
    bg: 'transparent',
  };
  switch (type) {
    case 'text':
      return { ...base, text: 'New text' };
    case 'image':
      return { ...base, w: 25, h: 20, objectFit: 'contain', src: '' };
    case 'table':
      return {
        ...base, w: 190, h: 45, x: 10, y: 20,
        columns: DEFAULT_ITEM_COLUMNS.map((c) => ({ ...c })),
        headerBg: '#efe9db', headerColor: '#1a1a1a', rowHeight: 7,
        fontSize: 9, borderStyle: 'grid', showZebra: true,
      };
    case 'line':
      return { ...base, w: 50, h: 0.4, borderWidth: 0.4, direction: 'h' };
    case 'rect':
      return { ...base, w: 50, h: 20, bg: '#f4f1ea' };
    case 'pageno':
      return { ...base, w: 40, h: 6, align: 'center', fontSize: 8 };
    case 'qrcode':
      return { ...base, w: 26, h: 26, qrSource: 'upi_amount', qrCustom: '', qrColor: '#1a1a1a' };
    case 'barcode':
      return { ...base, w: 44, h: 16, barcodeData: '{{invoice_no}}', barcodeColor: '#1a1a1a', barcodeShowText: true };
  }
}

export default function TemplateDesigner({ template: initial, customVars, buyerFields, customFonts, globalOffset, onSaved, onBack, onOpenSettings }: Props) {
  const { toast } = useToast();
  const [template, setTemplate] = useState<Template>(() => JSON.parse(JSON.stringify(initial)) as Template);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(0.9);
  const [showGrid, setShowGrid] = useState(true);
  const [snap, setSnap] = useState(true);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  /** roll preview: simulate N item rows (auto-height templates); null = authored layout */
  const [previewRows, setPreviewRows] = useState<number | null>(null);
  /** shift elements automatically when page margins are updated */
  const [shiftWithMargins, setShiftWithMargins] = useState(true);

  // Expandable / resizable property panel state
  const [propPanelWidth, setPropPanelWidth] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('invoicestudio_designer_panel_width');
      if (saved) {
        const n = parseInt(saved, 10);
        if (!isNaN(n) && n >= 260 && n <= 700) return n;
      }
    }
    return 330;
  });
  const [isPropCollapsed, setIsPropCollapsed] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  const startResizing = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    const startX = e.clientX;
    const startW = propPanelWidth;

    const onMouseMove = (moveEvent: MouseEvent) => {
      const delta = startX - moveEvent.clientX; // dragging left increases width
      const newW = Math.max(260, Math.min(650, startW + delta));
      setPropPanelWidth(newW);
    };

    const onMouseUp = () => {
      setIsResizing(false);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      setPropPanelWidth((cur) => {
        try { localStorage.setItem('invoicestudio_designer_panel_width', String(cur)); } catch {}
        return cur;
      });
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  }, [propPanelWidth]);

  const toggleExpandPanel = useCallback(() => {
    setPropPanelWidth((prev) => {
      const next = prev >= 420 ? 320 : 460;
      try { localStorage.setItem('invoicestudio_designer_panel_width', String(next)); } catch {}
      return next;
    });
  }, []);

  const selectedId = selectedIds[selectedIds.length - 1] ?? null;

  // undo / redo
  const past = useRef<TemplateElement[][]>([]);
  const future = useRef<TemplateElement[][]>([]);
  const [histTick, setHistTick] = useState(0);

  const snapshot = useCallback(() => {
    past.current = [...past.current.slice(-49), template.elements.map((e) => ({ ...e }))];
    future.current = [];
    setHistTick((t) => t + 1);
  }, [template.elements]);

  const undo = useCallback(() => {
    if (past.current.length === 0) return;
    const prev = past.current[past.current.length - 1];
    past.current = past.current.slice(0, -1);
    future.current = [...future.current, template.elements.map((e) => ({ ...e }))];
    setTemplate((t) => ({ ...t, elements: prev }));
    setDirty(true);
    setHistTick((x) => x + 1);
  }, [template.elements]);

  const redo = useCallback(() => {
    if (future.current.length === 0) return;
    const next = future.current[future.current.length - 1];
    future.current = future.current.slice(0, -1);
    past.current = [...past.current, template.elements.map((e) => ({ ...e }))];
    setTemplate((t) => ({ ...t, elements: next }));
    setDirty(true);
    setHistTick((x) => x + 1);
  }, [template.elements]);

  const selected = template.elements.find((e) => e.id === selectedId) ?? null;

  /** selection helper — additive toggles membership, otherwise replaces */
  const selectElement = useCallback((id: string | null, additive = false) => {
    setSelectedIds((cur) => {
      if (id === null) return additive ? cur : [];
      if (!additive) return [id];
      return cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    });
    if (id !== null && id !== editingId) setEditingId(null);
  }, [editingId]);

  /** apply patches to many elements at once (group ops) */
  const applyPatches = useCallback((patches: Record<string, Partial<TemplateElement>>, record = false) => {
    if (record) snapshot();
    setTemplate((t) => ({
      ...t,
      elements: t.elements.map((e) => (patches[e.id] ? { ...e, ...patches[e.id] } : e)),
    }));
    setDirty(true);
  }, [snapshot]);

  const updateElement = useCallback((id: string, patch: Partial<TemplateElement>, record = false) => {
    if (record) snapshot();
    setTemplate((t) => ({
      ...t,
      elements: t.elements.map((e) => (e.id === id ? { ...e, ...patch } : e)),
    }));
    setDirty(true);
  }, [snapshot]);

  const addElement = (type: TemplateElement['type']) => {
    snapshot();
    const el = newElement(type, template.elements.length);
    setTemplate((t) => ({ ...t, elements: [...t.elements, el] }));
    setSelectedIds([el.id]);
    setDirty(true);
  };

  const deleteElement = (id: string) => {
    const el = template.elements.find((e) => e.id === id);
    if (el?.locked) return;
    snapshot();
    setTemplate((t) => ({ ...t, elements: t.elements.filter((e) => e.id !== id) }));
    setSelectedIds((cur) => cur.filter((x) => x !== id));
    if (editingId === id) setEditingId(null);
    setDirty(true);
  };

  /** delete every selected, unlocked element (multi-select support) */
  const deleteSelected = () => {
    const ids = new Set(selectedIds);
    const targets = template.elements.filter((e) => ids.has(e.id) && !e.locked);
    if (targets.length === 0) return;
    snapshot();
    const removed = new Set(targets.map((e) => e.id));
    setTemplate((t) => ({ ...t, elements: t.elements.filter((e) => !removed.has(e.id)) }));
    setSelectedIds((cur) => cur.filter((x) => !removed.has(x)));
    setDirty(true);
  };

  const duplicateElement = (id: string) => {
    const el = template.elements.find((e) => e.id === id);
    if (!el) return;
    snapshot();
    const copy: TemplateElement = { ...el, id: uid(), x: el.x + 3, y: el.y + 3, zIndex: el.zIndex + 1 };
    setTemplate((t) => ({ ...t, elements: [...t.elements, copy] }));
    setSelectedIds([copy.id]);
    setDirty(true);
  };

  /** duplicate every selected element (keeps relative positions) */
  const duplicateSelected = () => {
    const ids = new Set(selectedIds);
    const targets = template.elements.filter((e) => ids.has(e.id) && !e.locked);
    if (targets.length === 0) return;
    snapshot();
    const topZ = template.elements.reduce((m, e) => Math.max(m, e.zIndex ?? 0), 0);
    const copies = targets.map((el, i) => ({ ...el, id: uid(), x: el.x + 3, y: el.y + 3, zIndex: topZ + 1 + i }));
    setTemplate((t) => ({ ...t, elements: [...t.elements, ...copies] }));
    setSelectedIds(copies.map((c) => c.id));
    setDirty(true);
  };

  /* ---------- multi-select alignment / distribution ---------- */

  const alignSelected = (mode: 'left' | 'cx' | 'right' | 'top' | 'cy' | 'bottom') => {
    const ids = new Set(selectedIds);
    const targets = template.elements.filter((e) => ids.has(e.id) && !e.locked);
    if (targets.length < 2) return;
    const minX = Math.min(...targets.map((e) => e.x));
    const maxX = Math.max(...targets.map((e) => e.x + e.w));
    const minY = Math.min(...targets.map((e) => e.y));
    const maxY = Math.max(...targets.map((e) => e.y + e.h));
    const patches: Record<string, Partial<TemplateElement>> = {};
    for (const e of targets) {
      if (mode === 'left') patches[e.id] = { x: minX };
      else if (mode === 'right') patches[e.id] = { x: Math.round((maxX - e.w) * 100) / 100 };
      else if (mode === 'cx') patches[e.id] = { x: Math.round(((minX + maxX) / 2 - e.w / 2) * 100) / 100 };
      else if (mode === 'top') patches[e.id] = { y: minY };
      else if (mode === 'bottom') patches[e.id] = { y: Math.round((maxY - e.h) * 100) / 100 };
      else if (mode === 'cy') patches[e.id] = { y: Math.round(((minY + maxY) / 2 - e.h / 2) * 100) / 100 };
    }
    applyPatches(patches, true);
  };

  const distributeSelected = (axis: 'h' | 'v') => {
    const ids = new Set(selectedIds);
    const targets = template.elements
      .filter((e) => ids.has(e.id) && !e.locked)
      .sort((a, b) => (axis === 'h' ? a.x - b.x : a.y - b.y));
    if (targets.length < 3) return;
    const patches: Record<string, Partial<TemplateElement>> = {};
    if (axis === 'h') {
      const first = targets[0];
      const last = targets[targets.length - 1];
      const span = (last.x + last.w) - first.x;
      const totalW = targets.reduce((s, e) => s + e.w, 0);
      const gap = targets.length > 1 ? (span - totalW) / (targets.length - 1) : 0;
      let cursor = first.x;
      for (const e of targets) {
        patches[e.id] = { x: Math.round(cursor * 100) / 100 };
        cursor += e.w + gap;
      }
    } else {
      const first = targets[0];
      const last = targets[targets.length - 1];
      const span = (last.y + last.h) - first.y;
      const totalH = targets.reduce((s, e) => s + e.h, 0);
      const gap = targets.length > 1 ? (span - totalH) / (targets.length - 1) : 0;
      let cursor = first.y;
      for (const e of targets) {
        patches[e.id] = { y: Math.round(cursor * 100) / 100 };
        cursor += e.h + gap;
      }
    }
    applyPatches(patches, true);
  };

  const changeZ = (id: string, dir: -1 | 1) => {
    const el = template.elements.find((e) => e.id === id);
    if (!el) return;
    updateElement(id, { zIndex: Math.max(0, el.zIndex + dir) }, true);
  };

  const updatePage = (patch: Partial<PageConfig>) => {
    setTemplate((t) => ({ ...t, page: { ...t.page, ...patch } }));
    setDirty(true);
  };

  const updateMargin = (side: 'top' | 'bottom' | 'left' | 'right', val: number) => {
    const newVal = Math.max(0, val);
    const oldVal = template.page.margin[side];
    const delta = newVal - oldVal;
    if (delta === 0) return;

    snapshot();
    let nextElements = template.elements;
    if (shiftWithMargins) {
      if (side === 'left') {
        nextElements = template.elements.map((el) => {
          if (el.locked) return el;
          const nx = Math.round(Math.max(0, Math.min(template.page.width - el.w, el.x + delta)) * 100) / 100;
          return { ...el, x: nx };
        });
      } else if (side === 'top') {
        nextElements = template.elements.map((el) => {
          if (el.locked) return el;
          const ny = Math.round(Math.max(0, Math.min(template.page.height - el.h, el.y + delta)) * 100) / 100;
          return { ...el, y: ny };
        });
      }
    }

    setTemplate((t) => ({
      ...t,
      page: { ...t.page, margin: { ...t.page.margin, [side]: newVal } },
      elements: nextElements,
    }));
    setDirty(true);
  };

  const alignElementsToMargins = () => {
    if (template.elements.length === 0) return;
    snapshot();
    const unlocked = template.elements.filter((e) => !e.locked && !e.hidden);
    if (unlocked.length === 0) return;

    const minX = Math.min(...unlocked.map((e) => e.x));
    const minY = Math.min(...unlocked.map((e) => e.y));
    const shiftX = template.page.margin.left - minX;
    const shiftY = template.page.margin.top - minY;
    const contentWidth = Math.max(10, template.page.width - template.page.margin.left - template.page.margin.right);

    const updated = template.elements.map((el) => {
      if (el.locked || el.hidden) return el;
      const nx = Math.round(Math.max(0, Math.min(template.page.width - el.w, el.x + shiftX)) * 100) / 100;
      const ny = Math.round(Math.max(0, Math.min(template.page.height - el.h, el.y + shiftY)) * 100) / 100;
      let nw = el.w;
      if ((el.type === 'table' || el.type === 'line' || el.type === 'rect') && el.w >= template.page.width - 30) {
        nw = Math.round(contentWidth * 100) / 100;
      }
      return { ...el, x: nx, y: ny, w: nw };
    });

    setTemplate((t) => ({ ...t, elements: updated }));
    setDirty(true);
    toast({
      title: 'Elements aligned to margins',
      description: `Shifted by X: ${shiftX >= 0 ? `+${shiftX.toFixed(1)}` : shiftX.toFixed(1)}mm, Y: ${shiftY >= 0 ? `+${shiftY.toFixed(1)}` : shiftY.toFixed(1)}mm`,
    });
  };

  const setPage = (size: PageSizeName) => {
    if (size === 'Custom') {
      updatePage({ sizeName: 'Custom', autoHeight: false });
      return;
    }
    const [w, h] = PAGE_SIZES[size];
    const landscape = template.page.orientation === 'landscape';
    updatePage({
      sizeName: size,
      width: landscape ? h : w,
      height: landscape ? w : h,
      // thermal rolls print continuously by default
      autoHeight: size === 'Thermal 80' || size === 'Thermal 58',
    });
  };

  const setOrientation = (orientation: 'portrait' | 'landscape') => {
    if (orientation === template.page.orientation) return;
    updatePage({ orientation, width: template.page.height, height: template.page.width });
  };

  /* keyboard shortcuts */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo(); else undo();
        return;
      }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
      if (mod && e.key.toLowerCase() === 'd' && selectedIds.length > 0) {
        e.preventDefault(); duplicateSelected(); return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedIds.length > 0) {
        e.preventDefault(); deleteSelected(); return;
      }
      if (e.key === 'Escape') { setSelectedIds([]); return; }
      if (e.key === '?') { e.preventDefault(); setShowShortcuts((v) => !v); return; }
      if (selectedIds.length > 0 && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
        const d = e.shiftKey ? 5 : 1;
        const ids = new Set(selectedIds);
        const targets = template.elements.filter((x) => ids.has(x.id) && !x.locked);
        if (targets.length === 0) return;
        const patches: Record<string, Partial<TemplateElement>> = {};
        for (const el of targets) {
          patches[el.id] =
            e.key === 'ArrowUp' ? { y: el.y - d } :
            e.key === 'ArrowDown' ? { y: el.y + d } :
            e.key === 'ArrowLeft' ? { x: el.x - d } : { x: el.x + d };
        }
        applyPatches(patches);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
     
  }, [selectedIds, template.elements, undo, redo, applyPatches]);

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch(`/api/templates/${template.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        // printOffset null (not undefined) so an explicit "clear" survives JSON.stringify
        body: JSON.stringify({
          ...template,
          name: template.name.trim() || 'Untitled template',
          printOffsetX: template.printOffsetX ?? null,
          printOffsetY: template.printOffsetY ?? null,
        }),
      });
      if (!res.ok) throw new Error('Save failed');
      const saved = (await res.json()) as Template;
      setTemplate(saved);
      setDirty(false);
      toast({ title: 'Template saved', description: `“${saved.name}” updated successfully.` });
      onSaved(saved);
    } catch {
      toast({ title: 'Save failed', description: 'Could not save the template.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const zoomPct = Math.round(zoom * 100);
  const canUndo = past.current.length > 0 && histTick >= 0;
  const canRedo = future.current.length > 0 && histTick >= 0;

  // thermal/roll templates: the canvas page grows with the content.
  // with the roll preview active it matches the simulated row count instead.
  const rowsForHeight = previewRows ?? 4;
  const designerPage = useMemo<PageConfig>(
    () => ({ ...template.page, height: effectivePageHeight(template, rowsForHeight) }),
    [template, rowsForHeight],
  );

  /** roll preview: shift every element below the items table by the row-count delta */
  const canvasElements = useMemo(() => {
    if (previewRows == null) return template.elements;
    const shift = rollTableShift(template, previewRows);
    if (!shift) return template.elements;
    const tableTop = template.elements.find((e) => e.type === 'table')?.y ?? Infinity;
    return template.elements.map((e) => (e.y > tableTop ? { ...e, y: Math.round((e.y + shift) * 100) / 100 } : e));
  }, [template, previewRows]);
  const rollLength = Math.round(effectivePageHeight(template, previewRows ?? 4));

  const insertButtons = useMemo(
    () => [
      { type: 'text' as const, icon: <TypeIcon className="h-3.5 w-3.5" />, label: 'Text' },
      { type: 'image' as const, icon: <ImageIcon className="h-3.5 w-3.5" />, label: 'Logo' },
      { type: 'table' as const, icon: <Table2 className="h-3.5 w-3.5" />, label: 'Items' },
      { type: 'rect' as const, icon: <Square className="h-3.5 w-3.5" />, label: 'Box' },
      { type: 'line' as const, icon: <Minus className="h-3.5 w-3.5" />, label: 'Line' },
      { type: 'pageno' as const, icon: <Hash className="h-3.5 w-3.5" />, label: 'Page#' },
      { type: 'qrcode' as const, icon: <QrCode className="h-3.5 w-3.5" />, label: 'QR' },
      { type: 'barcode' as const, icon: <Barcode className="h-3.5 w-3.5" />, label: 'Barcode' },
    ],
    [],
  );

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {/* ---------- toolbar ---------- */}
      <div className="flex flex-wrap items-center gap-1.5 border-b border-[#232b38] bg-[#0f1319] px-3 py-2">
        <Button variant="ghost" size="sm" className="h-7 gap-1.5 px-2 text-xs text-zinc-300" onClick={onBack}>
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </Button>
        <Separator orientation="vertical" className="mx-1 h-5 bg-[#232b38]" />
        <Input
          className="h-7 w-52 border-transparent bg-transparent text-sm font-semibold text-zinc-100 hover:border-[#2a3342]"
          value={template.name}
          onChange={(e) => { setTemplate((t) => ({ ...t, name: e.target.value })); setDirty(true); }}
          placeholder="Template name"
        />
        {dirty && <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-400">unsaved</span>}

        <Separator orientation="vertical" className="mx-1 h-5 bg-[#232b38]" />

        {/* insert */}
        {insertButtons.map((b) => (
          <button
            key={b.type}
            type="button"
            onClick={() => addElement(b.type)}
            className="flex h-7 items-center gap-1.5 rounded bg-[#171d27] px-2 text-[11px] text-zinc-300 transition-colors hover:bg-[#202936] hover:text-white"
            title={`Add ${b.label}`}
          >
            {b.icon} {b.label}
          </button>
        ))}

        <Separator orientation="vertical" className="mx-1 h-5 bg-[#232b38]" />

        {/* page setup */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="flex h-7 items-center gap-1.5 rounded bg-[#171d27] px-2 text-[11px] text-zinc-300 hover:bg-[#202936]">
              <FileDown className="h-3.5 w-3.5" />
              {template.page.sizeName} · {template.page.orientation === 'portrait' ? 'P' : 'L'}
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-80 border-[#2a3342] bg-[#12161d] p-3 text-zinc-200" align="start">
            <div className="space-y-3">
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Page size</Label>
                <Select value={template.page.sizeName} onValueChange={(v) => setPage(v as PageSizeName)}>
                  <SelectTrigger className="mt-1 h-8 border-[#2a3342] bg-[#0d1117] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {(['A4', 'A5', 'Letter', 'Legal', 'Thermal 80', 'Thermal 58', 'Custom'] as PageSizeName[]).map((s) => (
                      <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {(template.page.sizeName === 'Thermal 80' || template.page.sizeName === 'Thermal 58') && (
                <button
                  type="button"
                  onClick={() => updatePage({ autoHeight: !template.page.autoHeight })}
                  title="Print as one continuous receipt whose length follows the content"
                  className={`h-7 w-full rounded text-[10px] transition-colors ${
                    template.page.autoHeight ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'
                  }`}
                >
                  Continuous roll (auto height)
                </button>
              )}
              <div className="flex gap-2">
                {(['portrait', 'landscape'] as const).map((o) => (
                  <button
                    key={o}
                    type="button"
                    onClick={() => setOrientation(o)}
                    className={`h-7 flex-1 rounded text-[10px] uppercase tracking-wider ${
                      template.page.orientation === o ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400'
                    }`}
                  >
                    {o}
                  </button>
                ))}
              </div>
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Margins (mm)</Label>
                  <label className="flex items-center gap-1.5 text-[9px] text-zinc-400 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={shiftWithMargins}
                      onChange={(e) => setShiftWithMargins(e.target.checked)}
                      className="rounded border-zinc-700 bg-zinc-900 text-[#d9a13b] focus:ring-0 focus:ring-offset-0"
                    />
                    Shift elements
                  </label>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {(['top', 'bottom', 'left', 'right'] as const).map((m) => (
                    <div key={m}>
                      <Label className="text-[9px] uppercase text-zinc-500 mb-1 block">{m}</Label>
                      <NumStepper
                        value={template.page.margin[m]}
                        step={1}
                        shiftStep={5}
                        min={0}
                        max={60}
                        suffix="mm"
                        size="sm"
                        onChange={(val) => updateMargin(m, val)}
                      />
                    </div>
                  ))}
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={alignElementsToMargins}
                  className="mt-2.5 h-7 w-full border-[#2a3342] text-[10px] text-zinc-300 hover:bg-[#1f2633]"
                >
                  Align all elements to margins
                </Button>
                <p className="mt-1.5 text-[9px] leading-relaxed text-zinc-600">
                  Dashed guides on canvas show the printable boundary. Elements snap to them when dragged.
                </p>
              </div>
              {template.page.sizeName === 'Custom' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[9px] uppercase text-zinc-500 mb-1 block">Width</Label>
                    <NumStepper
                      value={Math.round(template.page.width * 10) / 10}
                      step={1}
                      shiftStep={10}
                      min={50}
                      max={1000}
                      suffix="mm"
                      size="sm"
                      onChange={(val) => updatePage({ width: Math.max(50, val) })}
                    />
                  </div>
                  <div>
                    <Label className="text-[9px] uppercase text-zinc-500 mb-1 block">Height</Label>
                    <NumStepper
                      value={Math.round(template.page.height * 10) / 10}
                      step={1}
                      shiftStep={10}
                      min={50}
                      max={1000}
                      suffix="mm"
                      size="sm"
                      onChange={(val) => updatePage({ height: Math.max(50, val) })}
                    />
                  </div>
                </div>
              )}
              <Separator className="bg-[#232b38]" />
              <div>
                <Label className="text-[9px] uppercase tracking-wider text-zinc-500">
                  Print offset (mm) — pre-printed stock
                </Label>
                <div className="mt-1.5 grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[9px] uppercase text-zinc-500 mb-1 block">Shift X</Label>
                    <NumStepper
                      value={template.printOffsetX ?? (globalOffset?.x ?? 0)}
                      step={0.5}
                      shiftStep={2}
                      min={-100}
                      max={100}
                      suffix="mm"
                      size="sm"
                      onChange={(val) => setTemplate((t) => ({ ...t, printOffsetX: val }))}
                    />
                  </div>
                  <div>
                    <Label className="text-[9px] uppercase text-zinc-500 mb-1 block">Shift Y</Label>
                    <NumStepper
                      value={template.printOffsetY ?? (globalOffset?.y ?? 0)}
                      step={0.5}
                      shiftStep={2}
                      min={-100}
                      max={100}
                      suffix="mm"
                      size="sm"
                      onChange={(val) => setTemplate((t) => ({ ...t, printOffsetY: val }))}
                    />
                  </div>
                </div>
                <p className="mt-1 text-[9px] leading-relaxed text-zinc-600">
                  Empty/default = global offset from Settings.
                </p>
              </div>
            </div>
          </PopoverContent>
        </Popover>

        <button
          type="button"
          onClick={() => setShowGrid((v) => !v)}
          className={`flex h-7 items-center gap-1 rounded px-2 text-[11px] ${showGrid ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#171d27] text-zinc-300'}`}
          title="Toggle 5mm grid"
        >
          <Grid3X3 className="h-3.5 w-3.5" /> Grid
        </button>
        <button
          type="button"
          onClick={() => setSnap((v) => !v)}
          className={`flex h-7 items-center gap-1 rounded px-2 text-[11px] ${snap ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#171d27] text-zinc-300'}`}
          title="Snap to grid (hold Alt to bypass)"
        >
          <Magnet className="h-3.5 w-3.5" /> Snap
        </button>

        {/* roll preview — simulate N item rows on continuous-roll templates */}
        {template.page.autoHeight && (
          <Popover>
            <PopoverTrigger asChild>
              <button
                type="button"
                className={`flex h-7 items-center gap-1 rounded px-2 text-[11px] ${
                  previewRows != null ? 'bg-sky-600 font-semibold text-white' : 'bg-[#171d27] text-zinc-300 hover:bg-[#202936]'
                }`}
                title="Preview how the layout shifts with a different number of item rows"
              >
                <Rows3 className="h-3.5 w-3.5" />
                {previewRows != null ? `${previewRows} rows` : 'Rows'}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-60 border-[#2a3342] bg-[#12161d] p-3 text-zinc-200" align="start">
              <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Roll preview</div>
              <p className="mb-2 mt-1 text-[10px] leading-relaxed text-zinc-500">
                Simulate the receipt with N item rows — everything below the table shifts exactly like the printed roll.
              </p>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  type="button"
                  onClick={() => setPreviewRows(null)}
                  className={`h-7 rounded text-[10px] ${previewRows == null ? 'bg-[#d9a13b] font-semibold text-black' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'}`}
                >
                  Off
                </button>
                {[1, 2, 3, 5, 8, 12, 18].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setPreviewRows(n)}
                    className={`h-7 rounded text-[10px] ${previewRows === n ? 'bg-sky-600 font-semibold text-white' : 'bg-[#0d1117] text-zinc-400 hover:bg-[#171d27]'}`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[10px] text-zinc-600">
                Content height ≈ <span className="font-mono text-[#e8c064]">{rollLength}mm</span> · turn Off to edit positions.
              </p>
            </PopoverContent>
          </Popover>
        )}

        <Separator orientation="vertical" className="mx-1 h-5 bg-[#232b38]" />

        <Button variant="ghost" size="icon" className="h-7 w-7" title="Undo (Ctrl+Z)" disabled={!canUndo} onClick={undo}>
          <Undo2 className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" title="Redo (Ctrl+Shift+Z)" disabled={!canRedo} onClick={redo}>
          <Redo2 className="h-3.5 w-3.5" />
        </Button>

        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setShowShortcuts(true)}
            className="flex h-7 w-7 items-center justify-center rounded bg-[#171d27] text-zinc-400 hover:bg-[#202936] hover:text-[#d9a13b]"
            title="Keyboard shortcuts (?)"
          >
            <Keyboard className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.25, Math.round((z - 0.1) * 100) / 100))}
            className="h-7 w-6 rounded bg-[#171d27] text-xs text-zinc-300 hover:bg-[#202936]"
          >−</button>
          <span className="tabular w-10 text-center text-[11px] text-zinc-400">{zoomPct}%</span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2, Math.round((z + 0.1) * 100) / 100))}
            className="h-7 w-6 rounded bg-[#171d27] text-xs text-zinc-300 hover:bg-[#202936]"
          >+</button>
          <Button
            size="sm"
            className="h-7 gap-1.5 bg-[#d9a13b] px-3 text-xs font-semibold text-black hover:bg-[#e5b055]"
            disabled={saving}
            onClick={save}
          >
            {saving ? <Check className="h-3.5 w-3.5 animate-pulse" /> : <Save className="h-3.5 w-3.5" />}
            Save
          </Button>
        </div>
      </div>

      {/* ---------- workspace ---------- */}
      <div className="flex min-h-0 flex-1">
        {/* left: insert + layers */}
        <div className="flex w-56 shrink-0 flex-col border-r border-[#232b38] bg-[#12161d]">
          <LayersPanel
            elements={template.elements}
            selectedId={selectedId}
            onSelect={(id) => selectElement(id, false)}
            onToggleHidden={(id) => {
              const el = template.elements.find((e) => e.id === id);
              if (el) updateElement(id, { hidden: !el.hidden }, true);
            }}
            onToggleLocked={(id) => {
              const el = template.elements.find((e) => e.id === id);
              if (el) updateElement(id, { locked: !el.locked }, true);
            }}
            onDelete={deleteElement}
          />
        </div>

        {/* center: canvas */}
        <DesignerCanvas
          page={designerPage}
          elements={canvasElements}
          selectedIds={selectedIds}
          zoom={zoom}
          showGrid={showGrid}
          snap={snap}
          editingId={editingId}
          onSelect={selectElement}
          onCommitDrag={(patches) => applyPatches(patches)}
          onBeginInteraction={snapshot}
          onStartEdit={(id) => {
            snapshot();
            setSelectedIds([id]);
            setEditingId(id);
          }}
          onEditText={(id, text) => updateElement(id, { text })}
          onEndEdit={() => setEditingId(null)}
        />

        {/* right: properties */}
        {/* right: properties (resizable & expandable) */}
        <div
          className="relative shrink-0 border-l border-[#232b38] bg-[#12161d] flex flex-col transition-[width] duration-150 ease-out"
          style={{ width: isPropCollapsed ? '42px' : `${propPanelWidth}px` }}
        >
          {/* Draggable resize handle on left border */}
          {!isPropCollapsed && (
            <div
              className={`absolute top-0 bottom-0 -left-1.5 w-3 z-20 cursor-col-resize hover:bg-[#d9a13b]/30 flex items-center justify-center transition-colors group ${
                isResizing ? 'bg-[#d9a13b]/50' : ''
              }`}
              title="Drag to resize properties panel (Double-click to toggle wide/standard)"
              onMouseDown={startResizing}
              onDoubleClick={toggleExpandPanel}
            >
              <div className="h-8 w-1 bg-zinc-600/40 rounded-full group-hover:bg-[#d9a13b]" />
            </div>
          )}

          {isPropCollapsed ? (
            <div className="h-full flex flex-col items-center py-4 text-zinc-500">
              <button
                type="button"
                onClick={() => setIsPropCollapsed(false)}
                title="Expand Properties Panel"
                className="p-1.5 rounded bg-[#181f2a] text-[#e8c064] hover:bg-[#232b38] border border-[#2a3342] shadow-sm mb-4 transition-colors"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="[writing-mode:vertical-lr] rotate-180 text-[10px] font-medium tracking-wider uppercase text-zinc-400 select-none">
                Properties
              </span>
            </div>
          ) : (
            <div className="h-full w-full overflow-hidden flex flex-col">
              <PropertiesPanel
                el={selected}
                multiCount={selectedIds.length}
                customVars={customVars}
                buyerFields={buyerFields}
                customFonts={customFonts}
                isExpanded={propPanelWidth >= 420}
                onToggleExpand={toggleExpandPanel}
                onCollapse={() => setIsPropCollapsed(true)}
                onChange={(patch) => selected && updateElement(selected.id, patch, true)}
                onZ={(dir) => selected && changeZ(selected.id, dir)}
                onDuplicate={() => (selectedIds.length > 1 ? duplicateSelected() : selected && duplicateElement(selected.id))}
                onDelete={() => (selectedIds.length > 1 ? deleteSelected() : selected && deleteElement(selected.id))}
                onAlign={alignSelected}
                onDistribute={distributeSelected}
                onOpenSettings={onOpenSettings}
              />
            </div>
          )}
        </div>
      </div>

      {/* ---------- keyboard shortcuts ---------- */}
      <Dialog open={showShortcuts} onOpenChange={setShowShortcuts}>
        <DialogContent className="max-w-lg border-[#2a3342] bg-[#12161d] p-0 text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] px-5 py-3">
            <DialogTitle className="flex items-center gap-2 text-sm">
              <Keyboard className="h-4 w-4 text-[#d9a13b]" /> Designer keyboard shortcuts
            </DialogTitle>
            <DialogDescription className="sr-only">
              Every canvas shortcut for fast designing.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-x-6 gap-y-1.5 px-5 py-4 text-xs sm:grid-cols-2">
            {([
              ['Click', 'select element'],
              ['Shift / Ctrl + click', 'add to selection'],
              ['Double-click text', 'edit text in place'],
              ['Drag', 'move (snaps to grid)'],
              ['Hold Alt + drag', 'bypass snapping'],
              ['Arrow keys', 'nudge 1 mm'],
              ['Shift + arrows', 'nudge 5 mm'],
              ['Ctrl + D', 'duplicate selection'],
              ['Delete / Backspace', 'delete selection'],
              ['Ctrl + Z', 'undo'],
              ['Ctrl + Shift + Z / Ctrl + Y', 'redo'],
              ['Escape', 'clear selection'],
            ] as const).map(([k, d]) => (
              <div key={k} className="flex items-center justify-between gap-3 border-b border-[#1a212c] py-1.5 last:border-0">
                <kbd className="whitespace-nowrap rounded border border-[#2a3342] bg-[#0d1117] px-1.5 py-0.5 font-mono text-[10px] text-[#e8c064]">
                  {k}
                </kbd>
                <span className="text-right text-[11px] text-zinc-400">{d}</span>
              </div>
            ))}
          </div>
          <p className="border-t border-[#232b38] px-5 py-3 text-[10px] leading-relaxed text-zinc-600">
            Select multiple elements to unlock the align & distribute tools in the properties panel.
          </p>
        </DialogContent>
      </Dialog>
    </div>
  );
}

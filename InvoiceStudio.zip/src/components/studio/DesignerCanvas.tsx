'use client';

/* ============================================================
 * InvoiceStudio — designer canvas
 * Drag, resize (8 handles), grid, snap, selection, keyboard nudges
 * ============================================================ */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { PageConfig, TemplateElement } from '@/lib/studio/types';
import ElementRenderer, { MM } from './ElementRenderer';

export type HandleId = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w';

interface DragState {
  mode: 'move' | 'resize';
  handle?: HandleId;
  startX: number;
  startY: number;
  orig: TemplateElement;
  /** positions of every group member at drag start (group move) */
  group: { id: string; x: number; y: number; w: number; h: number }[];
}

interface Guides {
  v: number[]; // vertical guide x positions (mm)
  h: number[]; // horizontal guide y positions (mm)
}

const NO_GUIDES: Guides = { v: [], h: [] };

interface Props {
  page: PageConfig;
  elements: TemplateElement[];
  selectedIds: string[];
  zoom: number;
  showGrid: boolean;
  snap: boolean;
  editingId: string | null;
  onSelect: (id: string | null, additive: boolean) => void;
  onCommitDrag: (patches: Record<string, Partial<TemplateElement>>) => void;
  onBeginInteraction: () => void; // snapshot for undo
  onStartEdit: (id: string) => void;
  onEditText: (id: string, text: string) => void;
  onEndEdit: (commit: boolean) => void;
}

const MIN_MM = 2;
const PAD = 28; // workspace padding around page (px)

function snapVal(v: number, enabled: boolean, grid: number): number {
  if (!enabled) return Math.round(v * 100) / 100;
  return Math.round(v / grid) * grid;
}

export default function DesignerCanvas({
  page,
  elements,
  selectedIds,
  zoom,
  showGrid,
  snap,
  editingId,
  onSelect,
  onCommitDrag,
  onBeginInteraction,
  onStartEdit,
  onEditText,
  onEndEdit,
}: Props) {
  const dragRef = useRef<DragState | null>(null);
  const [dragging, setDragging] = useState(false);
  const [guides, setGuides] = useState<Guides>(NO_GUIDES);

  const selected = elements.find((e) => e.id === selectedIds[selectedIds.length - 1]) ?? null;
  const editing = elements.find((e) => e.id === editingId) ?? null;

  const startDrag = useCallback(
    (e: React.PointerEvent, el: TemplateElement, mode: 'move' | 'resize', handle?: HandleId) => {
      if (el.locked) return;
      e.stopPropagation();
      e.preventDefault();
      const additive = e.shiftKey || e.ctrlKey || e.metaKey;
      if (additive) {
        // modifier-click only toggles selection — no drag
        onSelect(el.id, true);
        return;
      }
      // plain click: if the element belongs to an existing multi-selection,
      // drag the whole group; otherwise select it alone and drag it
      const isGroupPick = selectedIds.includes(el.id) && selectedIds.length > 1;
      if (!isGroupPick) onSelect(el.id, false);
      const memberIds = isGroupPick ? selectedIds : [el.id];
      const group = memberIds
        .map((id) => elements.find((x) => x.id === id))
        .filter((x): x is TemplateElement => !!x && !x.locked && !x.hidden)
        .map((x) => ({ id: x.id, x: x.x, y: x.y, w: x.w, h: x.h }));
      onBeginInteraction();
      dragRef.current = { mode, handle, startX: e.clientX, startY: e.clientY, orig: { ...el }, group };
      setDragging(true);
    },
    [onSelect, onBeginInteraction, selectedIds, elements],
  );

  useEffect(() => {
    if (!dragging) return;
    const grid = showGrid ? 5 : 1;
    /** screen-space snap threshold in mm (~6px) */
    const thr = Math.max(0.6, 6 / (MM * zoom));
    const others = elements.filter((e) => e.id !== dragRef.current?.orig.id && !e.hidden);
    // alignment targets: other elements' edges & centres + page edges/centre + margin guides
    const targetsX = [
      0,
      page.margin.left,
      page.width / 2,
      page.width - page.margin.right,
      page.width,
    ].filter((v) => v >= 0 && v <= page.width);
    const targetsY = [
      0,
      page.margin.top,
      page.height / 2,
      page.height - page.margin.bottom,
      page.height,
    ].filter((v) => v >= 0 && v <= page.height);
    for (const e of others) {
      targetsX.push(e.x, e.x + e.w / 2, e.x + e.w);
      targetsY.push(e.y, e.y + e.h / 2, e.y + e.h);
    }
    /** snap the closest candidate edge to the closest target; returns guide position or null */
    const align = (
      cands: { off: number; value: number }[],
      targets: number[],
    ): { delta: number; target: number } | null => {
      let best: { delta: number; target: number } | null = null;
      for (const c of cands) {
        for (const t of targets) {
          const delta = c.value - t;
          if (Math.abs(delta) <= thr && (!best || Math.abs(delta) < Math.abs(best.delta))) {
            best = { delta, target: t };
          }
        }
      }
      return best;
    };

    const onMove = (e: PointerEvent) => {
      const st = dragRef.current;
      if (!st) return;
      const k = MM * zoom;
      const dx = (e.clientX - st.startX) / k;
      const dy = (e.clientY - st.startY) / k;
      const o = st.orig;
      const alt = e.altKey; // hold Alt to bypass snap + alignment
      const sn = (v: number) => snapVal(v, snap && !alt, grid);
      const clampX = (x: number) => Math.max(0, Math.min(page.width - o.w, x));
      const clampY = (y: number) => Math.max(0, Math.min(page.height - o.h, y));

      if (st.mode === 'move') {
        let nx = sn(o.x + dx);
        let ny = sn(o.y + dy);
        const gv: number[] = [];
        const gh: number[] = [];
        if (snap && !alt) {
          const bx = align(
            [
              { off: 0, value: nx },
              { off: o.w / 2, value: nx + o.w / 2 },
              { off: o.w, value: nx + o.w },
            ],
            targetsX,
          );
          if (bx) {
            nx -= bx.delta;
            gv.push(bx.target);
          }
          const by = align(
            [
              { off: 0, value: ny },
              { off: o.h / 2, value: ny + o.h / 2 },
              { off: o.h, value: ny + o.h },
            ],
            targetsY,
          );
          if (by) {
            ny -= by.delta;
            gh.push(by.target);
          }
        }
        setGuides({ v: gv, h: gh });
        if (st.group.length > 1) {
          // group move — apply the primary's delta to every member, clamped per member
          const deltaX = nx - o.x;
          const deltaY = ny - o.y;
          const patches: Record<string, Partial<TemplateElement>> = {};
          for (const m of st.group) {
            patches[m.id] = {
              x: Math.round(Math.max(0, Math.min(page.width - m.w, m.x + deltaX)) * 100) / 100,
              y: Math.round(Math.max(0, Math.min(page.height - m.h, m.y + deltaY)) * 100) / 100,
            };
          }
          onCommitDrag(patches);
        } else {
          onCommitDrag({ [o.id]: { x: clampX(nx), y: clampY(ny) } });
        }
        return;
      }

      // resize
      const h = st.handle ?? 'se';
      let w = o.w;
      let height = o.h;
      if (h.includes('e')) w = o.w + dx;
      if (h.includes('s')) height = o.h + dy;
      if (h.includes('w')) w = o.w - dx;
      if (h.includes('n')) height = o.h - dy;
      const minH = o.type === 'line' ? 0.4 : MIN_MM;
      w = Math.max(minH, sn(w));
      height = Math.max(minH, sn(height));
      const patch: Partial<TemplateElement> = { w, h: height };
      const gv: number[] = [];
      const gh: number[] = [];
      if (h.includes('w')) {
        let px = sn(o.x + (o.w - w));
        if (snap && !alt) {
          const best = align([{ off: 0, value: px }], targetsX);
          if (best) {
            px = best.target;
            gv.push(best.target);
          }
        }
        patch.x = clampX(px);
      }
      if (h.includes('e') && snap && !alt) {
        const best = align([{ off: 0, value: o.x + w }], targetsX);
        if (best) {
          w -= best.delta;
          patch.w = Math.max(minH, w);
          gv.push(best.target);
        }
      }
      if (h.includes('n')) {
        let py = sn(o.y + (o.h - height));
        if (snap && !alt) {
          const best = align([{ off: 0, value: py }], targetsY);
          if (best) {
            py = best.target;
            gh.push(best.target);
          }
        }
        patch.y = clampY(py);
      }
      if (h.includes('s') && snap && !alt) {
        const best = align([{ off: 0, value: o.y + height }], targetsY);
        if (best) {
          height -= best.delta;
          patch.h = Math.max(minH, height);
          gh.push(best.target);
        }
      }
      setGuides({ v: gv, h: gh });
      onCommitDrag({ [o.id]: patch });
    };
    const onUp = () => {
      dragRef.current = null;
      setDragging(false);
      setGuides(NO_GUIDES);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, [dragging, zoom, snap, showGrid, onCommitDrag, page.width, page.height, elements]);

  const sorted = [...elements].filter((e) => !e.hidden).sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0));
  const workspaceW = page.width * MM * zoom + PAD * 2;
  const workspaceH = page.height * MM * zoom + PAD * 2;
  const handleSizeMm = 8 / (MM * zoom); // constant screen size handles

  const handles: { id: HandleId; cx: number; cy: number; cursor: string }[] = selected
    ? [
        { id: 'nw', cx: selected.x, cy: selected.y, cursor: 'nwse-resize' },
        { id: 'n', cx: selected.x + selected.w / 2, cy: selected.y, cursor: 'ns-resize' },
        { id: 'ne', cx: selected.x + selected.w, cy: selected.y, cursor: 'nesw-resize' },
        { id: 'e', cx: selected.x + selected.w, cy: selected.y + selected.h / 2, cursor: 'ew-resize' },
        { id: 'se', cx: selected.x + selected.w, cy: selected.y + selected.h, cursor: 'nwse-resize' },
        { id: 's', cx: selected.x + selected.w / 2, cy: selected.y + selected.h, cursor: 'ns-resize' },
        { id: 'sw', cx: selected.x, cy: selected.y + selected.h, cursor: 'nesw-resize' },
        { id: 'w', cx: selected.x, cy: selected.y + selected.h / 2, cursor: 'ew-resize' },
      ]
    : [];

  return (
    <div
      className="studio-scroll relative flex-1 overflow-auto"
      style={{ background: '#0d1015' }}
      onPointerDown={() => onSelect(null, false)}
    >
      <div style={{ width: workspaceW, height: workspaceH, position: 'relative' }}>
        {/* page */}
        <div
          onPointerDown={(e) => e.stopPropagation()}
          style={{
            position: 'absolute',
            left: PAD,
            top: PAD,
            width: `${page.width}mm`,
            height: `${page.height}mm`,
            transform: `scale(${zoom})`,
            transformOrigin: 'top left',
            background: '#ffffff',
            boxShadow: '0 8px 40px rgba(0,0,0,0.55)',
          }}
        >
          {/* grid */}
          {showGrid && (
            <div
              style={{
                position: 'absolute',
                inset: 0,
                backgroundImage:
                  'linear-gradient(to right, rgba(120,110,80,0.14) 0.5px, transparent 0.5px), linear-gradient(to bottom, rgba(120,110,80,0.14) 0.5px, transparent 0.5px)',
                backgroundSize: `${5 * MM}px ${5 * MM}px`,
                pointerEvents: 'none',
                zIndex: 9000,
              }}
            />
          )}
          {/* margin guides */}
          <div
            style={{
              position: 'absolute',
              left: `${page.margin.left}mm`,
              top: `${page.margin.top}mm`,
              right: `${page.margin.right}mm`,
              bottom: `${page.margin.bottom}mm`,
              border: '0.35mm dashed rgba(180,140,60,0.55)',
              pointerEvents: 'none',
              zIndex: 9001,
            }}
          />

          {/* snap / alignment guides (while dragging) */}
          {guides.v.map((g) => (
            <div
              key={`gv-${g}`}
              style={{
                position: 'absolute',
                left: `${g}mm`,
                top: 0,
                width: `${Math.max(0.3, 1.2 / (MM * zoom))}mm`,
                height: '100%',
                background: '#ff5d3a',
                boxShadow: '0 0 5px rgba(255,93,58,0.9)',
                pointerEvents: 'none',
                zIndex: 9550,
              }}
            />
          ))}
          {guides.h.map((g) => (
            <div
              key={`gh-${g}`}
              style={{
                position: 'absolute',
                top: `${g}mm`,
                left: 0,
                height: `${Math.max(0.3, 1.2 / (MM * zoom))}mm`,
                width: '100%',
                background: '#ff5d3a',
                boxShadow: '0 0 5px rgba(255,93,58,0.9)',
                pointerEvents: 'none',
                zIndex: 9550,
              }}
            />
          ))}

          {/* elements */}
          {sorted.map((el) => (
            <ElementRenderer
              key={el.id}
              el={el}
              mode="design"
              onPointerDown={(e) => startDrag(e, el, 'move')}
              onDoubleClick={el.type === 'text' && !el.locked ? () => onStartEdit(el.id) : undefined}
            />
          ))}

          {/* inline text editor (double-click) — remounts per session via key */}
          {editing && (
            <InlineEditor
              key={editing.id}
              el={editing}
              onEditText={onEditText}
              onEndEdit={onEndEdit}
            />
          )}

          {/* selection outlines (every selected element) + handles (primary only) */}
          {selectedIds.map((id) => {
            const s = elements.find((e) => e.id === id);
            if (!s || s.hidden || (editing && editing.id === id)) return null;
            const primary = id === selected?.id;
            return (
              <div
                key={`sel-${id}`}
                style={{
                  position: 'absolute',
                  left: `${s.x}mm`,
                  top: `${s.y}mm`,
                  width: `${s.w}mm`,
                  height: `${s.h}mm`,
                  outline: 'solid',
                  outlineColor: primary ? '#d9a13b' : 'rgba(217,161,59,0.55)',
                  outlineWidth: `${(primary ? 1 : 0.8) / (MM * zoom)}mm`,
                  outlineStyle: primary || selectedIds.length === 1 ? 'solid' : 'dashed',
                  outlineOffset: 0,
                  pointerEvents: 'none',
                  zIndex: 9500,
                }}
              />
            );
          })}
          {selected && !editing && handles.map((h) => (
                <div
                  key={h.id}
                  onPointerDown={(e) => selected && startDrag(e, selected, 'resize', h.id)}
                  style={{
                    position: 'absolute',
                    left: `${h.cx - handleSizeMm / 2}mm`,
                    top: `${h.cy - handleSizeMm / 2}mm`,
                    width: `${handleSizeMm}mm`,
                    height: `${handleSizeMm}mm`,
                    background: '#ffffff',
                    border: `${1.5 / (MM * zoom)}mm solid #d9a13b`,
                    borderRadius: '20%',
                    cursor: h.cursor,
                    zIndex: 9600,
                  }}
                />
              ))}
        </div>

        {/* ruler labels */}
        <div
          className="pointer-events-none absolute left-0 top-0 select-none px-2 py-1 font-mono text-[10px] text-zinc-600"
          style={{ width: '100%' }}
        >
          {page.sizeName} · {page.width.toFixed(1)} × {page.height.toFixed(1)} mm · {Math.round(zoom * 100)}%
          <span className="ml-3 text-zinc-700">double-click a text element to edit in place</span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------
 * InlineEditor — textarea that overlays a text element.
 * Mounted with key={element.id} so state initialises fresh
 * per edit session (no setState-in-effect required).
 * ------------------------------------------------------------ */
function InlineEditor({
  el,
  onEditText,
  onEndEdit,
}: {
  el: TemplateElement;
  onEditText: (id: string, text: string) => void;
  onEndEdit: (commit: boolean) => void;
}) {
  const [draft, setDraft] = useState(el.text ?? '');

  const endEdit = (commit: boolean) => {
    if (commit) onEditText(el.id, draft);
    onEndEdit(commit);
  };

  return (
    <textarea
      autoFocus
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onPointerDown={(e) => e.stopPropagation()}
      onKeyDown={(e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          endEdit(true);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          endEdit(false);
        }
      }}
      onBlur={() => endEdit(true)}
      style={{
        position: 'absolute',
        left: `${el.x}mm`,
        top: `${el.y}mm`,
        width: `${el.w}mm`,
        height: `${el.h}mm`,
        zIndex: 9700,
        fontFamily: el.fontFamily,
        fontSize: `${el.fontSize ?? 10}pt`,
        fontWeight: el.fontWeight ?? 400,
        fontStyle: el.italic ? 'italic' : undefined,
        color: el.color || '#1a1a1a',
        textAlign: el.align ?? 'left',
        lineHeight: el.lineHeight ?? 1.25,
        letterSpacing: el.letterSpacing ? `${el.letterSpacing}pt` : undefined,
        padding: el.padding ? `${el.padding}mm` : '0.5mm',
        background: '#fffdf5',
        border: 'none',
        outline: `${0.4 / MM}mm solid #d9a13b`,
        outlineOffset: 0,
        boxSizing: 'border-box',
        resize: 'none',
        overflow: 'hidden',
        whiteSpace: 'pre',
      }}
      aria-label="Inline text editor"
    />
  );
}

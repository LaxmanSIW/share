'use client';

/* ============================================================
 * InvoiceStudio — analytics dashboard (BlackRock-style dark)
 * ============================================================ */
import React, { useMemo, useState } from 'react';
import {
  AlertCircle, ArrowUpRight, BadgeCheck, CalendarSync, ChevronLeft, ChevronRight, Download, FileSpreadsheet, FileText,
  IndianRupee, Percent, Plus,
} from 'lucide-react';
import type { Bill, Settings } from '@/lib/studio/types';
import { billStatus, docTypeOf, DOC_TYPE_META, dueAmount, fmtDate, fmtMoney, nextRepeatDate, paidAmount, REPEAT_META, repeatDue, repeatOf, STATUS_META } from '@/lib/studio/format';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface Props {
  bills: Bill[];
  settings: Settings;
  onNewBill: () => void;
  onOpenHistory: () => void;
  onRepeat?: (b: Bill) => void;
  autoRecurring?: boolean;
  onToggleAutoRepeat?: (on: boolean) => void;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function DashboardView({ bills, settings, onNewBill, onOpenHistory, onRepeat, autoRecurring, onToggleAutoRepeat }: Props) {
  const { toast } = useToast();
  /** month the “this month” KPIs / chart window point at (defaults to the current month) */
  const [cursor, setCursor] = useState<{ y: number; m: number }>(() => {
    const n = new Date();
    return { y: n.getFullYear(), m: n.getMonth() };
  });
  const nowKey = useMemo(() => {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}`;
  }, []);
  const cursorKey = `${cursor.y}-${String(cursor.m + 1).padStart(2, '0')}`;
  const isCurrentMonth = cursorKey === nowKey;
  const monthLabel = `${MONTHS[cursor.m]} ${cursor.y}`;

  const shiftMonth = (delta: number) => {
    setCursor((c) => {
      const d = new Date(c.y, c.m + delta, 1);
      return { y: d.getFullYear(), m: d.getMonth() };
    });
  };

  const stats = useMemo(() => {
    const now = new Date(cursor.y, cursor.m, 1);
    const monthKey = `${cursor.y}-${String(cursor.m + 1).padStart(2, '0')}`;
    // revenue / GST / collections are computed on TAX INVOICES only —
    // proforma invoices & quotations are estimates, not sales
    const invoices = bills.filter((b) => docTypeOf(b) === 'invoice');
    const live = invoices.filter((b) => billStatus(b) !== 'cancelled');
    const monthLive = live.filter((b) => b.date.startsWith(monthKey));
    const monthRevenue = monthLive.reduce((s, b) => s + b.totals.grandTotal, 0);
    const totalRevenue = live.reduce((s, b) => s + b.totals.grandTotal, 0);
    const avg = live.length > 0 ? totalRevenue / live.length : 0;
    const others = bills.length - invoices.length;

    // collections — honour partial payments where recorded
    const open = live.filter((b) => dueAmount(b) > 0);
    const outstanding = open.reduce((s, b) => s + dueAmount(b), 0);
    const collected = live.reduce((s, b) => s + paidAmount(b), 0);
    const collectedThisMonth = live.reduce((s, b) => {
      let m = 0;
      for (const p of b.payments ?? []) if (p.date.startsWith(monthKey)) m += p.amount;
      if (!(b.payments?.length) && billStatus(b) === 'paid' && (b.paidAt ?? '').slice(0, 7) === monthKey) m += b.totals.grandTotal;
      return s + m;
    }, 0);

    // GST analytics (all time / this month)
    const sum = (arr: Bill[], f: (b: Bill) => number) => arr.reduce((s, b) => s + f(b), 0);
    const gst = {
      taxableAll: sum(live, (b) => b.totals.taxable),
      taxableMonth: sum(monthLive, (b) => b.totals.taxable),
      cgstAll: sum(live, (b) => b.totals.cgst),
      sgstAll: sum(live, (b) => b.totals.sgst),
      igstAll: sum(live, (b) => b.totals.igst),
      discountAll: sum(live, (b) => b.totals.discount),
      taxMonth: sum(monthLive, (b) => b.totals.cgst + b.totals.sgst + b.totals.igst),
      taxAll: sum(live, (b) => b.totals.cgst + b.totals.sgst + b.totals.igst),
    };

    // last 6 months revenue (invoices only) — window ends at the selected month
    const series: { label: string; value: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const value = live.filter((b) => b.date.startsWith(key)).reduce((s, b) => s + b.totals.grandTotal, 0);
      series.push({ label: `${MONTHS[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`, value });
    }

    // month-over-month trend for the selected month (previous calendar month revenue)
    const prev = new Date(cursor.y, cursor.m - 1, 1);
    const prevKey = `${prev.getFullYear()}-${String(prev.getMonth() + 1).padStart(2, '0')}`;
    const prevRevenue = live.filter((b) => b.date.startsWith(prevKey)).reduce((s, b) => s + b.totals.grandTotal, 0);
    const momDelta = prevRevenue > 0 ? ((monthRevenue - prevRevenue) / prevRevenue) * 100 : monthRevenue > 0 ? 100 : 0;

    // top buyers (invoices only)
    const byBuyer = new Map<string, { count: number; amount: number }>();
    for (const b of live) {
      const name = b.variables['buyer_name'] || '—';
      const cur = byBuyer.get(name) ?? { count: 0, amount: 0 };
      byBuyer.set(name, { count: cur.count + 1, amount: cur.amount + b.totals.grandTotal });
    }
    const topBuyers = Array.from(byBuyer.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);

    return {
      monthRevenue, monthCount: monthLive.length, totalRevenue, avg, series, topBuyers,
      maxSeries: Math.max(...series.map((s) => s.value), 1), gst,
      outstanding, collected, collectedThisMonth,
      unpaidCount: open.length,
      invoiceCount: invoices.length, otherCount: others,
      prevRevenue, momDelta,
    };
  }, [bills, cursor]);

  const recent = [...bills].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)).slice(0, 8);

  const exportGstCsv = () => {
    const head = ['Bill No', 'Date', 'Buyer', 'GSTIN', 'Subtotal', 'Discount', 'Taxable', 'CGST', 'SGST', 'IGST', 'Round Off', 'Grand Total'];
    const esc = (v: string | number) => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = [...bills]
      .sort((a, b) => (a.date < b.date ? -1 : 1))
      .map((b) => [
        b.billNo, b.date, b.variables['buyer_name'] ?? '', b.variables['buyer_gst'] ?? '',
        b.totals.subtotal, b.totals.discount, b.totals.taxable,
        b.totals.cgst, b.totals.sgst, b.totals.igst, b.totals.roundOff, b.totals.grandTotal,
      ].map(esc).join(','));
    const csv = '\ufeff' + [head.join(','), ...rows].join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gst-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'GST report downloaded', description: `${bills.length} bills exported.` });
  };

  const kpis = [
    { label: 'Total Bills', value: String(bills.length), sub: stats.otherCount > 0 ? `${stats.invoiceCount} invoices · ${stats.otherCount} other docs` : 'all time', icon: <FileText className="h-4 w-4" /> },
    {
      label: `Revenue · ${isCurrentMonth ? 'This Month' : monthLabel}`, value: fmtMoney(stats.monthRevenue, settings.currency), sub: `${stats.monthCount} bill${stats.monthCount === 1 ? '' : 's'}`, icon: <IndianRupee className="h-4 w-4" />,
      delta: stats.momDelta,
      deltaTitle: stats.prevRevenue > 0
        ? `${stats.momDelta >= 0 ? '+' : ''}${stats.momDelta.toFixed(1)}% vs ${MONTHS[(cursor.m + 11) % 12]} (${fmtMoney(stats.prevRevenue, settings.currency)})`
        : 'No revenue last month',
    },
    {
      label: 'Outstanding', value: fmtMoney(stats.outstanding, settings.currency),
      sub: `${stats.unpaidCount} open invoice${stats.unpaidCount === 1 ? '' : 's'} (balance due)`,
      icon: <AlertCircle className="h-4 w-4" />, accent: true,
    },
    {
      label: 'Collected', value: fmtMoney(stats.collected, settings.currency),
      sub: `${fmtMoney(stats.collectedThisMonth, settings.currency)} ${isCurrentMonth ? 'this month' : `in ${MONTHS[cursor.m]}`}`,
      icon: <BadgeCheck className="h-4 w-4" />, ok: true,
      bar: stats.collected + stats.outstanding > 0 ? stats.collected / (stats.collected + stats.outstanding) : 0,
    },
  ];

  return (
    <div className="studio-scroll flex-1 overflow-y-auto p-5">
      <div className="mx-auto max-w-6xl space-y-5">
        {/* header row */}
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-100">Overview</h1>
            <p className="mt-0.5 text-xs text-zinc-500">
              {settings.business.name} · GSTIN {settings.business.gstin}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {/* month picker — drives the month KPIs, GST tiles and the 6-month chart window */}
            <div className="flex items-center gap-1 rounded-md border border-[#232b38] bg-[#12161d] px-1 py-1" role="group" aria-label="Reporting month">
              <button
                type="button"
                className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 transition-colors hover:bg-[#1a212c] hover:text-[#e8c064]"
                title="Previous month"
                aria-label="Previous month"
                onClick={() => shiftMonth(-1)}
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                className={`min-w-[104px] rounded px-2 text-center text-[11px] font-semibold tabular transition-colors ${
                  isCurrentMonth ? 'text-zinc-300' : 'bg-[#d9a13b]/10 text-[#e8c064] hover:bg-[#d9a13b]/20'
                }`}
                title={isCurrentMonth ? 'Reporting month' : 'Back to current month'}
                onClick={() => { if (!isCurrentMonth) { const n = new Date(); setCursor({ y: n.getFullYear(), m: n.getMonth() }); } }}
              >
                {monthLabel}{!isCurrentMonth && ' ·'}
              </button>
              <button
                type="button"
                className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 transition-colors hover:bg-[#1a212c] hover:text-[#e8c064] disabled:cursor-not-allowed disabled:opacity-30"
                title="Next month"
                aria-label="Next month"
                disabled={isCurrentMonth}
                onClick={() => shiftMonth(1)}
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <Button className="h-9 gap-1.5 bg-[#d9a13b] text-sm font-semibold text-black hover:bg-[#e5b055]" onClick={onNewBill}>
              <ArrowUpRight className="h-4 w-4" /> Create Bill
            </Button>
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {kpis.map((k) => (
            <div
              key={k.label}
              className={`rounded-lg border bg-[#12161d] p-4 transition-all hover:-translate-y-0.5 hover:shadow-[0_6px_24px_rgba(0,0,0,0.35)] ${
                'accent' in k && k.accent
                  ? 'border-amber-500/25 hover:border-amber-500/50'
                  : 'ok' in k && k.ok
                    ? 'border-emerald-500/20 hover:border-emerald-500/45'
                    : 'border-[#232b38] hover:border-[#39445a]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">{k.label}</span>
                <span className={
                  'accent' in k && k.accent ? 'text-amber-400' : 'ok' in k && k.ok ? 'text-emerald-400' : 'text-[#d9a13b]'
                }>{k.icon}</span>
              </div>
              <div className={`tabular mt-2.5 text-2xl font-bold tracking-tight ${
                'accent' in k && k.accent ? 'text-amber-300' : 'ok' in k && k.ok ? 'text-emerald-300' : 'text-zinc-100'
              }`}>{k.value}</div>
              <div className="mt-1 flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] text-zinc-600">{k.sub}</span>
                {'delta' in k && typeof k.delta === 'number' && (isFinite(k.delta) && Math.abs(k.delta) >= 0.05) && (
                  <span
                    className={`inline-flex items-center gap-0.5 rounded-full border px-1.5 py-px text-[9px] font-bold tabular ${
                      k.delta >= 0
                        ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                        : 'border-red-500/30 bg-red-500/10 text-red-300'
                    }`}
                    title={k.deltaTitle as string}
                  >
                    {k.delta >= 0 ? '▲' : '▼'}
                    {Math.abs(k.delta) >= 999 ? '>999' : Math.abs(k.delta).toFixed(1)}%
                    <span className="font-normal opacity-70">MoM</span>
                  </span>
                )}
              </div>
              {'bar' in k && k.bar !== undefined && (
                <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-[#0f1319]" title={`${Math.round(k.bar * 100)}% of invoiced amount collected`}>
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-500"
                    style={{ width: `${Math.max(2, Math.min(100, k.bar * 100))}%` }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* chart + top buyers */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4 lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                Revenue · 6 Months to {MONTHS[cursor.m]} '{String(cursor.y).slice(2)}
              </span>
              <span className="text-[10px] text-zinc-600">{settings.currency}</span>
            </div>
            <div className="flex h-44 gap-3">
              {stats.series.map((s) => (
                <div key={s.label} className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="tabular text-[9px] text-zinc-500">
                    {s.value > 0 ? fmtMoney(s.value, settings.currency) : ''}
                  </span>
                  <div className="flex w-full flex-1 items-end">
                    <div
                      className={`w-full rounded-t bg-gradient-to-t from-[#8a6a24] to-[#d9a13b] transition-all duration-300 hover:brightness-110 ${
                        s.value > 0 ? 'cursor-default' : 'opacity-40'
                      }`}
                      style={{ height: `${Math.max(2, (s.value / stats.maxSeries) * 100)}%` }}
                      title={`${s.label}: ${fmtMoney(s.value, settings.currency)}`}
                    />
                  </div>
                  <span className="text-[9px] font-medium text-zinc-500">{s.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
            <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Top Buyers</span>
            <div className="mt-3 space-y-3">
              {stats.topBuyers.length === 0 && <p className="text-xs text-zinc-600">No data yet.</p>}
              {stats.topBuyers.map((b, i) => (
                <div key={b.name} className="flex items-center gap-3">
                  <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
                    i === 0 ? 'bg-[#d9a13b] text-black' : 'bg-[#1d2430] text-zinc-400'
                  }`}>
                    {i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-medium text-zinc-200">{b.name}</div>
                    <div className="text-[10px] text-zinc-600">{b.count} bills</div>
                  </div>
                  <span className="tabular text-xs font-semibold text-zinc-300">{fmtMoney(b.amount, settings.currency)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* GST analytics + reports */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4 lg:col-span-2">
            <div className="mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                <Percent className="h-3.5 w-3.5 text-[#d9a13b]" /> GST & Taxable Value
              </span>
              <span className="text-[10px] text-zinc-600">tax invoices only · cancelled excluded</span>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <GstStat label={`Taxable · ${MONTHS[cursor.m]}`} value={fmtMoney(stats.gst.taxableMonth, settings.currency)} />
              <GstStat label={`Tax · ${MONTHS[cursor.m]}`} value={fmtMoney(stats.gst.taxMonth, settings.currency)} />
              <GstStat label="Taxable · All" value={fmtMoney(stats.gst.taxableAll, settings.currency)} />
              <GstStat label="Tax · All" value={fmtMoney(stats.gst.taxAll, settings.currency)} />
              <GstStat label="CGST" value={fmtMoney(stats.gst.cgstAll, settings.currency)} small />
              <GstStat label="SGST" value={fmtMoney(stats.gst.sgstAll, settings.currency)} small />
              <GstStat label="IGST" value={fmtMoney(stats.gst.igstAll, settings.currency)} small />
              <GstStat label="Discounts given" value={fmtMoney(stats.gst.discountAll, settings.currency)} small />
            </div>
          </div>
          <div className="flex flex-col justify-between rounded-lg border border-[#232b38] bg-[#12161d] p-4">
            <div>
              <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                <FileSpreadsheet className="h-3.5 w-3.5 text-[#d9a13b]" /> Reports (CSV)
              </span>
              <p className="mt-2 text-[11px] leading-relaxed text-zinc-500">
                Month-wise taxable value & GST summary — ready for your CA, plus the bill-wise detail export.
              </p>
            </div>
            <div className="mt-4 space-y-2">
              <a href="/api/reports/gst" download className="block">
                <Button className="h-9 w-full gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]">
                  <Download className="h-3.5 w-3.5" /> Monthly GST summary
                </Button>
              </a>
              <Button variant="outline" className="h-9 w-full gap-1.5 border-[#2a3342] text-xs hover:bg-[#1a212c]" onClick={exportGstCsv}>
                <Download className="h-3.5 w-3.5" /> Bill-wise GST detail
              </Button>
            </div>
          </div>
        </div>

        {/* recurring invoices due */}
        {(() => {
          const dueRecurring = bills
            .filter(repeatDue)
            .sort((a, b) => (a.date < b.date ? 1 : -1));
          const flagged = bills.filter((b) => repeatOf(b) !== 'none');
          if (flagged.length === 0) return null;
          return (
            <div className="rounded-lg border border-[#d9a13b]/25 bg-gradient-to-r from-[#d9a13b]/[0.07] to-transparent p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#e8b954]">
                  <CalendarSync className="h-3.5 w-3.5" /> Recurring Invoices
                </span>
                <div className="flex items-center gap-2">
                  <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider ${
                    autoRecurring
                      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                      : 'border-zinc-600 bg-[#0f1319] text-zinc-500'
                  }`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${autoRecurring ? 'bg-emerald-400' : 'bg-zinc-600'}`} />
                    {autoRecurring ? 'Auto-create on' : 'Auto-create off'}
                  </span>
                  {onToggleAutoRepeat && (
                    <Button
                      size="sm"
                      variant="outline"
                      className={`h-6 gap-1 border px-2 text-[10px] ${
                        autoRecurring
                          ? 'border-[#2a3342] text-zinc-400 hover:bg-[#1a212c]'
                          : 'border-[#d9a13b]/40 text-[#e8c064] hover:bg-[#d9a13b]/10'
                      }`}
                      onClick={() => onToggleAutoRepeat(!autoRecurring)}
                    >
                      {autoRecurring ? 'Pause' : 'Enable auto-create'}
                    </Button>
                  )}
                  <span className="text-[10px] text-zinc-600">
                    {dueRecurring.length > 0
                      ? `${dueRecurring.length} due — next occurrence reached`
                      : `${flagged.length} flagged · nothing due yet`}
                  </span>
                </div>
              </div>
              {dueRecurring.length === 0 ? (
                <p className="text-xs text-zinc-500">
                  {autoRecurring
                    ? 'Auto-create is on — due invoices are created automatically the first time the app opens each day.'
                    : 'Recurring invoices roll forward automatically — a “Create next” action appears here when the next copy is due.'}
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
                  {dueRecurring.map((b) => {
                    const cad = REPEAT_META[repeatOf(b) as 'weekly' | 'monthly' | 'yearly'];
                    return (
                      <div
                        key={b.id}
                        className="flex items-center gap-3 rounded-md border border-[#2a3342] bg-[#0f1319] px-3 py-2.5 transition-colors hover:border-[#d9a13b]/40"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="truncate text-xs font-semibold text-zinc-200">
                              {b.variables['buyer_name'] || '—'}
                            </span>
                            {cad && (
                              <span className="shrink-0 rounded border border-[#d9a13b]/40 bg-[#d9a13b]/10 px-1 text-[8px] font-bold uppercase tracking-wider text-[#e8b954]">
                                {cad.label}
                              </span>
                            )}
                          </div>
                          <div className="font-mono text-[10px] text-zinc-600">
                            {b.billNo} · {fmtDate(b.date)} → due {fmtDate(nextRepeatDate(b))}
                            {b.repeatEndDate ? ` · until ${fmtDate(b.repeatEndDate)}` : ''}
                          </div>
                          {b.repeatSkipNext && (
                            <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-wider text-sky-300">
                              next occurrence will be skipped
                            </div>
                          )}
                        </div>
                        <span className="tabular shrink-0 text-xs font-semibold text-zinc-300">
                          {fmtMoney(b.totals.grandTotal, settings.currency)}
                        </span>
                        {onRepeat && (
                          <Button
                            size="sm"
                            className="h-7 shrink-0 gap-1 bg-[#d9a13b] px-2.5 text-[11px] font-semibold text-black hover:bg-[#e5b055]"
                            onClick={() => onRepeat(b)}
                            title={`Open a fresh copy of this invoice dated the next ${cad?.step ?? 'period'}`}
                          >
                            <Plus className="h-3 w-3" /> Create next
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })()}

        {/* recent bills */}
        <div className="overflow-hidden rounded-lg border border-[#232b38]">
          <div className="flex items-center justify-between border-b border-[#232b38] bg-[#12161d] px-4 py-2.5">
            <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Recent Bills</span>
            <Button variant="ghost" size="sm" className="h-7 text-xs text-[#d9a13b] hover:text-[#e8c064]" onClick={onOpenHistory}>
              View all →
            </Button>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#232b38] bg-[#10141b] text-left text-[10px] uppercase tracking-wider text-zinc-600">
                <th className="px-4 py-2 font-medium">Bill No</th>
                <th className="px-4 py-2 font-medium">Date</th>
                <th className="px-4 py-2 font-medium">Buyer</th>
                <th className="px-4 py-2 font-medium">Status</th>
                <th className="px-4 py-2 text-right font-medium">Amount</th>
              </tr>
            </thead>
            <tbody>
              {recent.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-sm text-zinc-600">
                    No bills yet — create your first bill to see it here.
                  </td>
                </tr>
              )}
              {recent.map((b) => {
                const st = billStatus(b);
                const meta = STATUS_META[st];
                const dmeta = DOC_TYPE_META[docTypeOf(b)];
                return (
                  <tr key={b.id} className="border-b border-[#1a212c] last:border-0 hover:bg-[#151b25]">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`inline-flex shrink-0 items-center rounded border px-1.5 py-px font-mono text-[8px] font-bold uppercase tracking-wider ${dmeta.cls}`}>
                          {dmeta.short}
                        </span>
                        <span className="font-mono text-xs font-semibold text-[#e8c064]">{b.billNo}</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-zinc-400">{fmtDate(b.date)}</td>
                    <td className="px-4 py-2.5 text-xs text-zinc-300">{b.variables['buyer_name'] || '—'}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider ${meta.cls}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} /> {meta.label}
                      </span>
                    </td>
                    <td className="tabular px-4 py-2.5 text-right font-semibold text-zinc-100">
                      {fmtMoney(b.totals.grandTotal, settings.currency)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function GstStat({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2.5">
      <p className="text-[9px] uppercase tracking-wider text-zinc-600">{label}</p>
      <p className={`tabular mt-1 font-semibold ${small ? 'text-sm text-zinc-300' : 'text-base text-zinc-100'}`}>{value}</p>
    </div>
  );
}

'use client';

/* ============================================================
 * InvoiceStudio — print engine
 * Renders hidden #print-root via portal, injects @page size,
 * triggers the browser print dialog, records the print event.
 * Supports bill jobs (template-based, multi-copy),
 * payment-receipt jobs (fixed A5 receipt document) and
 * calibration-sheet jobs (printer alignment).
 * ============================================================ */
import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { Bill, BillPayment, Settings, Template } from '@/lib/studio/types';
import BillPreview from './BillPreview';
import PaymentReceipt from './PaymentReceipt';
import CalibrationSheet from './CalibrationSheet';

export interface PrintJob {
  template: Template;
  bill: Bill;
  copies: number;
}

export interface ReceiptJob {
  bill: Bill;
  payment: BillPayment;
  receiptNo: string;
}

export type CalibrationJob = Record<string, never>;

interface Props {
  job: PrintJob | null;
  receiptJob?: ReceiptJob | null;
  calibrateJob?: CalibrationJob | null;
  settings: Settings;
  onDone: (billId: string) => void;
  onReceiptDone?: () => void;
  onCalibrateDone?: () => void;
}

export default function PrintManager({ job, receiptJob, calibrateJob, settings, onDone, onReceiptDone, onCalibrateDone }: Props) {
  const active = job ?? receiptJob ?? calibrateJob;

  useEffect(() => {
    if (!active) return;
    const isReceipt = !!receiptJob && !job;
    const isCalib = !!calibrateJob && !job && !receiptJob;
    const page = isCalib
      ? '210mm 297mm'
      : isReceipt
        ? '148mm 210mm'
        : job!.template.page.autoHeight
          ? `${job!.template.page.width}mm auto`
          : `${job!.template.page.width}mm ${job!.template.page.height}mm`;
    const style = document.createElement('style');
    style.setAttribute('data-print-page', '1');
    style.textContent = `
      @page {
        size: ${page};
        margin: 0mm !important;
      }
      @media print {
        html, body {
          margin: 0 !important;
          padding: 0 !important;
          width: 100% !important;
          background: #ffffff !important;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        #print-root {
          margin: 0 !important;
          padding: 0 !important;
        }
      }
    `;
    document.head.appendChild(style);

    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      if (isCalib) onCalibrateDone?.();
      else if (isReceipt) onReceiptDone?.();
      else onDone(job!.bill.id);
    };
    const timer = setTimeout(() => window.print(), 250);
    window.addEventListener('afterprint', finish);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('afterprint', finish);
      style.remove();
    };
  }, [job, receiptJob, calibrateJob]);

  if (calibrateJob && !job && !receiptJob) {
    return createPortal(
      <div id="print-root">
        <CalibrationSheet settings={settings} />
      </div>,
      document.body,
    );
  }

  if (job) {
    // per-template offsets (designer → page setup) win over the global Settings values
    const offX = job.template.printOffsetX !== undefined && job.template.printOffsetX !== null
      ? Number(job.template.printOffsetX) || 0
      : Number(settings.printOffsetX) || 0;
    const offY = job.template.printOffsetY !== undefined && job.template.printOffsetY !== null
      ? Number(job.template.printOffsetY) || 0
      : Number(settings.printOffsetY) || 0;
    return createPortal(
      <div id="print-root">
        <div style={{ transform: offX || offY ? `translate(${offX}mm, ${offY}mm)` : undefined }}>
          {Array.from({ length: Math.max(1, job.copies) }).map((_, i) => (
            <div className="print-copy" key={i}>
              <BillPreview
                template={job.template}
                bill={job.bill}
                settings={settings}
                copyIndex={i}
                multiPage
                forPrint
                showStatusStamp={settings.statusStamp !== false}
              />
            </div>
          ))}
        </div>
      </div>,
      document.body,
    );
  }

  if (receiptJob) {
    return createPortal(
      <div id="print-root">
        <PaymentReceipt
          bill={receiptJob.bill}
          payment={receiptJob.payment}
          receiptNo={receiptJob.receiptNo}
          settings={settings}
        />
      </div>,
      document.body,
    );
  }

  return null;
}

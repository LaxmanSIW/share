'use client';

/* Single template thumbnail card image — owns its own fit-scale hook */
import React from 'react';
import type { Settings, Template } from '@/lib/studio/types';
import BillPreview from './BillPreview';
import { useFitScale } from './useFitScale';

export default function TemplateThumb({ template, settings }: { template: Template; settings: Settings }) {
  const [ref, scale] = useFitScale(template.page.width, 12, 1, template.page.height);
  return (
    <div ref={ref} className="flex h-52 w-full items-center justify-center overflow-hidden bg-[#0d1015] p-3">
      <BillPreview
        template={template}
        settings={settings}
        scale={scale}
        className="rounded-sm shadow-[0_4px_24px_rgba(0,0,0,0.5)]"
      />
    </div>
  );
}

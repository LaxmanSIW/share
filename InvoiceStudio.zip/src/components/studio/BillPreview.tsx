/* ============================================================
 * InvoiceStudio — page preview (screen & print)
 * Single page by default; multi-page when items overflow the
 * template's table area (repeat elements carry letterheads over).
 * ============================================================ */
import React from 'react';
import type { Bill, Settings, Template } from '@/lib/studio/types';
import { buildContext, effectivePageHeight, paginateTemplate, rollTableShift, TABLE_HEADER_MM } from '@/lib/studio/render';
import ElementRenderer, { MM } from './ElementRenderer';

interface Props {
  template: Template;
  bill?: Bill | null;
  settings: Settings;
  /** screen zoom factor; omit for print (actual size) */
  scale?: number;
  copyIndex?: number;
  /** split items across pages using repeatOnPages elements */
  multiPage?: boolean;
  /** when multiPage + forPrint: emit .print-page breaks between pages */
  forPrint?: boolean;
  className?: string;
  /** screen gap between stacked pages (px) */
  pageGap?: number;
  /** overlay a PAID / CANCELLED rubber stamp when the bill has that status */
  showStatusStamp?: boolean;
}

function StatusStamp({ status, pageWidth }: { status: 'paid' | 'cancelled'; pageWidth: number }) {
  const paid = status === 'paid';
  const color = paid ? '#0e7a4f' : '#c02626';
  const label = paid ? 'PAID' : 'CANCELLED';
  return (
    <div
      aria-hidden
      style={{
        position: 'absolute',
        left: '50%',
        top: '44%',
        transform: `translate(-50%, -50%) rotate(-22deg)`,
        color,
        border: `${pageWidth * 0.018}mm double ${color}`,
        outline: `${pageWidth * 0.008}mm solid ${color}`,
        outlineOffset: `${pageWidth * 0.012}mm`,
        borderRadius: '2mm',
        padding: `${pageWidth * 0.012}mm ${pageWidth * 0.05}mm`,
        fontSize: `${pageWidth * 0.115}mm`,
        fontWeight: 900,
        letterSpacing: `${pageWidth * 0.045}mm`,
        textIndent: `${pageWidth * 0.045}mm`, // balance letter-spacing
        fontFamily: "'Arial Black', Arial, sans-serif",
        opacity: 0.22,
        whiteSpace: 'nowrap',
        pointerEvents: 'none',
        zIndex: 9600,
        WebkitPrintColorAdjust: 'exact',
        printColorAdjust: 'exact',
      }}
    >
      {label}
    </div>
  );
}

function SinglePage({
  template,
  bill,
  settings,
  copyIndex,
  pageNo,
  pageCount,
  elements,
  tableSlice,
  stamp,
}: {
  template: Template;
  bill: Bill | null;
  settings: Settings;
  copyIndex: number;
  pageNo: number;
  pageCount: number;
  elements: ReturnType<typeof paginateTemplate>[number]['elements'];
  tableSlice?: { start: number; end: number };
  stamp: 'paid' | 'cancelled' | null;
}) {
  const ctx = buildContext(bill, settings, copyIndex, pageNo, pageCount);
  const roll = !!template.page.autoHeight;
  const itemCount = tableSlice ? Math.max(tableSlice.end - tableSlice.start, 0) : bill?.items.length ?? 0;
  // on continuous rolls, elements below the table follow its real rendered height
  const shift = rollTableShift(template, itemCount);
  const tableY = elements.find((e) => e.type === 'table')?.y ?? Infinity;
  return (
    <div
      style={{
        width: `${template.page.width}mm`,
        height: roll ? `${effectivePageHeight(template, itemCount)}mm` : `${template.page.height}mm`,
        background: '#ffffff',
        position: 'relative',
        overflow: roll ? 'visible' : 'hidden',
      }}
    >
      {elements.map((el) => {
        // the table grows to fit its slice on this page
        const renderEl = {
          ...el,
          ...(el.type === 'table' && tableSlice
            ? {
                h: TABLE_HEADER_MM + Math.max(tableSlice.end - tableSlice.start, 1) * (el.rowHeight ?? 7),
              }
            : {}),
          ...(roll && shift > 0 && el.type !== 'table' && el.y > tableY + 2 ? { y: el.y + shift } : {}),
        };
        return (
          <ElementRenderer
            key={el.id}
            el={renderEl}
            mode="final"
            ctx={ctx}
            rowStart={el.type === 'table' ? tableSlice?.start : undefined}
            rowEnd={el.type === 'table' ? tableSlice?.end : undefined}
          />
        );
      })}
      {stamp && <StatusStamp status={stamp} pageWidth={template.page.width} />}
    </div>
  );
}

export default function BillPreview({
  template,
  bill = null,
  settings,
  scale = 1,
  copyIndex = 0,
  multiPage = false,
  forPrint = false,
  className,
  pageGap = 16,
  showStatusStamp = false,
}: Props) {
  const status = (bill?.status ?? 'unpaid') as 'unpaid' | 'paid' | 'cancelled';
  const stamp: 'paid' | 'cancelled' | null =
    showStatusStamp && bill && (status === 'paid' || status === 'cancelled') ? status : null;
  const pages = multiPage ? paginateTemplate(template, bill?.items.length ?? 0) : null;
  const list = pages ?? [
    {
      pageNo: 1,
      elements: [...template.elements].filter((e) => !e.hidden).sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0)),
      tableSlice: { start: 0, end: bill?.items.length ?? 0 },
    },
  ];
  const pageCount = list.length;
  const roll = !!template.page.autoHeight;
  // continuous receipts have one content-driven page height
  const itemCount = bill?.items.length ?? 0;
  const pageH = roll ? effectivePageHeight(template, itemCount) : template.page.height;

  if (!multiPage || roll) {
    return (
      <div
        className={className}
        style={{
          width: forPrint ? `${template.page.width}mm` : template.page.width * MM * scale,
          height: forPrint ? `${pageH}mm` : pageH * MM * scale,
          overflow: roll ? 'visible' : 'hidden',
          flexShrink: 0,
        }}
      >
        <div
          style={{
            width: `${template.page.width}mm`,
            height: `${pageH}mm`,
            transform: forPrint ? undefined : `scale(${scale})`,
            transformOrigin: 'top left',
            background: '#ffffff',
            position: 'relative',
            overflow: roll ? 'visible' : 'hidden',
          }}
        >
          {list.map((p) => (
            <SinglePage
              key={p.pageNo}
              template={template}
              bill={bill}
              settings={settings}
              copyIndex={copyIndex}
              pageNo={p.pageNo}
              pageCount={pageCount}
              elements={p.elements}
              tableSlice={p.tableSlice}
              stamp={stamp}
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div
      className={className}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: forPrint ? 'stretch' : 'center',
        gap: forPrint ? 0 : pageGap,
        width: forPrint ? undefined : template.page.width * MM * scale,
      }}
    >
      {list.map((p) => (
        <div
          key={p.pageNo}
          className={forPrint ? 'print-page' : undefined}
          style={{
            width: forPrint ? `${template.page.width}mm` : template.page.width * MM * scale,
            height: forPrint ? `${template.page.height}mm` : template.page.height * MM * scale,
            overflow: 'hidden',
            flexShrink: 0,
            boxShadow: forPrint ? undefined : '0 8px 40px rgba(0,0,0,0.45)',
            borderRadius: forPrint ? 0 : 2,
          }}
        >
          <div
            style={{
              width: `${template.page.width}mm`,
              height: `${template.page.height}mm`,
              transform: forPrint ? undefined : `scale(${scale})`,
              transformOrigin: 'top left',
              background: '#ffffff',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            <SinglePage
              template={template}
              bill={bill}
              settings={settings}
              copyIndex={copyIndex}
              pageNo={p.pageNo}
              pageCount={pageCount}
              elements={p.elements}
              tableSlice={p.tableSlice}
              stamp={stamp}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

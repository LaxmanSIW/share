'use client';

/* Fit-to-container scale hook for page previews.
 * The DOM node never crosses the hook boundary: callers receive a
 * callback-ref function and a scale number only.
 * When pageHeightMm is provided, the scale also fits that height
 * (useful for non-scrolling thumbnails). */
import { useCallback, useEffect, useRef, useState } from 'react';
import { MM } from '@/components/studio/ElementRenderer';

export function useFitScale(
  pageWidthMm: number,
  paddingPx = 32,
  maxScale = 1,
  pageHeightMm?: number,
): [(node: HTMLDivElement | null) => void, number] {
  const [scale, setScale] = useState(0.5);
  const nodeRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const node = nodeRef.current;
    if (!node) return;
    const update = () => {
      const w = node.clientWidth - paddingPx;
      const target = w / (pageWidthMm * MM);
      const h = pageHeightMm ? node.clientHeight - paddingPx : Infinity;
      const targetH = pageHeightMm ? h / (pageHeightMm * MM) : Infinity;
      setScale(Math.max(0.05, Math.min(maxScale, target, targetH)));
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(node);
    return () => ro.disconnect();
  }, [pageWidthMm, pageHeightMm, paddingPx, maxScale]);

  const attach = useCallback((node: HTMLDivElement | null) => {
    nodeRef.current = node;
  }, []);

  return [attach, scale];
}

/* ============================================================
 * InvoiceStudio — renders a single template element
 * Used by: Designer canvas (design mode), Bill preview & print (final mode),
 *          and the server-side PDF export (no 'use client' — shared module,
 *          hook-free so both React runtimes can invoke it directly).
 * ============================================================ */
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import type { BillItem, TemplateElement } from '@/lib/studio/types';
import { code128Svg } from '@/lib/studio/code128';
import { isServerRender, qrSvg } from '@/lib/studio/qrsvg';
import {
  buildBarcodeValue, buildQrPayload, isTextBlank, itemCellValue, resolveText,
  type RenderContext,
} from '@/lib/studio/render';

export const MM = 3.7795275591; // px per mm at 96dpi

interface Props {
  el: TemplateElement;
  mode: 'design' | 'final';
  ctx?: RenderContext; // required in final mode
  onPointerDown?: (e: React.PointerEvent) => void;
  onDoubleClick?: (e: React.MouseEvent) => void;
  selected?: boolean;
  /** table row window for this page (absolute indices into ctx.items) */
  rowStart?: number;
  rowEnd?: number;
}

/** Highlight {{variables}} in design mode / resolve in final mode. */
function TemplateText({
  text,
  mode,
  ctx,
}: {
  text: string;
  mode: 'design' | 'final';
  ctx?: RenderContext;
}) {
  if (mode === 'final' && ctx) {
    return <>{resolveText(text, ctx.values)}</>;
  }
  const parts = text.split(/(\{\{\s*[a-zA-Z0-9_]+\s*\}\})/g);
  return (
    <>
      {parts.map((p, i) =>
        /^\{\{.*\}\}$/.test(p) ? (
          <span key={i} className="rounded-[2px] bg-amber-200/60 px-[1px] text-[inherit] text-stone-700">
            {p.replace(/^\{\{\s*|\s*\}\}$/g, '')}
          </span>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

function placeholderItems(): BillItem[] {
  return [
    { id: 'p1', desc: 'Brass Hinges 4" (Sample)', hsn: '8302', qty: 24, unit: 'PCS', rate: 125, gst: 18 },
    { id: 'p2', desc: 'Steel Tower Bolt 6" (Sample)', hsn: '8302', qty: 36, unit: 'PCS', rate: 88.5, gst: 18 },
    { id: 'p3', desc: 'Door Handle Set (Sample)', hsn: '8302', qty: 10, unit: 'SET', rate: 1150, gst: 18 },
    { id: 'p4', desc: 'Packing & Forwarding (Sample)', hsn: '9985', qty: 1, unit: 'LOT', rate: 250, gst: 12 },
  ];
}

/** demo context for design-mode QR/barcode previews */
function demoCtx(): RenderContext {
  return {
    values: { invoice_no: 'INV-0001', grand_total: '1,24,260.00' },
    items: [],
    settings: {
      business: { name: 'Demo Traders', upi: 'demo@upi' },
    },
    pageNo: 1,
    pageCount: 1,
    copyLabel: '',
  } as unknown as RenderContext;
}

/** CODE128 barcode drawn into an inline SVG that stretches to the element box.
 *  Uses the isomorphic code128 encoder — identical output on screen, in print
 *  and in the server-side PDF (viewBox + preserveAspectRatio="none" stretches
 *  the bars to exactly fill the element). */
function BarcodeSvg({ value, color, showText }: { value: string; color: string; showText?: boolean }) {
  const markup = code128Svg(value, { color, showText });
  if (!markup) return null;
  return (
    <div
      style={{ width: '100%', height: '100%', display: 'block' }}
      dangerouslySetInnerHTML={{ __html: markup }}
    />
  );
}

export default function ElementRenderer({
  el,
  mode,
  ctx,
  onPointerDown,
  onDoubleClick,
  selected,
  rowStart,
  rowEnd,
}: Props) {
  const base: React.CSSProperties = {
    position: 'absolute',
    left: `${el.x}mm`,
    top: `${el.y}mm`,
    width: `${el.w}mm`,
    height: `${el.h}mm`,
    zIndex: el.zIndex ?? 0,
    opacity: el.opacity ?? 1,
    transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined,
    transformOrigin: 'center center',
  };

  const wrapperPointer = mode === 'design' ? onPointerDown : undefined;
  const wrapperDblClick = mode === 'design' ? onDoubleClick : undefined;
  const cursor = mode === 'design' ? { cursor: 'move' as const } : {};

  /* ---------- hide-when-blank (final output only) ---------- */
  if (mode === 'final' && ctx && el.hideWhenBlank) {
    let blank = false;
    if (el.type === 'text') blank = isTextBlank(el.text ?? '', ctx.values);
    else if (el.type === 'image') blank = !(el.src || (el.useBusinessLogo ? ctx.values['business_logo'] : ''));
    else if (el.type === 'qrcode') blank = !buildQrPayload(el, ctx);
    else if (el.type === 'barcode') blank = !buildBarcodeValue(el, ctx);
    if (blank) return null;
  }

  /* ---------- RECT ---------- */
  if (el.type === 'rect') {
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          background: el.bg || 'transparent',
          border: el.borderWidth ? `${el.borderWidth}mm solid ${el.borderColor || '#000'}` : undefined,
          borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
          boxSizing: 'border-box',
        }}
      />
    );
  }

  /* ---------- LINE ---------- */
  if (el.type === 'line') {
    const thickness = Math.max(el.borderWidth ?? 0.3, 0.15);
    const isH = el.direction !== 'v';
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          background: el.borderColor || '#000',
          width: isH ? `${el.w}mm` : `${thickness}mm`,
          height: isH ? `${thickness}mm` : `${el.h}mm`,
          borderRadius: '999px',
        }}
      />
    );
  }

  /* ---------- IMAGE ---------- */
  if (el.type === 'image') {
    const businessLogo = el.useBusinessLogo && ctx ? ctx.values['business_logo'] : '';
    const resolvedSrc = el.src || businessLogo;
    const hasSrc = !!resolvedSrc;
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
          border: mode === 'design' && !hasSrc ? '0.3mm dashed #b8a26a' : undefined,
          borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
          background: el.bg || 'transparent',
        }}
      >
        {hasSrc ? (
           
          <img
            src={resolvedSrc}
            alt="Logo"
            draggable={false}
            style={{ width: '100%', height: '100%', objectFit: el.objectFit ?? 'contain' }}
          />
        ) : mode === 'design' ? (
          <span style={{ fontSize: 8, letterSpacing: 2, color: '#b8a26a', fontWeight: 700 }}>
            {el.useBusinessLogo ? 'BIZ LOGO' : 'LOGO'}
          </span>
        ) : null}
      </div>
    );
  }

  /* ---------- QR CODE ---------- */
  if (el.type === 'qrcode') {
    const payload =
      mode === 'final' && ctx
        ? buildQrPayload(el, ctx)
        : buildQrPayload(el, {
            ...demoCtx(),
            settings: { business: { name: 'Demo Traders', upi: el.qrSource === 'custom' ? '' : 'demo@upi' } },
          } as unknown as RenderContext);
    const dark = el.qrColor || '#1a1a1a';
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#ffffff',
          overflow: 'hidden',
          borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
        }}
        title={mode === 'design' ? `QR — ${el.qrSource ?? 'upi_amount'}` : undefined}
      >
        {payload ? (
          isServerRender() ? (
            // server-side PDF export — hook-free QR renderer (same matrix output)
            <div
              style={{ width: '100%', height: '100%' }}
              dangerouslySetInnerHTML={{
                __html: qrSvg(payload, { fgColor: dark, bgColor: '#ffffff' }),
              }}
            />
          ) : (
            <QRCodeSVG
              value={payload}
              size={256}
              marginSize={0}
              bgColor="#ffffff"
              fgColor={dark}
              style={{ width: '100%', height: '100%' }}
            />
          )
        ) : (
          mode === 'design' && (
            <span style={{ fontSize: 7, letterSpacing: 1, color: '#b8a26a', fontWeight: 700 }}>SET UPI</span>
            )
        )}
      </div>
    );
  }

  /* ---------- BARCODE (CODE128) ---------- */
  if (el.type === 'barcode') {
    const value =
      mode === 'final' && ctx
        ? buildBarcodeValue(el, ctx)
        : buildBarcodeValue(el, demoCtx());
    const ink = el.barcodeColor || '#1a1a1a';
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: el.bg || 'transparent',
          padding: el.padding ? `${el.padding}mm` : 0,
          boxSizing: 'border-box',
          overflow: 'hidden',
          borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
        }}
        title={mode === 'design' ? `Barcode CODE128 — ${el.barcodeData || '{{invoice_no}}'}` : undefined}
      >
        {value ? (
          <BarcodeSvg value={value} color={ink} showText={el.barcodeShowText !== false} />
        ) : (
          mode === 'design' && (
            <span style={{ fontSize: 7, letterSpacing: 1, color: '#b8a26a', fontWeight: 700 }}>SET DATA</span>
          )
        )}
      </div>
    );
  }

  /* ---------- PAGE NO ---------- */
  if (el.type === 'pageno') {
    const label =
      mode === 'final' && ctx
        ? `Page ${ctx.pageNo} of ${ctx.pageCount}`
        : 'Page 1';
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          display: 'flex',
          alignItems: el.vAlign === 'middle' ? 'center' : el.vAlign === 'bottom' ? 'flex-end' : 'flex-start',
          justifyContent: 'center',
          fontFamily: el.fontFamily,
          fontSize: `${el.fontSize ?? 9}pt`,
          color: el.color || '#333',
          fontWeight: el.fontWeight,
        }}
      >
        {label}
      </div>
    );
  }

  /* ---------- TEXT ---------- */
  if (el.type === 'text') {
    const justify = el.align === 'center' ? 'center' : el.align === 'right' ? 'flex-end' : 'flex-start';
    return (
      <div
        data-el-id={el.id}
        onPointerDown={wrapperPointer}
        onDoubleClick={wrapperDblClick}
        style={{
          ...base,
          ...cursor,
          display: 'flex',
          flexDirection: 'column',
          alignItems: justify,
          justifyContent:
            el.vAlign === 'middle' ? 'center' : el.vAlign === 'bottom' ? 'flex-end' : 'flex-start',
          background: el.bg || 'transparent',
          border: el.borderWidth ? `${el.borderWidth}mm solid ${el.borderColor || '#000'}` : undefined,
          borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
          padding: el.padding ? `${el.padding}mm` : 0,
          boxSizing: 'border-box',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            width: '100%',
            fontFamily: el.fontFamily,
            fontSize: `${el.fontSize ?? 10}pt`,
            fontWeight: el.fontWeight ?? 400,
            fontStyle: el.italic ? 'italic' : undefined,
            textDecoration: el.underline ? 'underline' : undefined,
            textTransform: el.uppercase ? 'uppercase' : undefined,
            color: el.color || '#1a1a1a',
            textAlign: el.align ?? 'left',
            lineHeight: el.lineHeight ?? 1.25,
            letterSpacing: el.letterSpacing ? `${el.letterSpacing}pt` : undefined,
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
          }}
        >
          <TemplateText text={el.text ?? ''} mode={mode} ctx={ctx} />
        </div>
      </div>
    );
  }

  /* ---------- TABLE ---------- */
  const cols = el.columns ?? [];
  const allItems = mode === 'final' && ctx ? ctx.items : placeholderItems();
  const sIdx = mode === 'final' ? Math.max(rowStart ?? 0, 0) : 0;
  const eIdx = mode === 'final' ? rowEnd ?? allItems.length : allItems.length;
  const items = allItems.slice(sIdx, eIdx);
  const headerBg = el.headerBg || '#efe9db';
  const headerColor = el.headerColor || '#1a1a1a';
  const gridColor = '#b9b3a4';
  const rowHeight = el.rowHeight ?? 7;

  const cellBorder = (isHeader: boolean, isLast: boolean): React.CSSProperties => {
    if (el.borderStyle === 'none') return {};
    if (el.borderStyle === 'rows') {
      return { borderBottom: `0.25mm solid ${gridColor}` };
    }
    return {
      border: `0.25mm solid ${gridColor}`,
      borderRightWidth: isLast ? '0.25mm' : undefined,
    };
  };

  return (
    <div
      data-el-id={el.id}
      onPointerDown={wrapperPointer}
      onDoubleClick={wrapperDblClick}
      style={{
        ...base,
        ...cursor,
        overflow: 'hidden',
        background: el.bg || 'transparent',
        borderRadius: el.borderRadius ? `${el.borderRadius}mm` : undefined,
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* header */}
      <div style={{ display: 'flex', background: headerBg, flexShrink: 0 }}>
        {cols.map((c, ci) => (
          <div
            key={c.key + ci}
            style={{
              width: `${c.width}%`,
              padding: '1.2mm 1.5mm',
              fontFamily: el.fontFamily,
              fontSize: `${(el.fontSize ?? 9) + 0.25}pt`,
              fontWeight: 700,
              color: headerColor,
              textAlign: c.align,
              letterSpacing: 0.2,
              boxSizing: 'border-box',
              ...cellBorder(true, ci === cols.length - 1),
            }}
          >
            {c.label}
          </div>
        ))}
      </div>
      {/* body */}
      {items.map((item, ri) => {
        const abs = mode === 'final' ? sIdx + ri : ri;
        return (
        <div
          key={item.id || ri}
          style={{
            display: 'flex',
            flexShrink: 0,
            height: `${rowHeight}mm`,
            background: el.showZebra && ri % 2 === 1 ? 'rgba(0,0,0,0.03)' : undefined,
          }}
        >
          {cols.map((c, ci) => (
            <div
              key={c.key + ci}
              style={{
                width: `${c.width}%`,
                padding: '1mm 1.5mm',
                fontFamily: el.fontFamily,
                fontSize: `${el.fontSize ?? 9}pt`,
                color: el.color || '#1a1a1a',
                textAlign: c.align,
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'flex-start',
                ...cellBorder(false, ci === cols.length - 1),
              }}
            >
              {itemCellValue(item, c.key, abs)}
            </div>
          ))}
        </div>
        );
      })}
      {mode === 'design' && items.length === 0 && (
        <div style={{ padding: 4, fontSize: 9, color: '#999' }}>No items</div>
      )}
    </div>
  );
}

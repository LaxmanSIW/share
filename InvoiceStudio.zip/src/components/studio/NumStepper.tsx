'use client';

/* ============================================================
 * InvoiceStudio — NumStepper
 * Compact stepper input with clickable +/- buttons, shift-step,
 * keyboard arrow support, and decimal precision clamping.
 * ============================================================ */
import React, { useEffect, useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { Label } from '@/components/ui/label';

export interface NumStepperProps {
  label?: string;
  value: number | undefined;
  onChange: (value: number) => void;
  step?: number;
  shiftStep?: number;
  min?: number;
  max?: number;
  suffix?: string;
  placeholder?: string;
  className?: string;
  labelWidth?: string;
  disabled?: boolean;
  size?: 'sm' | 'default';
}

export function NumStepper({
  label,
  value,
  onChange,
  step = 1,
  shiftStep,
  min,
  max,
  suffix,
  placeholder,
  className = '',
  labelWidth = 'w-12',
  disabled = false,
  size = 'default',
}: NumStepperProps) {
  const safeVal = Number.isFinite(value) ? (value as number) : 0;
  const precision = step < 0.01 ? 3 : step < 0.1 ? 2 : step < 1 ? 1 : 0;
  const actualShiftStep = shiftStep ?? (step >= 10 ? step * 2 : step >= 1 ? step * 5 : step * 10);

  const [text, setText] = useState<string>(() => String(Number(safeVal.toFixed(precision))));
  const [isFocused, setIsFocused] = useState(false);

  // Sync text with external value changes when not actively focused
  useEffect(() => {
    if (!isFocused) {
      setText(String(Number(safeVal.toFixed(precision))));
    }
  }, [safeVal, precision, isFocused]);

  const clampAndRound = (val: number): number => {
    let v = val;
    if (min !== undefined && v < min) v = min;
    if (max !== undefined && v > max) v = max;
    return Number(v.toFixed(precision));
  };

  const handleStep = (dir: -1 | 1, isShift: boolean) => {
    if (disabled) return;
    const delta = (isShift ? actualShiftStep : step) * dir;
    const next = clampAndRound(safeVal + delta);
    onChange(next);
    setText(String(next));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setText(e.target.value);
    const parsed = parseFloat(e.target.value);
    if (!isNaN(parsed) && Number.isFinite(parsed)) {
      onChange(clampAndRound(parsed));
    }
  };

  const handleBlur = () => {
    setIsFocused(false);
    const parsed = parseFloat(text);
    if (isNaN(parsed) || !Number.isFinite(parsed)) {
      const fallback = min !== undefined ? min : 0;
      onChange(fallback);
      setText(String(fallback));
    } else {
      const clamped = clampAndRound(parsed);
      onChange(clamped);
      setText(String(clamped));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      handleStep(1, e.shiftKey);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      handleStep(-1, e.shiftKey);
    } else if (e.key === 'Enter') {
      (e.target as HTMLInputElement).blur();
    }
  };

  const canDecrease = !disabled && (min === undefined || safeVal > min);
  const canIncrease = !disabled && (max === undefined || safeVal < max);

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      {label && (
        <Label
          className={`${labelWidth} shrink-0 text-[11px] font-medium text-zinc-400 select-none truncate`}
          title={label}
        >
          {label}
        </Label>
      )}
      <div className="relative flex flex-1 min-w-0 items-center rounded-md border border-[#2a3342] bg-[#0d1117] transition-all duration-150 focus-within:border-[#d9a13b] focus-within:ring-1 focus-within:ring-[#d9a13b]/40 hover:border-[#3b475c]">
        <button
          type="button"
          tabIndex={-1}
          disabled={!canDecrease}
          onClick={(e) => handleStep(-1, e.shiftKey)}
          className="flex h-7 w-6 shrink-0 cursor-pointer items-center justify-center rounded-l text-zinc-400 hover:bg-[#1a2230] hover:text-[#d9a13b] active:scale-95 disabled:pointer-events-none disabled:opacity-25 transition-all"
          title={`Decrease by ${step} (Shift+click: ${actualShiftStep})`}
        >
          <Minus className="h-3 w-3" />
        </button>

        <input
          type="text"
          inputMode="decimal"
          disabled={disabled}
          placeholder={placeholder}
          className="h-7 w-full min-w-0 bg-transparent px-1 text-center font-mono text-xs text-zinc-100 tabular outline-none focus:text-white disabled:opacity-50"
          value={text}
          onFocus={() => setIsFocused(true)}
          onChange={handleInputChange}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
        />

        {suffix && (
          <span className="shrink-0 pr-1 text-[10px] text-zinc-500 font-mono select-none pointer-events-none">
            {suffix}
          </span>
        )}

        <button
          type="button"
          tabIndex={-1}
          disabled={!canIncrease}
          onClick={(e) => handleStep(1, e.shiftKey)}
          className="flex h-7 w-6 shrink-0 cursor-pointer items-center justify-center rounded-r text-zinc-400 hover:bg-[#1a2230] hover:text-[#d9a13b] active:scale-95 disabled:pointer-events-none disabled:opacity-25 transition-all"
          title={`Increase by ${step} (Shift+click: ${actualShiftStep})`}
        >
          <Plus className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
}

export default NumStepper;

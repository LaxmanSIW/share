'use client';

/* ============================================================
 * InvoiceStudio — layers panel (element stack)
 * ============================================================ */
import React from 'react';
import {
  Eye, EyeOff, Image as ImageIcon, Lock, LockOpen, MinusSquare,
  Table2, Type as TypeIcon, Square, Minus, Hash, QrCode, Barcode, Trash2,
} from 'lucide-react';
import type { TemplateElement } from '@/lib/studio/types';

const ICONS: Record<TemplateElement['type'], React.ReactNode> = {
  text: <TypeIcon className="h-3 w-3" />,
  image: <ImageIcon className="h-3 w-3" />,
  table: <Table2 className="h-3 w-3" />,
  line: <Minus className="h-3 w-3" />,
  rect: <Square className="h-3 w-3" />,
  pageno: <Hash className="h-3 w-3" />,
  qrcode: <QrCode className="h-3 w-3" />,
  barcode: <Barcode className="h-3 w-3" />,
};

interface Props {
  elements: TemplateElement[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onToggleHidden: (id: string) => void;
  onToggleLocked: (id: string) => void;
  onDelete: (id: string) => void;
}

function labelOf(el: TemplateElement): string {
  if (el.type === 'text') {
    const t = (el.text ?? '').replace(/\s+/g, ' ').trim();
    return t ? (t.length > 22 ? `${t.slice(0, 22)}…` : t) : 'Empty text';
  }
  if (el.type === 'table') return `Table · ${el.columns?.length ?? 0} cols`;
  if (el.type === 'image') return el.src ? 'Image' : 'Logo placeholder';
  if (el.type === 'qrcode') return `QR — ${el.qrSource === 'custom' ? 'custom' : el.qrSource === 'upi' ? 'UPI' : 'UPI + amount'}`;
  if (el.type === 'barcode') return `Barcode — ${(el.barcodeData || '{{invoice_no}}').slice(0, 18)}`;
  if (el.type === 'line') return 'Line';
  if (el.type === 'rect') return 'Box / Shape';
  return 'Page number';
}

export default function LayersPanel({
  elements, selectedId, onSelect, onToggleHidden, onToggleLocked, onDelete,
}: Props) {
  const sorted = [...elements].sort((a, b) => (b.zIndex ?? 0) - (a.zIndex ?? 0));
  return (
    <div className="studio-scroll h-full overflow-y-auto py-2">
      <div className="mb-1 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
        Layers · {elements.length}
      </div>
      {sorted.length === 0 && (
        <p className="px-3 py-4 text-[11px] text-zinc-600">No elements yet. Add one from the toolbar.</p>
      )}
      {sorted.map((el) => {
        const active = el.id === selectedId;
        return (
          <div
            key={el.id}
            onClick={() => onSelect(el.id)}
            className={`group mx-1.5 flex cursor-pointer items-center gap-1.5 rounded px-2 py-1.5 text-[11px] transition-colors ${
              active ? 'bg-[#d9a13b]/15 text-[#e8c064]' : 'text-zinc-400 hover:bg-[#1a212c]'
            }`}
          >
            <span className={active ? 'text-[#d9a13b]' : 'text-zinc-600'}>{ICONS[el.type]}</span>
            <span className="flex-1 truncate">{labelOf(el)}</span>
            <button
              type="button"
              title={el.hidden ? 'Show' : 'Hide'}
              onClick={(e) => { e.stopPropagation(); onToggleHidden(el.id); }}
              className="text-zinc-600 opacity-0 transition-opacity hover:text-zinc-200 group-hover:opacity-100"
            >
              {el.hidden ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </button>
            <button
              type="button"
              title={el.locked ? 'Unlock' : 'Lock'}
              onClick={(e) => { e.stopPropagation(); onToggleLocked(el.id); }}
              className={`text-zinc-600 transition-opacity hover:text-zinc-200 group-hover:opacity-100 ${el.locked ? 'opacity-100 text-amber-500' : ''}`}
            >
              {el.locked ? <Lock className="h-3 w-3" /> : <LockOpen className="h-3 w-3" />}
            </button>
            <button
              type="button"
              title="Delete"
              onClick={(e) => { e.stopPropagation(); onDelete(el.id); }}
              className="text-zinc-600 opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
            >
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        );
      })}
      {elements.length > 0 && (
        <div className="mt-2 flex items-center gap-1 px-3 text-[9px] text-zinc-700">
          <MinusSquare className="h-2.5 w-2.5" /> top of list = front
        </div>
      )}
    </div>
  );
}

'use client';

/* ============================================================
 * InvoiceStudio — printer calibration sheet
 * A pure print artifact: 10 mm reference grid + rulers + crop
 * marks, shifted by the configured print offsets so the user
 * can verify (or dial in) alignment on real paper.
 * All geometry uses mm strings — never raw numbers.
 * ============================================================ */
import React from 'react';
import type { Settings } from '@/lib/studio/types';

const mm = (v: number) => `${v}mm`;

export default function CalibrationSheet({ settings }: { settings: Settings }) {
  const W = 210;
  const H = 297;
  const offX = Number(settings.printOffsetX) || 0;
  const offY = Number(settings.printOffsetY) || 0;

  const grid: React.ReactNode[] = [];
  for (let x = 10; x < W; x += 10) {
    grid.push(
      <div key={`v${x}`} style={{ position: 'absolute', left: mm(x), top: 0, width: '0.15mm', height: mm(H), background: x % 50 === 0 ? '#8a8a8a' : '#d8d4cc' }} />,
    );
  }
  for (let y = 10; y < H; y += 10) {
    grid.push(
      <div key={`h${y}`} style={{ position: 'absolute', top: mm(y), left: 0, height: '0.15mm', width: mm(W), background: y % 50 === 0 ? '#8a8a8a' : '#d8d4cc' }} />,
    );
  }

  const topRuler: React.ReactNode[] = [];
  for (let x = 10; x < W; x += 10) {
    const major = x % 50 === 0;
    topRuler.push(
      <div key={`t${x}`} style={{ position: 'absolute', left: mm(x), top: 0, width: major ? '0.5mm' : '0.2mm', height: major ? mm(8) : mm(4), background: '#111' }} />,
    );
    if (major) {
      topRuler.push(
        <div key={`tl${x}`} style={{ position: 'absolute', left: mm(x + 1), top: mm(8.5), fontSize: '5.5pt', color: '#111' }}>{x}</div>,
      );
    }
  }

  const leftRuler: React.ReactNode[] = [];
  for (let y = 10; y < H; y += 10) {
    const major = y % 50 === 0;
    leftRuler.push(
      <div key={`l${y}`} style={{ position: 'absolute', top: mm(y), left: 0, height: major ? '0.5mm' : '0.2mm', width: major ? mm(8) : mm(4), background: '#111' }} />,
    );
    if (major) {
      leftRuler.push(
        <div key={`ll${y}`} style={{ position: 'absolute', top: mm(y + 1), left: mm(9), fontSize: '5.5pt', color: '#111' }}>{y}</div>,
      );
    }
  }

  return (
    <div
      style={{
        width: mm(W),
        height: mm(H),
        position: 'relative',
        background: '#ffffff',
        color: '#111',
        fontFamily: 'Arial, Helvetica, sans-serif',
        overflow: 'hidden',
        pageBreakAfter: 'always',
      }}
    >
      {/* offset shift — identical transform to real bill printing */}
      <div style={{ position: 'absolute', inset: 0, transform: offX || offY ? `translate(${offX}mm, ${offY}mm)` : undefined }}>
        {grid}
        {topRuler}
        {leftRuler}

        {/* corner crop marks (L-shaped, 10 mm legs) */}
        <div style={{ position: 'absolute', left: 0, top: 0, width: mm(10), height: mm(10), borderLeft: '0.5mm solid #111', borderTop: '0.5mm solid #111' }} />
        <div style={{ position: 'absolute', right: 0, top: 0, width: mm(10), height: mm(10), borderRight: '0.5mm solid #111', borderTop: '0.5mm solid #111' }} />
        <div style={{ position: 'absolute', left: 0, bottom: 0, width: mm(10), height: mm(10), borderLeft: '0.5mm solid #111', borderBottom: '0.5mm solid #111' }} />
        <div style={{ position: 'absolute', right: 0, bottom: 0, width: mm(10), height: mm(10), borderRight: '0.5mm solid #111', borderBottom: '0.5mm solid #111' }} />

        {/* 100 × 50 mm test box at (20,20) */}
        <div style={{ position: 'absolute', left: mm(20), top: mm(20), width: mm(100), height: mm(50), border: '0.6mm solid #111' }}>
          <span style={{ position: 'absolute', left: mm(2), top: mm(1.5), fontSize: '7pt', fontWeight: 700 }}>
            100 × 50 mm
          </span>
        </div>

        {/* centre crosshair */}
        <div style={{ position: 'absolute', left: mm(W / 2 - 10), top: mm(H / 2), width: mm(20), height: '0.4mm', background: '#111' }} />
        <div style={{ position: 'absolute', left: mm(W / 2), top: mm(H / 2 - 10), height: mm(20), width: '0.4mm', background: '#111' }} />
        <div style={{ position: 'absolute', left: mm(W / 2 + 2), top: mm(H / 2 + 1), fontSize: '6pt' }}>
          centre {W / 2}×{H / 2}
        </div>

        {/* 150 mm stepped span at y=90 */}
        <div style={{ position: 'absolute', left: mm(20), top: mm(90), width: mm(150), height: mm(6), border: '0.4mm solid #111', display: 'flex' }}>
          {Array.from({ length: 15 }).map((_, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                borderRight: i < 14 ? '0.2mm solid #999' : undefined,
                fontSize: '4.5pt',
                textAlign: 'right',
                color: '#666',
              }}
            >
              {(i + 1) * 10}
            </div>
          ))}
        </div>
        <div style={{ position: 'absolute', left: mm(20), top: mm(97), fontSize: '6pt' }}>
          150 mm horizontal span (10 mm steps)
        </div>

        {/* bottom-right info block */}
        <div style={{ position: 'absolute', right: mm(8), bottom: mm(8), textAlign: 'right', fontSize: '7pt', lineHeight: 1.6 }}>
          <div style={{ fontSize: '9pt', fontWeight: 700, letterSpacing: '1px' }}>PRINT CALIBRATION — A4</div>
          <div>{String(settings.business?.name ?? 'InvoiceStudio')}</div>
          <div>
            applied offsets: X {offX > 0 ? `+${offX}` : offX} mm · Y {offY > 0 ? `+${offY}` : offY} mm
          </div>
          <div style={{ color: '#555' }}>
            measure the drift between printed &amp; expected lines, then set
            <br />
            Settings → Print Calibration so bills land on pre-printed stock.
          </div>
        </div>
      </div>
    </div>
  );
}

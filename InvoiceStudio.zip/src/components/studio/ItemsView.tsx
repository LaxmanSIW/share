'use client';

/* ============================================================
 * InvoiceStudio — items master & sales analytics
 * Saved items catalog + CRUD + graphical reports (units sold & revenue)
 * ============================================================ */
import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  BarChart3,
  CheckCircle2,
  Package,
  Pencil,
  Plus,
  ReceiptText,
  Search,
  Sparkles,
  Tag,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import type { Bill, ItemRecord } from '@/lib/studio/types';
import { fmtDate, fmtMoney, itemAmount } from '@/lib/studio/format';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

const COMMON_UNITS = ['PCS', 'NOS', 'BOX', 'KG', 'MTR', 'HRS', 'SET', 'PKT', 'LTR', 'BAG', 'DOZ'];
const COMMON_GST = [0, 5, 12, 18, 28];

interface Props {
  items: ItemRecord[];
  bills: Bill[];
  currency: string;
  onChanged: () => void;
  onNewBillWithItem?: (item: ItemRecord) => void;
}

interface ItemForm {
  name: string;
  hsn: string;
  unit: string;
  rate: number;
  gst: number;
}

const EMPTY_FORM: ItemForm = {
  name: '',
  hsn: '',
  unit: 'PCS',
  rate: 0,
  gst: 18,
};

type SortField = 'name' | 'rate' | 'soldQty' | 'soldAmount';

export default function ItemsView({ items, bills, currency, onChanged, onNewBillWithItem }: Props) {
  const { toast } = useToast();
  const [q, setQ] = useState('');
  const [sortBy, setSortBy] = useState<SortField>('soldQty');
  const [sortAsc, setSortAsc] = useState(false);
  const [editing, setEditing] = useState<ItemRecord | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<ItemForm>(EMPTY_FORM);
  const [deleting, setDeleting] = useState<ItemRecord | null>(null);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'catalog' | 'analytics'>('catalog');

  /* ---------------- aggregate item metrics from bills ---------------- */
  const itemStats = useMemo(() => {
    // map normalized item name -> { totalQty, totalAmount, billCount }
    const statsMap = new Map<string, { totalQty: number; totalAmount: number; billCount: number }>();

    for (const b of bills) {
      if (b.status === 'cancelled') continue;
      for (const it of b.items ?? []) {
        const descKey = (it.desc ?? '').trim().toLowerCase();
        if (!descKey) continue;
        const cur = statsMap.get(descKey) ?? { totalQty: 0, totalAmount: 0, billCount: 0 };
        cur.totalQty += Number(it.qty) || 0;
        cur.totalAmount += itemAmount(it);
        cur.billCount += 1;
        statsMap.set(descKey, cur);
      }
    }

    return statsMap;
  }, [bills]);

  /* compute KPI summary numbers */
  const kpis = useMemo(() => {
    let totalUnitsSold = 0;
    let totalRevenue = 0;
    let topItem = { name: '—', qty: 0 };

    for (const it of items) {
      const s = itemStats.get(it.name.trim().toLowerCase());
      if (s) {
        totalUnitsSold += s.totalQty;
        totalRevenue += s.totalAmount;
        if (s.totalQty > topItem.qty) {
          topItem = { name: it.name, qty: s.totalQty };
        }
      }
    }

    // also check any items sold in bills not yet in catalog
    for (const [key, s] of itemStats.entries()) {
      if (s.totalQty > topItem.qty && !items.some((i) => i.name.toLowerCase() === key)) {
        topItem = { name: key, qty: s.totalQty };
      }
    }

    return {
      totalItems: items.length,
      totalUnitsSold,
      totalRevenue,
      topItemName: topItem.name,
      topItemQty: topItem.qty,
    };
  }, [items, itemStats]);

  /* items augmented with sales stats & filtered by search */
  const processedItems = useMemo(() => {
    const list = items.map((it) => {
      const s = itemStats.get(it.name.trim().toLowerCase()) ?? { totalQty: 0, totalAmount: 0, billCount: 0 };
      return {
        ...it,
        soldQty: s.totalQty,
        soldAmount: s.totalAmount,
        billCount: s.billCount,
      };
    });

    const needle = q.trim().toLowerCase();
    const filtered = needle
      ? list.filter(
          (i) =>
            i.name.toLowerCase().includes(needle) ||
            i.hsn.toLowerCase().includes(needle) ||
            i.unit.toLowerCase().includes(needle),
        )
      : list;

    filtered.sort((a, b) => {
      let cmp = 0;
      if (sortBy === 'name') cmp = a.name.localeCompare(b.name);
      else if (sortBy === 'rate') cmp = a.rate - b.rate;
      else if (sortBy === 'soldQty') cmp = a.soldQty - b.soldQty;
      else if (sortBy === 'soldAmount') cmp = a.soldAmount - b.soldAmount;
      return sortAsc ? cmp : -cmp;
    });

    return filtered;
  }, [items, itemStats, q, sortBy, sortAsc]);

  /* Top 8 items by sold quantity for graphical chart */
  const chartItems = useMemo(() => {
    const sorted = [...processedItems].sort((a, b) => b.soldQty - a.soldQty).slice(0, 8);
    const maxQty = Math.max(...sorted.map((i) => i.soldQty), 1);
    const maxRevenue = Math.max(...sorted.map((i) => i.soldAmount), 1);
    return { list: sorted, maxQty, maxRevenue };
  }, [processedItems]);

  /* ---------------- CRUD actions ---------------- */
  const openCreate = () => {
    setForm(EMPTY_FORM);
    setCreating(true);
  };

  const openEdit = (it: ItemRecord) => {
    setEditing(it);
    setForm({
      name: it.name,
      hsn: it.hsn ?? '',
      unit: it.unit ?? 'PCS',
      rate: it.rate ?? 0,
      gst: it.gst ?? 18,
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = form.name.trim();
    if (!name) {
      toast({ title: 'Name required', description: 'Enter an item description/name.', variant: 'destructive' });
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        const res = await fetch(`/api/items/${editing.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        });
        if (!res.ok) throw new Error();
        toast({ title: 'Item updated', description: form.name });
      } else {
        const res = await fetch('/api/items', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        });
        if (!res.ok) throw new Error();
        toast({ title: 'Item added to catalog', description: form.name });
      }
      setCreating(false);
      setEditing(null);
      onChanged();
    } catch {
      toast({ title: 'Save failed', description: 'Could not persist item record.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleting) return;
    try {
      const res = await fetch(`/api/items/${deleting.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      toast({ title: 'Item deleted', description: deleting.name });
      setDeleting(null);
      onChanged();
    } catch {
      toast({ title: 'Delete failed', variant: 'destructive' });
    }
  };

  const toggleSort = (field: SortField) => {
    if (sortBy === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="studio-scroll flex-1 overflow-y-auto p-5">
      <div className="mx-auto max-w-6xl space-y-5">
        {/* Header row */}
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-100 flex items-center gap-2.5">
              <Package className="h-5 w-5 text-[#d9a13b]" /> Item Catalog & Reports
            </h1>
            <p className="mt-0.5 text-xs text-zinc-400">
              Manage product and service items, set default rates & GST, and track sales performance across bills.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-md border border-[#232b38] bg-[#12161d] p-0.5">
              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className={`rounded px-3 py-1 text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'catalog'
                    ? 'bg-[#1e2634] text-[#e8c064] shadow-xs font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Catalog ({items.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('analytics')}
                className={`rounded px-3 py-1 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'analytics'
                    ? 'bg-[#1e2634] text-[#e8c064] shadow-xs font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <BarChart3 className="h-3.5 w-3.5" /> Sales Reports
              </button>
            </div>
            <Button
              className="h-8 gap-1.5 bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055] cursor-pointer"
              onClick={openCreate}
            >
              <Plus className="h-3.5 w-3.5" /> New Item
            </Button>
          </div>
        </div>

        {/* KPI Summary Tiles */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-3.5">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold flex items-center gap-1.5">
              <Tag className="h-3.5 w-3.5 text-zinc-400" /> Catalog Items
            </div>
            <div className="mt-1 text-xl font-bold tracking-tight text-zinc-100 tabular">
              {kpis.totalItems}
            </div>
            <div className="mt-0.5 text-[10px] text-zinc-500">Reusable item masters</div>
          </div>

          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-3.5">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5 text-[#d9a13b]" /> Total Units Sold
            </div>
            <div className="mt-1 text-xl font-bold tracking-tight text-[#f3cd74] tabular">
              {kpis.totalUnitsSold.toLocaleString('en-IN')}
            </div>
            <div className="mt-0.5 text-[10px] text-zinc-500">Across active bills</div>
          </div>

          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-3.5">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold flex items-center gap-1.5">
              <BarChart3 className="h-3.5 w-3.5 text-emerald-400" /> Total Revenue
            </div>
            <div className="mt-1 text-xl font-bold tracking-tight text-emerald-300 tabular">
              {fmtMoney(kpis.totalRevenue, currency)}
            </div>
            <div className="mt-0.5 text-[10px] text-zinc-500">Item sales generated</div>
          </div>

          <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-3.5">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-amber-400" /> Top Seller
            </div>
            <div className="mt-1 truncate text-base font-bold text-zinc-100" title={kpis.topItemName}>
              {kpis.topItemName}
            </div>
            <div className="mt-0.5 text-[10px] text-zinc-500">
              {kpis.topItemQty > 0 ? `${kpis.topItemQty.toLocaleString()} units sold` : 'No sales yet'}
            </div>
          </div>
        </div>

        {/* Graphical Reports Section (Visible in Analytics tab or top of page) */}
        {activeTab === 'analytics' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {/* Units Sold Chart */}
              <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-400 flex items-center gap-1.5">
                    <BarChart3 className="h-3.5 w-3.5 text-[#d9a13b]" /> Top Items by Units Sold
                  </span>
                  <span className="text-[10px] text-zinc-500">Quantity</span>
                </div>

                {chartItems.list.length === 0 || chartItems.maxQty <= 1 ? (
                  <div className="flex h-48 flex-col items-center justify-center text-center text-xs text-zinc-500">
                    <Package className="h-8 w-8 text-zinc-700 mb-2" />
                    No sales data yet. Once you bill items, charts will appear here.
                  </div>
                ) : (
                  <div className="space-y-3 pt-2">
                    {chartItems.list.map((it, idx) => {
                      const pct = Math.max(4, Math.round((it.soldQty / chartItems.maxQty) * 100));
                      return (
                        <div key={it.id || idx} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="truncate font-medium text-zinc-200 max-w-[280px]">
                              {it.name}
                            </span>
                            <span className="font-mono text-zinc-300 tabular">
                              {it.soldQty} {it.unit}
                            </span>
                          </div>
                          <div className="h-2 w-full overflow-hidden rounded-full bg-[#18202c]">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#d9a13b] to-[#f5c868] transition-all duration-500"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Revenue Breakdown Chart */}
              <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-400 flex items-center gap-1.5">
                    <TrendingUp className="h-3.5 w-3.5 text-emerald-400" /> Top Items by Revenue
                  </span>
                  <span className="text-[10px] text-zinc-500">{currency}</span>
                </div>

                {chartItems.list.length === 0 || chartItems.maxRevenue <= 1 ? (
                  <div className="flex h-48 flex-col items-center justify-center text-center text-xs text-zinc-500">
                    <BarChart3 className="h-8 w-8 text-zinc-700 mb-2" />
                    No revenue data recorded yet.
                  </div>
                ) : (
                  <div className="space-y-3 pt-2">
                    {chartItems.list.map((it, idx) => {
                      const pct = Math.max(4, Math.round((it.soldAmount / chartItems.maxRevenue) * 100));
                      return (
                        <div key={it.id || idx} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="truncate font-medium text-zinc-200 max-w-[280px]">
                              {it.name}
                            </span>
                            <span className="font-mono text-emerald-300 tabular">
                              {fmtMoney(it.soldAmount, currency)}
                            </span>
                          </div>
                          <div className="h-2 w-full overflow-hidden rounded-full bg-[#18202c]">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-500"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Catalog Table Card */}
        <div className="rounded-lg border border-[#232b38] bg-[#12161d]">
          {/* Filter / Search toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#232b38] p-3.5">
            <div className="relative flex-1 min-w-[220px] max-w-md">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-500" />
              <Input
                className="h-8 pl-8 border-[#2a3342] bg-[#0d1117] text-xs"
                placeholder="Search items by description or HSN..."
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
            </div>
            <div className="text-xs text-zinc-500">
              Showing <span className="font-semibold text-zinc-300">{processedItems.length}</span> of {items.length} items
            </div>
          </div>

          {/* Table */}
          {processedItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-zinc-500">
              <Package className="h-10 w-10 text-zinc-700 mb-2" />
              <p className="text-sm font-medium text-zinc-400">No items found</p>
              <p className="text-xs text-zinc-500 mt-0.5">
                {q ? 'Try a different search keyword.' : 'Add your first product or service item to get started.'}
              </p>
              {!q && (
                <Button
                  size="sm"
                  className="mt-4 bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055] cursor-pointer"
                  onClick={openCreate}
                >
                  <Plus className="mr-1 h-3.5 w-3.5" /> Add First Item
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto no-scrollbar [scrollbar-width:none]">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#232b38] bg-[#0f1319] text-[10px] uppercase tracking-wider text-zinc-500 select-none">
                    <th className="py-2.5 px-3 font-medium">#</th>
                    <th
                      className="py-2.5 px-3 font-medium cursor-pointer hover:text-zinc-200"
                      onClick={() => toggleSort('name')}
                    >
                      <span className="flex items-center gap-1">
                        Item Description <ArrowUpDown className="h-3 w-3 opacity-60" />
                      </span>
                    </th>
                    <th className="py-2.5 px-3 font-medium">HSN / SAC</th>
                    <th className="py-2.5 px-3 font-medium">Unit</th>
                    <th
                      className="py-2.5 px-3 font-medium cursor-pointer hover:text-zinc-200"
                      onClick={() => toggleSort('rate')}
                    >
                      <span className="flex items-center gap-1">
                        Default Rate <ArrowUpDown className="h-3 w-3 opacity-60" />
                      </span>
                    </th>
                    <th className="py-2.5 px-3 font-medium">Default GST</th>
                    <th
                      className="py-2.5 px-3 font-medium cursor-pointer hover:text-zinc-200 text-right"
                      onClick={() => toggleSort('soldQty')}
                    >
                      <span className="flex items-center justify-end gap-1">
                        Units Sold <ArrowUpDown className="h-3 w-3 opacity-60" />
                      </span>
                    </th>
                    <th
                      className="py-2.5 px-3 font-medium cursor-pointer hover:text-zinc-200 text-right"
                      onClick={() => toggleSort('soldAmount')}
                    >
                      <span className="flex items-center justify-end gap-1">
                        Total Revenue <ArrowUpDown className="h-3 w-3 opacity-60" />
                      </span>
                    </th>
                    <th className="py-2.5 px-3 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#18202c]">
                  {processedItems.map((it, idx) => (
                    <tr key={it.id} className="hover:bg-[#151c27] transition-colors">
                      <td className="py-2.5 px-3 font-mono text-zinc-500">{idx + 1}</td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-zinc-100 text-[13px]">{it.name}</div>
                        <div className="text-[10px] text-zinc-500 font-mono">ID: {it.id}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        {it.hsn ? (
                          <span className="rounded bg-[#1c2432] px-1.5 py-0.5 font-mono text-[11px] text-zinc-300">
                            {it.hsn}
                          </span>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-zinc-300">{it.unit || 'PCS'}</td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-zinc-100 tabular">
                        {fmtMoney(it.rate, currency)}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="rounded-full bg-[#d9a13b]/10 px-2 py-0.5 text-[10px] font-semibold text-[#e8c064]">
                          {it.gst}%
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-zinc-200 tabular">
                        {it.soldQty > 0 ? (
                          <span className="font-semibold text-[#f3cd74]">{it.soldQty}</span>
                        ) : (
                          <span className="text-zinc-600">0</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-emerald-400 tabular">
                        {it.soldAmount > 0 ? fmtMoney(it.soldAmount, currency) : '—'}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {onNewBillWithItem && (
                            <button
                              type="button"
                              onClick={() => onNewBillWithItem(it)}
                              className="rounded p-1 text-zinc-400 hover:bg-[#1f2837] hover:text-[#d9a13b] transition-colors cursor-pointer"
                              title="Create bill with this item"
                            >
                              <ReceiptText className="h-3.5 w-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => openEdit(it)}
                            className="rounded p-1 text-zinc-400 hover:bg-[#1f2837] hover:text-zinc-100 transition-colors cursor-pointer"
                            title="Edit item"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleting(it)}
                            className="rounded p-1 text-zinc-500 hover:bg-rose-500/10 hover:text-rose-400 transition-colors cursor-pointer"
                            title="Delete item"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Create / Edit Modal Dialog */}
      <Dialog
        open={creating || !!editing}
        onOpenChange={(open) => {
          if (!open) {
            setCreating(false);
            setEditing(null);
          }
        }}
      >
        <DialogContent className="max-w-md border-[#2a3342] bg-[#12161d] text-zinc-200">
          <DialogHeader>
            <DialogTitle className="text-sm font-semibold flex items-center gap-2">
              <Package className="h-4 w-4 text-[#d9a13b]" />
              {editing ? 'Edit Item' : 'New Catalog Item'}
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Save reusable item details. When selected on a bill, these values populate by default.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSave} className="space-y-4 pt-2">
            <div>
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
                Item Description / Name *
              </Label>
              <Input
                required
                className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm"
                placeholder="e.g. Graphic Design Services, Cotton T-Shirt"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
                  HSN / SAC Code
                </Label>
                <Input
                  className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm font-mono"
                  placeholder="e.g. 998314"
                  value={form.hsn}
                  onChange={(e) => setForm({ ...form, hsn: e.target.value })}
                />
              </div>

              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
                  Unit
                </Label>
                <Select
                  value={form.unit}
                  onValueChange={(v) => setForm({ ...form, unit: v })}
                >
                  <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {COMMON_UNITS.map((u) => (
                      <SelectItem key={u} value={u} className="text-xs">
                        {u}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
                  Default Rate ({currency}) *
                </Label>
                <Input
                  type="number"
                  step="any"
                  min="0"
                  required
                  className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm font-mono tabular"
                  placeholder="0.00"
                  value={form.rate || ''}
                  onChange={(e) => setForm({ ...form, rate: parseFloat(e.target.value) || 0 })}
                />
                <p className="mt-1 text-[9px] text-zinc-500">Can be altered when billing</p>
              </div>

              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
                  Default GST %
                </Label>
                <Select
                  value={String(form.gst)}
                  onValueChange={(v) => setForm({ ...form, gst: Number(v) })}
                >
                  <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {COMMON_GST.map((g) => (
                      <SelectItem key={g} value={String(g)} className="text-xs">
                        {g}% GST
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#232b38]">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  setCreating(false);
                  setEditing(null);
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                size="sm"
                className="bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055]"
                disabled={saving}
              >
                {saving ? 'Saving…' : editing ? 'Update Item' : 'Add Item'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleting} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-sm">Delete Item</AlertDialogTitle>
            <AlertDialogDescription className="text-xs text-zinc-400">
              Are you sure you want to remove <span className="font-semibold text-zinc-100">{deleting?.name}</span> from the catalog?
              Past bills containing this item will remain untouched.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2a3342] bg-transparent text-xs hover:bg-[#1a2330]">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-xs text-white hover:bg-red-700"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

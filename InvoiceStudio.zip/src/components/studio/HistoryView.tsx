'use client';

/* ============================================================
 * InvoiceStudio — bill history
 * Search / filter / view / print / edit / duplicate / delete / CSV
 * Payment recording (partial payments, method + reference)
 * Document types: invoice / proforma / quotation / challan / credit note
 * ============================================================ */
import React, { useMemo, useState } from 'react';
import {
  ArrowRightLeft, BadgeCheck, CalendarCheck2, CalendarSync, CalendarX2, CircleDollarSign, Copy, Download, Eye,
  FileDown, HandCoins, ListChecks, MessageCircle, Pencil, Printer, ReceiptText, Search, Share2, Trash2, X,
} from 'lucide-react';
import type { Bill, BillPayment, BillStatus, DocType, PaymentMethod, Settings, Template } from '@/lib/studio/types';
import {
  billStatus, docTypeOf, DOC_TYPE_META, DOC_TYPE_TITLE, dueAmount, fmtDate, fmtMoney, nextRepeatDate, paidAmount,
  REPEAT_META, repeatEnded, repeatOf, repeatSkipped, STATUS_META, uid,
} from '@/lib/studio/format';
import { buildContext, buildQrPayload, paginateTemplate } from '@/lib/studio/render';
import { downloadPdf } from '@/lib/studio/downloadPdf';
import BillPreview from './BillPreview';
import type { ReceiptJob } from './PrintManager';
import { useFitScale } from './useFitScale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

interface Props {
  bills: Bill[];
  templates: Template[];
  settings: Settings;
  onEdit: (b: Bill) => void;
  onDuplicate: (b: Bill) => void;
  onConvert: (b: Bill) => void;
  onRepeat: (b: Bill) => void;
  onDeleted: (id: string) => void;
  onUpdated: (b: Bill) => void;
  onPrint: (template: Template, bill: Bill, copies: number) => void;
  onPrintReceipt: (job: ReceiptJob) => void;
  onNewBill?: () => void;
}

const PAYMENT_METHODS: PaymentMethod[] = ['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Card', 'Other'];

/** Build a wa.me deep-link sharing a payment receipt confirmation. */
function receiptWhatsAppUrl(b: Bill, p: BillPayment, receiptNo: string, settings: Settings): string {
  const biz = settings.business.name || 'Our business';
  const due = dueAmount(b);
  const lines = [
    `*RECEIPT — ${biz}*`,
    '',
    `Receipt no: ${receiptNo}`,
    `Date: ${fmtDate(p.date)}`,
    `Received with thanks from: ${b.variables['buyer_name'] || '—'}`,
    `Amount received: ${fmtMoney(p.amount, settings.currency)} (${p.method}${p.reference ? ` · Ref ${p.reference}` : ''})`,
    `Against invoice: ${b.billNo} dated ${fmtDate(b.date)}`,
    due > 0
      ? `Balance due: ${fmtMoney(due, settings.currency)}`
      : 'Invoice fully settled — thank you!',
    'This is a computer-generated confirmation.',
  ].filter(Boolean);
  const text = encodeURIComponent(lines.join('\n'));
  const digits = (b.variables['buyer_phone'] || '').replace(/\D/g, '');
  const phone = digits.length === 10 ? `91${digits}` : digits; // assume Indian local numbers
  return phone
    ? `https://wa.me/${phone}?text=${text}`
    : `https://wa.me/?text=${text}`;
}

/** Build a wa.me deep-link with a prefilled bill summary (UPI pay link included). */
function whatsappUrl(b: Bill, settings: Settings): string {
  const st = billStatus(b);
  const dt = docTypeOf(b);
  const ctx = buildContext(b, settings);
  const upi = buildQrPayload({ qrSource: 'upi_amount' }, ctx);
  const due = dueAmount(b);
  const lines = [
    `*${settings.business.name}*`,
    `${DOC_TYPE_TITLE[dt]} — ${b.billNo}`,
    `Date: ${fmtDate(b.date)}`,
    b.variables['buyer_name'] ? `Buyer: ${b.variables['buyer_name']}` : '',
    `Amount: ${fmtMoney(b.totals.grandTotal, settings.currency)}`,
    ...(dt === 'invoice' ? [`Balance due: ${fmtMoney(due, settings.currency)} (${st})`] : []),
    upi ? `Pay via UPI: ${upi}` : '',
    'Thank you for your business!',
  ].filter(Boolean);
  const text = encodeURIComponent(lines.join('\n'));
  const digits = (b.variables['buyer_phone'] || '').replace(/\D/g, '');
  const phone = digits.length === 10 ? `91${digits}` : digits; // assume Indian local numbers
  return phone
    ? `https://wa.me/${phone}?text=${text}`
    : `https://wa.me/?text=${text}`;
}

function DocChip({ dt }: { dt: DocType }) {
  const meta = DOC_TYPE_META[dt];
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded border px-1.5 py-px font-mono text-[8px] font-bold uppercase tracking-wider ${meta.cls}`}
      title={meta.label}
    >
      {meta.short}
    </span>
  );
}

export default function HistoryView({ bills, templates, settings, onEdit, onDuplicate, onConvert, onRepeat, onDeleted, onUpdated, onPrint, onPrintReceipt, onNewBill }: Props) {
  const { toast } = useToast();
  const [q, setQ] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | BillStatus>('all');
  const [docFilter, setDocFilter] = useState<'all' | DocType>('all');
  const [viewing, setViewing] = useState<Bill | null>(null);
  const [deleting, setDeleting] = useState<Bill | null>(null);
  const [copies, setCopies] = useState(1);
  const [busyId, setBusyId] = useState<string | null>(null);
  /** bill currently generating a server-side PDF */
  const [pdfBusyId, setPdfBusyId] = useState<string | null>(null);
  const [payFor, setPayFor] = useState<Bill | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payDate, setPayDate] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('UPI');
  const [payRef, setPayRef] = useState('');
  /** id of the payment being edited (null while recording a new one) */
  const [editingPayId, setEditingPayId] = useState<string | null>(null);

  /* ---------- bulk selection ---------- */
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkConfirm, setBulkConfirm] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);

  const viewingTemplate0 = viewing ? templates.find((t) => t.id === viewing.templateId) : null;
  const [viewFitRef, viewFitScale] = useFitScale(viewingTemplate0?.page.width ?? 210, 24, 1);
  const pages = useMemo(
    () => (viewingTemplate0 ? paginateTemplate(viewingTemplate0, viewing?.items.length ?? 0).length : 1),
    [viewingTemplate0, viewing],
  );

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return bills.filter((b) => {
      if (from && b.date < from) return false;
      if (to && b.date > to) return false;
      if (statusFilter !== 'all' && billStatus(b) !== statusFilter) return false;
      if (docFilter !== 'all' && docTypeOf(b) !== docFilter) return false;
      if (!needle) return true;
      const hay = [
        b.billNo,
        b.variables['buyer_name'] ?? '',
        b.variables['buyer_gst'] ?? '',
        b.templateName,
        String(b.totals.grandTotal),
      ].join(' ').toLowerCase();
      return hay.includes(needle);
    });
  }, [bills, q, from, to, statusFilter, docFilter]);

  const live = filtered.filter((b) => billStatus(b) !== 'cancelled' && docTypeOf(b) === 'invoice');
  const totalAmount = live.reduce((s, b) => s + b.totals.grandTotal, 0);
  const collected = live.reduce((s, b) => s + paidAmount(b), 0);
  const outstanding = live.reduce((s, b) => s + dueAmount(b), 0);

  const openPayDialog = (b: Bill, p?: BillPayment) => {
    setPayFor(b);
    setEditingPayId(p?.id ?? null);
    setPayAmount(p ? String(p.amount) : String(dueAmount(b) || b.totals.grandTotal));
    setPayDate(p?.date ?? new Date().toISOString().slice(0, 10));
    setPayMethod(p?.method ?? 'UPI');
    setPayRef(p?.reference ?? '');
  };

  /** record a new payment OR apply edits to an existing receipt (full or partial) */
  const recordPayment = async () => {
    if (!payFor) return;
    const amt = Number(payAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({ title: 'Enter a valid amount', variant: 'destructive' });
      return;
    }
    setBusyId(payFor.id);
    try {
      const receipt: BillPayment = {
        id: editingPayId ?? uid('pay'),
        date: payDate || new Date().toISOString().slice(0, 10),
        amount: Math.round(amt * 100) / 100,
        method: payMethod,
        reference: payRef.trim() || undefined,
      };
      const payments = editingPayId
        ? (payFor.payments ?? []).map((p) => (p.id === editingPayId ? receipt : p))
        : [...(payFor.payments ?? []), receipt];
      const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
      const fullyPaid = totalPaid >= payFor.totals.grandTotal - 0.01;
      const res = await fetch(`/api/bills/${payFor.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payFor,
          payments,
          status: fullyPaid ? 'paid' : 'unpaid',
          paidAt: fullyPaid ? (payFor.paidAt ?? new Date().toISOString()) : null,
        }),
      });
      if (!res.ok) throw new Error();
      const updated = (await res.json()) as Bill;
      if (viewing?.id === updated.id) setViewing(updated);
      onUpdated(updated);
      toast({
        title: editingPayId ? 'Receipt updated' : fullyPaid ? `${payFor.billNo} fully paid` : `Payment recorded — ${payFor.billNo}`,
        description: `${fmtMoney(receipt.amount, settings.currency)} via ${receipt.method}${
          fullyPaid ? '' : ` · balance ${fmtMoney(dueAmount(updated), settings.currency)}`
        }`,
      });
      setPayFor(null);
      setEditingPayId(null);
    } catch {
      toast({ title: 'Could not save payment', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  /** remove a receipt — the payment status is recomputed from the remaining receipts */
  const deletePayment = async (b: Bill, payId: string) => {
    const p = (b.payments ?? []).find((x) => x.id === payId);
    setBusyId(b.id);
    try {
      const payments = (b.payments ?? []).filter((x) => x.id !== payId);
      const totalPaid = payments.reduce((s, x) => s + x.amount, 0);
      const fullyPaid = payments.length > 0 && totalPaid >= b.totals.grandTotal - 0.01;
      const res = await fetch(`/api/bills/${b.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...b,
          payments,
          status: fullyPaid ? 'paid' : 'unpaid',
          paidAt: fullyPaid ? b.paidAt ?? new Date().toISOString() : null,
        }),
      });
      if (!res.ok) throw new Error();
      const updated = (await res.json()) as Bill;
      if (viewing?.id === updated.id) setViewing(updated);
      onUpdated(updated);
      toast({
        title: 'Receipt deleted',
        description: `${fmtMoney(p?.amount ?? 0, settings.currency)} removed — bill is ${fullyPaid ? 'still fully paid' : 'unpaid'}${
          dueAmount(updated) > 0 ? ` (${fmtMoney(dueAmount(updated), settings.currency)} due)` : ''
        }`,
      });
    } catch {
      toast({ title: 'Could not delete receipt', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  /** print an official receipt for one recorded payment */
  const printReceipt = (b: Bill, p: BillPayment) => {
    const idx = (b.payments ?? []).findIndex((x) => x.id === p.id);
    onPrintReceipt({ bill: b, payment: p, receiptNo: `RCP-${b.billNo}-${String(idx + 1).padStart(2, '0')}` });
  };

  /** revert a paid bill back to unpaid (clears the paid flag, keeps receipts for records) */
  const markUnpaid = async (b: Bill) => {
    setBusyId(b.id);
    try {
      const res = await fetch(`/api/bills/${b.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...b, status: 'unpaid', paidAt: null }),
      });
      if (!res.ok) throw new Error();
      const updated = (await res.json()) as Bill;
      if (viewing?.id === b.id) setViewing(updated);
      onUpdated(updated);
      toast({ title: `${b.billNo} marked unpaid` });
    } catch {
      toast({ title: 'Could not update status', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const cycleStatus = (b: Bill) => {
    const st = billStatus(b);
    if (st === 'paid') markUnpaid(b);
    else if (st === 'cancelled') markUnpaid(b);
    else openPayDialog(b);
  };

  const reprint = (b: Bill) => {
    const tpl = templates.find((t) => t.id === b.templateId);
    if (!tpl) {
      toast({ title: 'Template missing', description: 'The template used for this bill no longer exists.', variant: 'destructive' });
      return;
    }
    onPrint(tpl, b, copies);
  };

  /** server-side PDF export of the designed document (exact page size, QR + barcode included) */
  const exportBillPdf = async (b: Bill, n = 1) => {
    setPdfBusyId(b.id);
    try {
      await downloadPdf({ kind: 'bill', billId: b.id, copies: n }, `${b.billNo}.pdf`);
      toast({ title: `PDF downloaded — ${b.billNo}`, description: n > 1 ? `${n} copies in one file` : 'Exact page size, ready to print or share.' });
    } catch (e) {
      toast({ title: 'PDF export failed', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setPdfBusyId(null);
    }
  };

  /** server-side PDF export of one payment receipt */
  const exportReceiptPdf = async (b: Bill, p: BillPayment) => {
    const idx = (b.payments ?? []).findIndex((x) => x.id === p.id);
    const receiptNo = `RCP-${b.billNo}-${String(idx + 1).padStart(2, '0')}`;
    setPdfBusyId(p.id);
    try {
      await downloadPdf({ kind: 'receipt', billId: b.id, paymentId: p.id, receiptNo }, `${receiptNo}.pdf`);
      toast({ title: `Receipt PDF downloaded`, description: receiptNo });
    } catch (e) {
      toast({ title: 'PDF export failed', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setPdfBusyId(null);
    }
  };

  /** one-shot skip of the next recurring occurrence (or undo it) */
  const toggleSkipNext = async (b: Bill) => {
    const next = !repeatSkipped(b);
    setBusyId(b.id);
    try {
      const res = await fetch(`/api/bills/${b.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...b, repeatSkipNext: next }),
      });
      if (!res.ok) throw new Error();
      const updated = (await res.json()) as Bill;
      if (viewing?.id === updated.id) setViewing(updated);
      onUpdated(updated);
      const cad = REPEAT_META[repeatOf(b) as 'weekly' | 'monthly' | 'yearly'];
      toast({
        title: next ? `Next ${cad.step} skipped — ${b.billNo}` : `Skip removed — ${b.billNo}`,
        description: next
          ? `The cadence rolls forward one ${cad.step}; no copy is created for ${fmtDate(nextRepeatDate(b))}.`
          : 'The next occurrence will be created as usual.',
      });
    } catch {
      toast({ title: 'Could not update the recurring flag', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const doDelete = async () => {
    if (!deleting) return;
    const res = await fetch(`/api/bills/${deleting.id}`, { method: 'DELETE' });
    if (res.ok) {
      onDeleted(deleting.id);
      toast({ title: 'Bill deleted', description: `${deleting.billNo} removed from history.` });
    } else {
      toast({ title: 'Delete failed', variant: 'destructive' });
    }
    setDeleting(null);
  };

  const exportUrl = `/api/bills/export?${new URLSearchParams({
    ...(from ? { from } : {}),
    ...(to ? { to } : {}),
  }).toString()}`;

  /* ---------- bulk actions ---------- */

  /** selection restricted to bills currently visible under the active filters */
  const bulkTargets = useMemo(() => filtered.filter((b) => selected.has(b.id)), [filtered, selected]);
  const bulkInvoices = bulkTargets.filter((b) => docTypeOf(b) === 'invoice');
  const bulkUnpaid = bulkInvoices.filter((b) => billStatus(b) !== 'paid');
  const bulkPaid = bulkInvoices.filter((b) => billStatus(b) === 'paid' || billStatus(b) === 'cancelled');
  const bulkAmount = bulkTargets.reduce((s, b) => s + b.totals.grandTotal, 0);
  const allVisibleSelected = filtered.length > 0 && filtered.every((b) => selected.has(b.id));

  const toggleAll = () => {
    setSelected((cur) => {
      const next = new Set(cur);
      if (allVisibleSelected) filtered.forEach((b) => next.delete(b.id));
      else filtered.forEach((b) => next.add(b.id));
      return next;
    });
  };

  const toggleOne = (id: string) => {
    setSelected((cur) => {
      const next = new Set(cur);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const bulkSetStatus = async (target: 'paid' | 'unpaid') => {
    const targets = target === 'paid' ? bulkUnpaid : bulkPaid;
    if (targets.length === 0) return;
    setBulkBusy(true);
    let ok = 0;
    try {
      await Promise.all(
        targets.map(async (b) => {
          const res = await fetch(`/api/bills/${b.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...b,
              status: target,
              paidAt: target === 'paid' ? b.paidAt ?? new Date().toISOString() : null,
            }),
          });
          if (res.ok) {
            ok += 1;
            onUpdated((await res.json()) as Bill);
          }
        }),
      );
      toast({ title: `${ok} bill${ok === 1 ? '' : 's'} marked ${target}` });
    } catch {
      toast({ title: 'Bulk update failed', variant: 'destructive' });
    } finally {
      setBulkBusy(false);
    }
  };

  const bulkDelete = async () => {
    if (bulkTargets.length === 0) return;
    setBulkBusy(true);
    const ids = bulkTargets.map((b) => b.id);
    const nos = bulkTargets.map((b) => b.billNo);
    try {
      await Promise.all(ids.map((id) => fetch(`/api/bills/${id}`, { method: 'DELETE' })));
      ids.forEach(onDeleted);
      setSelected(new Set());
      toast({ title: `${ids.length} bill${ids.length === 1 ? '' : 's'} deleted`, description: nos.slice(0, 6).join(', ') + (nos.length > 6 ? '…' : '') });
    } catch {
      toast({ title: 'Bulk delete failed', variant: 'destructive' });
    } finally {
      setBulkBusy(false);
      setBulkConfirm(false);
    }
  };

  const exportSelected = () => {
    if (bulkTargets.length === 0) return;
    const url = `/api/bills/export?ids=${encodeURIComponent(bulkTargets.map((b) => b.id).join(','))}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* filters */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#232b38] bg-[#0f1319] px-4 py-2.5">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-600" />
          <Input
            className="h-8 w-56 border-[#2a3342] bg-[#0d1117] pl-8 text-xs"
            placeholder="Search bill no, buyer, GST…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          {q && (
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-300" onClick={() => setQ('')}>
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
        <Input type="date" className="h-8 w-36 border-[#2a3342] bg-[#0d1117] text-xs" value={from} onChange={(e) => setFrom(e.target.value)} />
        <span className="text-xs text-zinc-600">to</span>
        <Input type="date" className="h-8 w-36 border-[#2a3342] bg-[#0d1117] text-xs" value={to} onChange={(e) => setTo(e.target.value)} />
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as 'all' | BillStatus)}>
          <SelectTrigger className="h-8 w-32 border-[#2a3342] bg-[#0d1117] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
            <SelectItem value="all" className="text-xs">All statuses</SelectItem>
            <SelectItem value="unpaid" className="text-xs">Unpaid</SelectItem>
            <SelectItem value="paid" className="text-xs">Paid</SelectItem>
            <SelectItem value="cancelled" className="text-xs">Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <Select value={docFilter} onValueChange={(v) => setDocFilter(v as 'all' | DocType)}>
          <SelectTrigger className="h-8 w-36 border-[#2a3342] bg-[#0d1117] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
            <SelectItem value="all" className="text-xs">All doc types</SelectItem>
            <SelectItem value="invoice" className="text-xs">Invoices</SelectItem>
            <SelectItem value="proforma" className="text-xs">Proforma</SelectItem>
            <SelectItem value="quotation" className="text-xs">Quotations</SelectItem>
            <SelectItem value="challan" className="text-xs">Delivery Challans</SelectItem>
            <SelectItem value="creditnote" className="text-xs">Credit Notes</SelectItem>
          </SelectContent>
        </Select>
        {(from || to || statusFilter !== 'all' || docFilter !== 'all') && (
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-zinc-400" onClick={() => { setFrom(''); setTo(''); setStatusFilter('all'); setDocFilter('all'); }}>
            Clear filters
          </Button>
        )}
        <div className="ml-auto flex items-center gap-3">
          <span className="tabular hidden items-center gap-1 text-[11px] text-emerald-300 md:flex">
            <CircleDollarSign className="h-3.5 w-3.5" /> {fmtMoney(collected, settings.currency)} collected
          </span>
          <span className="tabular hidden items-center gap-1 text-[11px] text-amber-300 md:flex">
            <BadgeCheck className="h-3.5 w-3.5" /> {fmtMoney(outstanding, settings.currency)} outstanding
          </span>
          <span className="tabular text-xs text-zinc-500">
            {filtered.length} bills · <span className="font-semibold text-[#d9a13b]">{fmtMoney(totalAmount, settings.currency)}</span>
          </span>
          <a href={exportUrl} download>
            <Button variant="outline" size="sm" className="h-8 gap-1.5 border-[#2a3342] text-xs">
              <Download className="h-3.5 w-3.5" /> Export CSV
            </Button>
          </a>
        </div>
      </div>

      {/* table */}
      <div className="studio-scroll flex-1 overflow-auto p-4">
        <div className="overflow-hidden rounded-lg border border-[#232b38]">
          <table className="w-full min-w-[960px] text-sm">
            <thead>
              <tr className="sticky top-0 z-10 border-b border-[#232b38] bg-[#12161d] text-left text-[10px] uppercase tracking-wider text-zinc-500 shadow-[0_1px_0_rgba(217,161,59,0.25)]">
                <th className="w-9 px-3 py-2.5">
                  <input
                    type="checkbox"
                    className="h-3.5 w-3.5 cursor-pointer accent-[#d9a13b]"
                    checked={allVisibleSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = !allVisibleSelected && bulkTargets.length > 0;
                    }}
                    onChange={toggleAll}
                    title="Select all filtered bills"
                    aria-label="Select all filtered bills"
                  />
                </th>
                <th className="px-4 py-2.5 font-medium">Bill No</th>
                <th className="px-4 py-2.5 font-medium">Date</th>
                <th className="px-4 py-2.5 font-medium">Buyer</th>
                <th className="px-4 py-2.5 text-center font-medium">Items</th>
                <th className="px-4 py-2.5 text-center font-medium">Status</th>
                <th className="px-4 py-2.5 text-right font-medium">Grand Total</th>
                <th className="px-4 py-2.5 text-right font-medium">Balance</th>
                <th className="px-4 py-2.5 font-medium">Template</th>
                <th className="px-4 py-2.5 text-center font-medium">Prints</th>
                <th className="px-4 py-2.5 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && bills.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-4 py-14 text-center">
                    <div className="mx-auto flex max-w-sm flex-col items-center gap-2.5">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#2a3342] bg-[#0f1319]">
                        <ReceiptText className="h-5 w-5 text-[#d9a13b]/70" />
                      </span>
                      <p className="text-sm font-medium text-zinc-300">No bills yet</p>
                      <p className="text-xs leading-relaxed text-zinc-600">
                        Every bill you create or print lands here — with payments, prints and one-tap reprints.
                      </p>
                      {onNewBill && (
                        <Button
                          size="sm"
                          className="mt-1 h-8 gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]"
                          onClick={onNewBill}
                        >
                          <ReceiptText className="h-3.5 w-3.5" /> Create your first bill
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
              {filtered.length === 0 && bills.length > 0 && (
                <tr>
                  <td colSpan={11} className="px-4 py-14 text-center">
                    <div className="mx-auto flex max-w-sm flex-col items-center gap-2.5">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#2a3342] bg-[#0f1319]">
                        <Search className="h-5 w-5 text-zinc-600" />
                      </span>
                      <p className="text-sm font-medium text-zinc-300">No bills match your filters</p>
                      <p className="text-xs text-zinc-600">Try a different search term, date range or status.</p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 gap-1.5 border-[#2a3342] text-xs"
                        onClick={() => { setQ(''); setFrom(''); setTo(''); setStatusFilter('all'); setDocFilter('all'); }}
                      >
                        <X className="h-3 w-3" /> Clear all filters
                      </Button>
                    </div>
                  </td>
                </tr>
              )}
              {filtered.map((b) => {
                const st = billStatus(b);
                const meta = STATUS_META[st];
                const dt = docTypeOf(b);
                const due = dueAmount(b);
                const paid = paidAmount(b);
                const partial = paid > 0 && due > 0;
                const isSel = selected.has(b.id);
                return (
                  <tr
                    key={b.id}
                    className={`border-b border-[#1a212c] transition-colors last:border-0 hover:bg-[#151b25] ${isSel ? 'bg-[#d9a13b]/[0.06]' : ''}`}
                  >
                    <td className="px-3 py-2.5">
                      <input
                        type="checkbox"
                        className="h-3.5 w-3.5 cursor-pointer accent-[#d9a13b]"
                        checked={isSel}
                        onChange={() => toggleOne(b.id)}
                        aria-label={`Select ${b.billNo}`}
                      />
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <DocChip dt={dt} />
                        <span className="font-mono text-xs font-semibold text-[#e8c064]">{b.billNo}</span>
                        {repeatOf(b) !== 'none' && (() => {
                          const cad = REPEAT_META[repeatOf(b) as 'weekly' | 'monthly' | 'yearly'];
                          const skip = repeatSkipped(b);
                          const end = repeatEnded(b);
                          return (
                            <span
                              className={`inline-flex shrink-0 items-center gap-0.5 rounded border px-1 py-px text-[8px] font-bold uppercase tracking-wider ${
                                end
                                  ? 'border-zinc-600/40 bg-zinc-600/10 text-zinc-500 line-through'
                                  : skip
                                    ? 'border-sky-500/40 bg-sky-500/10 text-sky-300'
                                    : 'border-[#d9a13b]/40 bg-[#d9a13b]/10 text-[#e8b954]'
                              }`}
                              title={
                                end
                                  ? `Recurring ${cad.label.toLowerCase()} — chain ended (past ${fmtDate(b.repeatEndDate!)})`
                                  : `Recurring ${cad.label.toLowerCase()} — next occurrence ${fmtDate(nextRepeatDate(b))}${
                                      b.repeatEndDate ? ` · until ${fmtDate(b.repeatEndDate)}` : ''
                                    }${skip ? ' · next one will be skipped' : ''}`
                              }
                            >
                              {skip ? <CalendarX2 className="h-2.5 w-2.5" /> : <CalendarSync className="h-2.5 w-2.5" />} {cad.short}
                            </span>
                          );
                        })()}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-zinc-400">{fmtDate(b.date)}</td>
                    <td className="px-4 py-2.5">
                      <div className="text-sm text-zinc-200">{b.variables['buyer_name'] || '—'}</div>
                      <div className="text-[10px] text-zinc-600">{b.variables['buyer_gst'] || ''}</div>
                    </td>
                    <td className="tabular px-4 py-2.5 text-center text-xs text-zinc-400">{b.items.length}</td>
                    <td className="px-4 py-2.5 text-center">
                      {dt === 'invoice' ? (
                        <button
                          type="button"
                          disabled={busyId === b.id}
                          title={
                            st === 'paid'
                              ? 'Click to mark unpaid'
                              : st === 'cancelled'
                                ? 'Click to restore to unpaid'
                                : paid > 0
                                  ? `Partially paid — ${fmtMoney(paid, settings.currency)} received. Click to record more.`
                                  : 'Click to record a payment'
                          }
                          onClick={() => cycleStatus(b)}
                          className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider transition-opacity hover:opacity-75 disabled:opacity-40 ${meta.cls}`}
                        >
                          <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} /> {meta.label}
                        </button>
                      ) : (
                        <span className="text-[9px] uppercase tracking-wider text-zinc-600">—</span>
                      )}
                    </td>
                    <td className="tabular px-4 py-2.5 text-right font-semibold text-zinc-100">
                      {fmtMoney(b.totals.grandTotal, settings.currency)}
                    </td>
                    <td className={`tabular px-4 py-2.5 text-right text-xs font-semibold ${due > 0 ? 'text-amber-300' : 'text-emerald-400'}`}>
                      {dt === 'invoice' ? fmtMoney(due, settings.currency) : '—'}
                      {partial && (
                        <div className="text-[9px] font-normal text-zinc-600">{fmtMoney(paid, settings.currency)} paid</div>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-zinc-500">{b.templateName}</td>
                    <td className="tabular px-4 py-2.5 text-center text-xs text-zinc-400">{b.printCount}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center justify-end gap-0.5">
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="View" onClick={() => setViewing(b)}>
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="Print" onClick={() => reprint(b)}>
                          <Printer className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-sky-300/80 hover:text-sky-200"
                          title="Download PDF — exact page size with QR & barcodes, no print dialog"
                          disabled={pdfBusyId === b.id}
                          onClick={() => exportBillPdf(b)}
                        >
                          <FileDown className={`h-3.5 w-3.5 ${pdfBusyId === b.id ? 'animate-pulse' : ''}`} />
                        </Button>
                        {dt === 'invoice' && due > 0 && st !== 'cancelled' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-emerald-400/80 hover:text-emerald-300"
                            title="Record payment"
                            onClick={() => openPayDialog(b)}
                          >
                            <HandCoins className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        {dt !== 'invoice' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-sky-300/80 hover:text-sky-200"
                            title="Convert to Tax Invoice — carries buyer, items & totals; gets the next invoice number"
                            onClick={() => onConvert(b)}
                          >
                            <ArrowRightLeft className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        {dt === 'invoice' && (() => {
                          const cad = repeatOf(b) !== 'none' ? REPEAT_META[repeatOf(b) as 'weekly' | 'monthly' | 'yearly'] : null;
                          const skip = repeatSkipped(b);
                          return (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-[#e8b954]/80 hover:text-[#e8b954]"
                                title={cad ? `Repeat next ${cad.step} — opens a fresh copy of this invoice with the next bill number` : 'Repeat — opens a fresh copy of this invoice with the next bill number'}
                                onClick={() => onRepeat(b)}
                              >
                                <CalendarSync className="h-3.5 w-3.5" />
                              </Button>
                              {cad && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className={`h-7 w-7 ${skip ? 'text-sky-300 hover:text-sky-200' : 'text-zinc-600 hover:text-sky-300'}`}
                                  title={skip ? 'Undo skip — the next occurrence will be created as usual' : `Skip next occurrence (${fmtDate(nextRepeatDate(b))}) — rolls the cadence forward without creating a copy`}
                                  disabled={busyId === b.id}
                                  onClick={() => toggleSkipNext(b)}
                                >
                                  {skip ? <CalendarCheck2 className="h-3.5 w-3.5" /> : <CalendarX2 className="h-3.5 w-3.5" />}
                                </Button>
                              )}
                            </>
                          );
                        })()}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-emerald-400/80 hover:text-emerald-300"
                          title="Share on WhatsApp — prefilled bill summary with a UPI pay link"
                          onClick={() => window.open(whatsappUrl(b, settings), '_blank', 'noopener')}
                        >
                          <MessageCircle className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="Edit" onClick={() => onEdit(b)}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="Duplicate" onClick={() => onDuplicate(b)}>
                          <Copy className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-red-400" title="Delete" onClick={() => setDeleting(b)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ---------- bulk selection bar ---------- */}
      {bulkTargets.length > 0 && (
        <div className="pointer-events-none sticky bottom-3 z-20 flex justify-center px-4">
          <div className="pointer-events-auto flex flex-wrap items-center gap-2 rounded-lg border border-[#d9a13b]/40 bg-[#12161d]/97 py-2 pl-4 pr-2 shadow-[0_10px_36px_rgba(0,0,0,0.6)] backdrop-blur studio-rise">
            <span className="flex items-center gap-2 text-xs">
              <ListChecks className="h-4 w-4 text-[#d9a13b]" />
              <span className="font-semibold text-[#e8c064]">{bulkTargets.length} selected</span>
              <span className="tabular text-zinc-500">· {fmtMoney(bulkAmount, settings.currency)}</span>
            </span>
            <span className="mx-1 h-5 w-px bg-[#2a3342]" />
            {bulkUnpaid.length > 0 && (
              <Button
                size="sm"
                className="h-8 gap-1.5 bg-emerald-500/90 text-xs font-semibold text-black hover:bg-emerald-400"
                disabled={bulkBusy}
                onClick={() => bulkSetStatus('paid')}
              >
                <BadgeCheck className="h-3.5 w-3.5" /> Mark paid ({bulkUnpaid.length})
              </Button>
            )}
            {bulkPaid.length > 0 && (
              <Button
                size="sm"
                variant="outline"
                className="h-8 gap-1.5 border-[#2a3342] text-xs text-amber-300 hover:bg-[#d9a13b]/10"
                disabled={bulkBusy}
                onClick={() => bulkSetStatus('unpaid')}
              >
                <BadgeCheck className="h-3.5 w-3.5" /> Mark unpaid ({bulkPaid.length})
              </Button>
            )}
            <Button
              size="sm"
              variant="outline"
              className="h-8 gap-1.5 border-[#2a3342] text-xs"
              disabled={bulkBusy}
              onClick={exportSelected}
            >
              <Download className="h-3.5 w-3.5" /> Export {bulkTargets.length}
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-8 gap-1.5 border-red-500/30 text-xs text-red-300 hover:bg-red-500/10"
              disabled={bulkBusy}
              onClick={() => setBulkConfirm(true)}
            >
              <Trash2 className="h-3.5 w-3.5" /> Delete
            </Button>
            <Button size="sm" variant="ghost" className="h-8 px-2 text-xs text-zinc-500" onClick={() => setSelected(new Set())}>
              <X className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      )}

      {/* bulk delete confirm */}
      <AlertDialog open={bulkConfirm} onOpenChange={setBulkConfirm}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-sm">Delete {bulkTargets.length} selected bill{bulkTargets.length === 1 ? '' : 's'}?</AlertDialogTitle>
            <AlertDialogDescription className="text-xs leading-relaxed">
              This permanently removes them from history:
              <span className="mt-1.5 block font-mono text-[11px] text-amber-300/90">
                {bulkTargets.map((b) => b.billNo).slice(0, 8).join(', ')}
                {bulkTargets.length > 8 ? ` +${bulkTargets.length - 8} more` : ''}
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-8 border-[#2a3342] bg-transparent text-xs hover:bg-[#171d27] hover:text-zinc-200">Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="h-8 bg-red-500/90 text-xs font-semibold text-white hover:bg-red-500"
              onClick={(e) => {
                e.preventDefault();
                bulkDelete();
              }}
            >
              Delete {bulkTargets.length}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* view dialog */}
      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent
          showCloseButton={false}
          className="h-[94vh] max-h-[94vh] w-[95vw] sm:max-w-5xl md:max-w-6xl lg:max-w-7xl border-[#2a3342] bg-[#12161d] p-0 text-zinc-200 flex flex-col overflow-hidden shadow-2xl"
        >
          {/* Header */}
          <div className="border-b border-[#232b38] bg-[#12161d] px-5 py-3 shrink-0">
            {/* Top row: Title, DocChip, Bill No, Buyer, Status & Close */}
            <div className="flex items-center justify-between gap-3 mb-2.5">
              <div className="flex min-w-0 items-center gap-2 flex-wrap">
                {viewing && <DocChip dt={docTypeOf(viewing)} />}
                <span className="font-mono font-bold text-sm text-[#e8c064]">{viewing?.billNo}</span>
                <span className="text-zinc-400 font-medium text-xs truncate max-w-[320px]">
                  {viewing?.variables['buyer_name']}
                </span>
                {viewing && docTypeOf(viewing) === 'invoice' && (() => {
                  const meta = STATUS_META[billStatus(viewing)];
                  return (
                    <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider ${meta.cls}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} /> {meta.label}
                    </span>
                  );
                })()}
                {viewing && docTypeOf(viewing) === 'creditnote' && viewing.variables['ref_invoice_no'] && (
                  <span
                    className="inline-flex shrink-0 items-center gap-1 rounded border border-rose-500/40 bg-rose-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold text-rose-300"
                    title="Credit note issued against this invoice"
                  >
                    <ArrowRightLeft className="h-2.5 w-2.5" /> against {viewing.variables['ref_invoice_no']}
                  </span>
                )}
              </div>

              {/* Dedicated Close Button */}
              <button
                type="button"
                onClick={() => setViewing(null)}
                className="h-7 w-7 rounded border border-[#2a3342] bg-[#181f2a] flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#232b38] transition-colors shrink-0"
                title="Close preview (Esc)"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Bottom row: Action buttons toolbar */}
            <div className="flex items-center justify-between gap-2 flex-wrap pt-2 border-t border-[#1a212c]">
              <div className="flex items-center gap-2 flex-wrap">
                {viewing && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-sky-500/40 text-xs text-sky-300 hover:bg-sky-500/10"
                    title="Download PDF — exact page size with QR & barcodes, no print dialog"
                    disabled={pdfBusyId === viewing.id}
                    onClick={() => exportBillPdf(viewing, copies)}
                  >
                    <FileDown className={`h-3.5 w-3.5 ${pdfBusyId === viewing.id ? 'animate-pulse' : ''}`} /> PDF
                  </Button>
                )}
                {viewing && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-emerald-500/40 text-xs text-emerald-300 hover:bg-emerald-500/10"
                    title="Share on WhatsApp — prefilled bill summary with a UPI pay link"
                    onClick={() => window.open(whatsappUrl(viewing, settings), '_blank', 'noopener')}
                  >
                    <Share2 className="h-3.5 w-3.5" /> WhatsApp
                  </Button>
                )}
                {viewing && docTypeOf(viewing) === 'invoice' && dueAmount(viewing) > 0 && billStatus(viewing) !== 'cancelled' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-emerald-500/40 text-xs text-emerald-300 hover:bg-emerald-500/10"
                    disabled={busyId === viewing.id}
                    onClick={() => openPayDialog(viewing)}
                  >
                    <HandCoins className="h-3.5 w-3.5" />
                    {paidAmount(viewing) > 0 ? 'Record more' : 'Record payment'}
                  </Button>
                )}
                {viewing && docTypeOf(viewing) === 'invoice' && billStatus(viewing) === 'paid' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-[#2a3342] text-xs text-zinc-400 hover:bg-[#1a212c]"
                    disabled={busyId === viewing.id}
                    onClick={() => markUnpaid(viewing)}
                  >
                    Mark unpaid
                  </Button>
                )}
                {viewing && docTypeOf(viewing) === 'invoice' && billStatus(viewing) !== 'cancelled' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-red-500/40 text-xs text-red-300 hover:bg-red-500/10"
                    disabled={busyId === viewing.id}
                    onClick={async () => {
                      if (!viewing) return;
                      setBusyId(viewing.id);
                      try {
                        const res = await fetch(`/api/bills/${viewing.id}`, {
                          method: 'PUT',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ ...viewing, status: 'cancelled' }),
                        });
                        if (!res.ok) throw new Error();
                        const updated = (await res.json()) as Bill;
                        setViewing(updated);
                        onUpdated(updated);
                        toast({ title: `${viewing.billNo} cancelled`, description: 'Excluded from revenue, GST and collection stats.' });
                      } catch {
                        toast({ title: 'Could not cancel bill', variant: 'destructive' });
                      } finally {
                        setBusyId(null);
                      }
                    }}
                  >
                    <X className="h-3.5 w-3.5" /> Cancel bill
                  </Button>
                )}
                {viewing && docTypeOf(viewing) !== 'invoice' && (
                  <Button
                    size="sm"
                    className="h-7 gap-1.5 bg-sky-600 text-xs font-semibold text-white hover:bg-sky-500"
                    onClick={() => onConvert(viewing)}
                  >
                    <ArrowRightLeft className="h-3.5 w-3.5" /> Convert to invoice
                  </Button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <Select value={String(copies)} onValueChange={(v) => setCopies(Number(v))}>
                  <SelectTrigger className="h-7 w-24 border-[#2a3342] bg-[#0d1117] text-[11px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {[1, 2, 3].map((n) => (
                      <SelectItem key={n} value={String(n)} className="text-xs">{n} cop{n > 1 ? 'ies' : 'y'}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  className="h-7 gap-1.5 bg-[#d9a13b] text-xs font-semibold text-black hover:bg-[#e5b055]"
                  onClick={() => viewing && reprint(viewing)}
                >
                  <Printer className="h-3.5 w-3.5" /> Print
                </Button>
              </div>
            </div>
          </div>
          <div ref={viewFitRef} className="studio-scroll flex-1 overflow-auto bg-[#0d1015] p-6 sm:p-8">
            {viewing && repeatOf(viewing) !== 'none' && viewing.id && (
              <div className="mx-auto mb-4 flex max-w-xl flex-wrap items-center justify-center gap-2 rounded-md border border-[#d9a13b]/25 bg-[#d9a13b]/[0.06] px-3 py-1.5 text-[10px] text-[#e8b954]">
                <CalendarSync className="h-3 w-3" />
                <span>
                  Repeats {REPEAT_META[repeatOf(viewing) as 'weekly' | 'monthly' | 'yearly'].label.toLowerCase()} —
                  next {fmtDate(nextRepeatDate(viewing))}
                  {viewing.repeatEndDate ? ` · until ${fmtDate(viewing.repeatEndDate)}` : ''}
                </span>
                {repeatEnded(viewing) ? (
                  <span className="rounded border border-zinc-600/40 px-1 py-px text-[8px] font-bold uppercase tracking-wider text-zinc-500">chain ended</span>
                ) : repeatSkipped(viewing) ? (
                  <span className="rounded border border-sky-500/40 bg-sky-500/10 px-1 py-px text-[8px] font-bold uppercase tracking-wider text-sky-300">next skipped</span>
                ) : (
                  <button
                    type="button"
                    className="rounded border border-sky-500/30 px-1.5 py-px text-[8px] font-bold uppercase tracking-wider text-sky-300/90 transition-colors hover:bg-sky-500/10"
                    disabled={busyId === viewing.id}
                    onClick={() => toggleSkipNext(viewing)}
                  >
                    Skip next
                  </button>
                )}
              </div>
            )}
            {viewing && !viewingTemplate0 && (
              <div className="flex flex-col items-center gap-3 py-14 text-center">
                <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#2a3342] bg-[#0f1319]">
                  <Eye className="h-5 w-5 text-zinc-600" />
                </span>
                <p className="text-sm font-medium text-zinc-300">Preview unavailable</p>
                <p className="max-w-xs text-xs leading-relaxed text-zinc-600">
                  The template this document was printed with has been deleted. The stored figures below are intact —
                  use <span className="text-zinc-400">Convert to invoice</span> or <span className="text-zinc-400">Duplicate</span> to
                  re-issue it on a current template.
                </p>
                <div className="mt-1 grid w-full max-w-xs grid-cols-2 gap-2 text-left">
                  <div className="rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2">
                    <p className="text-[9px] uppercase tracking-wider text-zinc-600">Grand total</p>
                    <p className="tabular text-sm font-semibold text-zinc-200">{fmtMoney(viewing.totals.grandTotal, settings.currency)}</p>
                  </div>
                  <div className="rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2">
                    <p className="text-[9px] uppercase tracking-wider text-zinc-600">Items</p>
                    <p className="tabular text-sm font-semibold text-zinc-200">{viewing.items.length}</p>
                  </div>
                </div>
              </div>
            )}
            {viewing && viewingTemplate0 && (
              <div>
                <BillPreview
                  template={viewingTemplate0}
                  bill={viewing}
                  settings={settings}
                  scale={viewFitScale}
                  multiPage
                  showStatusStamp
                  className="mx-auto"
                />
                <p className="mt-3 text-center text-[10px] text-zinc-600">
                  {viewing.items.length > 0 && pages > 1 ? `${pages} pages` : 'Single page'}
                  <span className="ml-2 text-zinc-700">· “PDF” above exports this exact layout without the print dialog</span>
                </p>

                {/* payment ledger */}
                {docTypeOf(viewing) === 'invoice' && (
                  <div className="mx-auto mt-5 max-w-xl overflow-hidden rounded-lg border border-[#232b38] bg-[#0f1319]">
                    <div className="flex items-center justify-between border-b border-[#232b38] px-4 py-2">
                      <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Payment ledger</span>
                      <span className="tabular text-[10px]">
                        <span className="text-emerald-400">{fmtMoney(paidAmount(viewing), settings.currency)} paid</span>
                        <span className="mx-1.5 text-zinc-700">/</span>
                        <span className={dueAmount(viewing) > 0 ? 'text-amber-300' : 'text-zinc-500'}>
                          {fmtMoney(dueAmount(viewing), settings.currency)} due
                        </span>
                      </span>
                    </div>
                    {(viewing.payments?.length ?? 0) === 0 ? (
                      <p className="px-4 py-3 text-[11px] text-zinc-600">
                        No receipts recorded yet{billStatus(viewing) === 'paid' ? ' — legacy bill marked fully paid.' : '.'}
                      </p>
                    ) : (
                      <ul className="divide-y divide-[#1a212c]">
                        {viewing.payments!.map((p) => (
                          <li key={p.id} className="flex items-center gap-3 px-4 py-2 text-[11px]">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-400">
                              <CircleDollarSign className="h-3.5 w-3.5" />
                            </span>
                            <div className="min-w-0 flex-1">
                              <span className="font-semibold text-zinc-200">{p.method}</span>
                              {p.reference && <span className="ml-1.5 font-mono text-[10px] text-zinc-500">{p.reference}</span>}
                              <span className="ml-2 text-zinc-600">{fmtDate(p.date)}</span>
                            </div>
                            <span className="tabular font-semibold text-emerald-300">{fmtMoney(p.amount, settings.currency)}</span>
                            <div className="flex shrink-0 items-center gap-0.5">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                title="Print receipt"
                                onClick={() => printReceipt(viewing, p)}
                              >
                                <ReceiptText className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-sky-300/80 hover:text-sky-200"
                                title="Download receipt PDF"
                                disabled={pdfBusyId === p.id}
                                onClick={() => exportReceiptPdf(viewing, p)}
                              >
                                <FileDown className={`h-3 w-3 ${pdfBusyId === p.id ? 'animate-pulse' : ''}`} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-emerald-400/80 hover:text-emerald-300"
                                title="Share receipt on WhatsApp — confirmation with amount, method & balance"
                                onClick={() => {
                                  const idx = (viewing.payments ?? []).findIndex((x) => x.id === p.id);
                                  const no = `RCP-${viewing.billNo}-${String(idx + 1).padStart(2, '0')}`;
                                  window.open(receiptWhatsAppUrl(viewing, p, no, settings), '_blank', 'noopener');
                                }}
                              >
                                <MessageCircle className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                title="Edit receipt"
                                onClick={() => openPayDialog(viewing, p)}
                              >
                                <Pencil className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 hover:text-red-400"
                                title="Delete receipt — payment status is recomputed"
                                disabled={busyId === viewing.id}
                                onClick={() => deletePayment(viewing, p.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* record-payment dialog */}
      <Dialog open={!!payFor} onOpenChange={(o) => !o && setPayFor(null)}>
        <DialogContent className="max-w-md border-[#2a3342] bg-[#12161d] text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] pb-3">
            <DialogTitle className="flex items-center gap-2 text-sm">
              <HandCoins className="h-4 w-4 text-emerald-400" />
              {editingPayId ? 'Edit receipt' : 'Record payment'} — {payFor?.billNo}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Record a full or partial payment against this invoice.
            </DialogDescription>
          </DialogHeader>
          {payFor && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2 rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2 text-center">
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-zinc-600">Total</p>
                  <p className="tabular text-xs font-semibold text-zinc-200">{fmtMoney(payFor.totals.grandTotal, settings.currency)}</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-zinc-600">Received</p>
                  <p className="tabular text-xs font-semibold text-emerald-300">{fmtMoney(paidAmount(payFor), settings.currency)}</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-zinc-600">Balance</p>
                  <p className="tabular text-xs font-semibold text-amber-300">{fmtMoney(dueAmount(payFor), settings.currency)}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Amount received *</Label>
                  <Input
                    type="number"
                    min="0"
                    className="tabular mt-1 h-9 border-[#2a3342] bg-[#0d1117]"
                    value={payAmount}
                    onChange={(e) => setPayAmount(e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Date</Label>
                  <Input
                    type="date"
                    className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]"
                    value={payDate}
                    onChange={(e) => setPayDate(e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Method</Label>
                  <Select value={payMethod} onValueChange={(v) => setPayMethod(v as PaymentMethod)}>
                    <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                      {PAYMENT_METHODS.map((m) => (
                        <SelectItem key={m} value={m} className="text-xs">{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Reference (UPI / Txn / Cheque)</Label>
                  <Input
                    className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] font-mono text-sm"
                    placeholder="e.g. UPI 4392…"
                    value={payRef}
                    onChange={(e) => setPayRef(e.target.value)}
                  />
                </div>
              </div>
              <p className="text-[10px] text-zinc-600">
                Partial amounts are supported — the bill stays “partially paid” until the full total is received.
              </p>
            </div>
          )}
          <div className="flex items-center justify-end gap-2 border-t border-[#232b38] pt-3">
            <Button variant="outline" className="h-8 border-[#2a3342] text-xs" onClick={() => setPayFor(null)}>
              Cancel
            </Button>
            <Button
              className="h-8 gap-1.5 bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500"
              disabled={busyId === payFor?.id}
              onClick={recordPayment}
            >
              <HandCoins className="h-3.5 w-3.5" /> {editingPayId ? 'Save changes' : 'Save payment'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {deleting?.billNo}?</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              This permanently removes the bill from history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2a3342] bg-transparent text-zinc-300 hover:bg-[#1a212c]">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 text-white hover:bg-red-500" onClick={doDelete}>
              Delete bill
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

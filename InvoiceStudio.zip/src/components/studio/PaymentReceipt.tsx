/* ============================================================
 * InvoiceStudio — printable payment receipt (A5 portrait)
 * Rendered inside the PrintManager portal for receipt jobs and
 * by the server-side PDF export. Inline styles only — the print
 * document must not depend on any external stylesheet.
 * ============================================================ */
import type { CSSProperties } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import type { Bill, BillPayment, Settings } from '@/lib/studio/types';
import { amountInWords, dueAmount, fmtDate, fmtMoney, paidAmount } from '@/lib/studio/format';
import { isServerRender, qrSvg } from '@/lib/studio/qrsvg';

interface Props {
  bill: Bill;
  payment: BillPayment;
  receiptNo: string;
  settings: Settings;
}

/** QR payload for a receipt: a UPI pay link for the remaining balance,
 *  or (when fully settled) a scannable receipt-verification text. */
function receiptQrPayload(bill: Bill, settings: Settings, receiptNo: string): string {
  const biz = settings.business;
  const due = Math.max(0, bill.totals.grandTotal - paidAmount(bill));
  if (due > 0 && biz.upi) {
    const params = new URLSearchParams({
      pa: biz.upi,
      pn: biz.name || 'Merchant',
      am: due.toFixed(2),
      cu: 'INR',
      tn: `Balance ${bill.billNo}`,
    });
    return `upi://pay?${params.toString()}`;
  }
  return [
    `RECEIPT ${receiptNo}`,
    `Invoice ${bill.billNo}`,
    `Paid ${fmtMoney(paidAmount(bill), settings.currency)}`,
    biz.name,
  ].join(' | ');
}

/** tiny helper — keeps JSX terse while staying stylesheet-free */
const s = (o: CSSProperties): CSSProperties => o;

export default function PaymentReceipt({ bill, payment, receiptNo, settings }: Props) {
  const biz = settings.business;
  const cur = settings.currency;
  const buyer = bill.variables['buyer_name'] ?? '—';
  const due = Math.max(0, bill.totals.grandTotal - paidAmount(bill));
  const FONT = 'Arial, Helvetica, sans-serif';

  return (
    <div
      style={s({
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        background: '#ffffff',
        color: '#000000',
        width: '148mm',
        height: '209.6mm',
        fontFamily: FONT,
        padding: '10mm 11mm',
        boxSizing: 'border-box',
      })}
    >
      {/* gold top rule */}
      <div style={s({ position: 'absolute', left: 0, right: 0, top: 0, height: '2.5mm', background: 'linear-gradient(90deg,#b98a2b,#e7c268,#b98a2b)' })} />

      {/* header */}
      <div style={s({ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '3mm' })}>
        <div style={s({ minWidth: 0 })}>
          <p style={s({ margin: 0, fontSize: '13pt', fontWeight: 700, textTransform: 'uppercase', lineHeight: 1.2, letterSpacing: '0.4pt', color: '#1a1a1a', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' })}>
            {biz.name}
          </p>
          <p style={s({ margin: '0.6mm 0 0', whiteSpace: 'pre-line', fontSize: '7pt', lineHeight: 1.35, color: '#333' })}>{biz.address}</p>
          <p style={s({ margin: '0.6mm 0 0', fontSize: '7pt', color: '#333' })}>
            {biz.phone ? <>Ph: {biz.phone} · </> : null}
            {biz.email}
          </p>
          {biz.gstin ? <p style={s({ margin: 0, fontSize: '7pt', fontWeight: 700, color: '#333' })}>GSTIN: {biz.gstin}</p> : null}
        </div>
        {biz.logo ? (
          <img src={biz.logo} alt="logo" style={s({ height: '16mm', width: '16mm', flexShrink: 0, objectFit: 'contain' })} />
        ) : null}
      </div>

      {/* title band */}
      <div style={s({ marginTop: '5mm', borderTop: '0.6mm solid #000', borderBottom: '0.6mm solid #000', padding: '1.8mm 0', textAlign: 'center' })}>
        <p style={s({ margin: 0, fontSize: '12.5pt', fontWeight: 700, letterSpacing: '0.28em', color: '#8a6a24' })}>
          PAYMENT RECEIPT
        </p>
      </div>

      {/* meta */}
      <div style={s({ marginTop: '3mm', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', fontSize: '8pt' })}>
        <div>
          <p style={s({ margin: 0, marginBottom: '1mm' })}>
            <span style={s({ color: '#555' })}>Receipt No: </span>
            <span style={s({ fontWeight: 700 })}>{receiptNo}</span>
          </p>
          <p style={s({ margin: 0 })}>
            <span style={s({ color: '#555' })}>Date: </span>
            <span style={s({ fontWeight: 600 })}>{fmtDate(payment.date)}</span>
          </p>
        </div>
        <div style={s({ textAlign: 'right' })}>
          <p style={s({ margin: 0, marginBottom: '1mm' })}>
            <span style={s({ color: '#555' })}>Against Invoice: </span>
            <span style={s({ fontWeight: 700 })}>{bill.billNo}</span>
          </p>
          <p style={s({ margin: 0 })}>
            <span style={s({ color: '#555' })}>Invoice Dated: </span>
            <span style={s({ fontWeight: 600 })}>{fmtDate(bill.date)}</span>
          </p>
        </div>
      </div>

      {/* received from */}
      <div style={s({ marginTop: '4mm', borderRadius: '1.5mm', border: '1px solid #c9c9c9', background: '#faf7ef', padding: '2.5mm 3mm' })}>
        <p style={s({ margin: 0, fontSize: '7pt', textTransform: 'uppercase', letterSpacing: '0.18em', color: '#777' })}>Received with thanks from</p>
        <p style={s({ margin: '0.8mm 0 0', fontSize: '11pt', fontWeight: 700, lineHeight: 1.2 })}>{buyer}</p>
        {bill.variables['buyer_address'] ? (
          <p style={s({ margin: '0.6mm 0 0', whiteSpace: 'pre-line', fontSize: '7.5pt', lineHeight: 1.35, color: '#444' })}>
            {bill.variables['buyer_address']}
          </p>
        ) : null}
      </div>

      {/* amount */}
      <div style={s({ marginTop: '4mm', display: 'flex', alignItems: 'stretch', gap: '2.5mm' })}>
        <div style={s({ flex: 1, display: 'flex', alignItems: 'center', borderRadius: '1.5mm', border: '0.5mm solid #000', padding: '2.2mm 3mm' })}>
          <div>
            <p style={s({ margin: 0, fontSize: '7pt', textTransform: 'uppercase', letterSpacing: '0.18em', color: '#555' })}>Amount received</p>
            <p style={s({ margin: 0, fontSize: '15pt', fontWeight: 700, lineHeight: 1.15 })}>{fmtMoney(payment.amount, cur)}</p>
          </div>
        </div>
        <div style={s({ width: '34mm', display: 'flex', flexDirection: 'column', justifyContent: 'center', borderRadius: '1.5mm', border: '1px solid #c9c9c9', padding: '1.5mm 2.5mm', textAlign: 'center' })}>
          <p style={s({ margin: 0, fontSize: '6.5pt', textTransform: 'uppercase', letterSpacing: '0.14em', color: '#555' })}>Balance due</p>
          <p style={s({ margin: 0, fontSize: '10.5pt', fontWeight: 700, color: due > 0 ? '#b45309' : '#15803d' })}>
            {fmtMoney(due, cur)}
          </p>
        </div>
      </div>

      <p style={s({ margin: '2.5mm 0 0', fontSize: '7.5pt', lineHeight: 1.4 })}>
        <span style={s({ fontWeight: 700 })}>In words: </span>
        {amountInWords(payment.amount)}
      </p>

      {/* payment mode + QR */}
      <div style={s({ marginTop: '3mm', display: 'flex', alignItems: 'flex-start', gap: '3mm' })}>
        <div style={s({ minWidth: 0, flex: 1, fontSize: '8pt' })}>
          <p style={s({ margin: 0 })}>
            <span style={s({ color: '#555' })}>Payment mode: </span>
            <span style={s({ fontWeight: 700, textTransform: 'uppercase' })}>{payment.method}</span>
            {payment.reference ? (
              <>
                <span style={s({ color: '#555' })}> · Ref: </span>
                <span style={s({ fontFamily: 'monospace', fontWeight: 700 })}>{payment.reference}</span>
              </>
            ) : null}
          </p>
          <p style={s({ margin: '0.8mm 0 0', color: '#555' })}>
            Invoice total {fmtMoney(bill.totals.grandTotal, cur)} · total received {fmtMoney(paidAmount(bill), cur)}
            {dueAmount(bill) <= 0 ? ' · FULLY PAID' : ''}
          </p>
          <p style={s({ margin: '1.6mm 0 0', maxWidth: '80mm', fontSize: '6.5pt', lineHeight: 1.4, color: '#777' })}>
            {due > 0
              ? 'Scan the QR to pay the remaining balance instantly via any UPI app.'
              : 'Scan the QR to verify this receipt.'}
          </p>
        </div>
        <div style={s({ flexShrink: 0, textAlign: 'center' })}>
          {isServerRender() ? (
            <div
              style={s({ width: 62, height: 62 })}
              dangerouslySetInnerHTML={{ __html: qrSvg(receiptQrPayload(bill, settings, receiptNo), { fgColor: '#111111' }) }}
            />
          ) : (
            <QRCodeSVG value={receiptQrPayload(bill, settings, receiptNo)} size={62} level="M" bgColor="#ffffff" fgColor="#111111" />
          )}
          <p style={s({ margin: '0.8mm 0 0', fontSize: '5.5pt', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.14em', color: '#555' })}>
            {due > 0 ? 'Pay balance' : 'Verified'}
          </p>
        </div>
      </div>

      {/* notes */}
      {bill.notes ? (
        <p style={s({ margin: '2mm 0 0', whiteSpace: 'pre-line', borderTop: '1px solid #ddd', paddingTop: '1.5mm', fontSize: '7pt', color: '#555' })}>{bill.notes}</p>
      ) : null}

      {/* footer */}
      <div style={s({ marginTop: 'auto' })}>
        <div style={s({ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' })}>
          <p style={s({ margin: 0, fontSize: '6.5pt', color: '#777' })}>
            Computer-generated receipt · {biz.name}
            {biz.gstin ? ` · GSTIN ${biz.gstin}` : ''}
          </p>
          <div style={s({ width: '38mm', borderTop: '1px solid #000', paddingTop: '1mm', textAlign: 'center', fontSize: '7.5pt', fontWeight: 700 })}>
            Authorised Signatory
          </div>
        </div>
      </div>
    </div>
  );
}

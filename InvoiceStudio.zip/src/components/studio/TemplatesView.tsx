'use client';

/* ============================================================
 * InvoiceStudio — templates gallery
 * Preset gallery / duplicate / delete / open in designer
 * ============================================================ */
import React from 'react';
import { Copy, FileText, Pencil, Plus, Printer, Sparkles, Trash2 } from 'lucide-react';
import type { Settings, Template } from '@/lib/studio/types';
import { buildPresetTemplate, TEMPLATE_PRESETS, type PresetKey } from '@/lib/studio/defaults';
import { fmtDate, uid } from '@/lib/studio/format';
import TemplateThumb from './TemplateThumb';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

interface Props {
  templates: Template[];
  settings: Settings;
  onEdit: (t: Template) => void;
  onCreateBill: (t: Template) => void;
  onChanged: () => void;
}

/** tiny stylised preview mock for the preset cards */
function PresetMock({ kind }: { kind: PresetKey }) {
  const bar = (w: string, c: string, h = 'h-1') => <div className={`${h} w-${w} rounded-sm`} style={{ background: c }} />;
  if (kind === 'thermal') {
    return (
      <div className="mx-auto flex h-24 w-11 flex-col items-center gap-1 overflow-hidden rounded-sm border border-[#39445a] bg-white px-1 py-1.5">
        {bar('10', '#1a1a1a', 'h-1.5')}
        {bar('8', '#d4d4d8')}
        {bar('9', '#e4e4e7')}
        <div className="my-0.5 h-px w-full bg-zinc-300" />
        <div className="flex w-full flex-col gap-0.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="flex items-center justify-between border-b border-dotted border-zinc-300 pb-0.5">
              {bar('5', '#f4f4f5', 'h-0.5')}
              {bar('2', '#a1a1aa', 'h-0.5')}
            </div>
          ))}
        </div>
        <div className="mt-0.5 h-2 w-full rounded-sm bg-[#1c1c1c]" />
        {/* QR block */}
        <div className="mt-1 grid grid-cols-3 gap-px rounded-[2px] bg-[#1c1c1c] p-px">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className={`h-1 w-1 ${i % 2 === 0 ? 'bg-[#1c1c1c]' : 'bg-white'}`} />
          ))}
        </div>
        {bar('7', '#d4d4d8')}
      </div>
    );
  }
  if (kind === 'thermal58') {
    return (
      <div className="mx-auto flex h-24 w-8 flex-col items-center gap-0.5 overflow-hidden rounded-sm border border-[#39445a] bg-white px-0.5 py-1.5">
        {bar('7', '#1a1a1a', 'h-1')}
        {bar('6', '#d4d4d8', 'h-0.5')}
        {bar('7', '#e4e4e7', 'h-0.5')}
        <div className="my-0.5 h-px w-full bg-zinc-300" />
        <div className="flex w-full flex-col gap-0.5">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between border-b border-dotted border-zinc-300 pb-0.5">
              {bar('4', '#f4f4f5', 'h-0.5')}
              {bar('1.5', '#a1a1aa', 'h-0.5')}
            </div>
          ))}
        </div>
        <div className="mt-0.5 h-1.5 w-full rounded-sm bg-[#1c1c1c]" />
        <div className="grid grid-cols-3 gap-px rounded-[2px] bg-[#1c1c1c] p-px">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className={`h-[3px] w-[3px] ${i % 2 === 0 ? 'bg-[#1c1c1c]' : 'bg-white'}`} />
          ))}
        </div>
        <div className="mt-auto h-1.5 w-3/4 rounded-sm bg-[#1c1c1c]" />
      </div>
    );
  }
  if (kind === 'compact-a5') {
    return (
      <div className="mx-auto flex h-24 w-16 flex-col gap-1 rounded-sm border border-[#39445a] bg-white p-1.5">
        <div className="flex items-center justify-between">
          {bar('8', '#1a1a1a', 'h-1.5')}
          {bar('5', '#1a1a1a', 'h-1')}
        </div>
        <div className="h-px w-full bg-zinc-300" />
        {bar('10', '#e5e5e5')}
        <div className="grid flex-1 grid-cols-4 gap-px rounded-sm bg-zinc-200 p-px">
          {Array.from({ length: 12 }).map((_, i) => <div key={i} className="bg-white" />)}
        </div>
        <div className="ml-auto h-2.5 w-8 rounded-sm bg-[#1c1c1c]" />
      </div>
    );
  }
  if (kind === 'modern') {
    return (
      <div className="mx-auto flex h-24 w-20 flex-col gap-1 overflow-hidden rounded-sm border border-[#39445a] bg-white">
        <div className="flex h-5 items-center gap-1 bg-[#181818] px-1.5">
          <div className="h-1.5 w-5 rounded-sm bg-[#d9a13b]" />
          <div className="ml-auto h-1 w-4 rounded-sm bg-zinc-500" />
        </div>
        <div className="h-px w-full bg-[#d9a13b]" />
        <div className="flex flex-1 gap-1 p-1.5">
          <div className="flex flex-1 flex-col gap-1">
            {bar('10', '#e5e5e5')}
            {bar('8', '#eeeeee')}
            {bar('9', '#eeeeee')}
          </div>
          <div className="flex flex-1 flex-col gap-1">
            {bar('6', '#d4d4d4')}
            {bar('6', '#d4d4d4')}
            <div className="mt-auto h-2.5 w-full rounded-sm bg-[#181818]" />
          </div>
        </div>
      </div>
    );
  }
  if (kind === 'minimal') {
    return (
      <div className="mx-auto flex h-24 w-20 flex-col gap-1.5 rounded-sm border border-[#39445a] bg-white p-2">
        <div className="flex items-end justify-between">
          {bar('7', '#1a1a1a', 'h-2')}
          {bar('6', '#a1a1aa')}
        </div>
        <div className="h-px w-full bg-zinc-800" />
        {bar('9', '#e4e4e7')}
        {bar('7', '#eeeeee')}
        <div className="mt-1 space-y-1">
          {[0, 1, 2].map((i) => (
            <div key={i} className="flex items-center justify-between border-b border-zinc-200 pb-0.5">
              {bar('8', '#f4f4f5')}
              {bar('3', '#d4d4d8')}
            </div>
          ))}
        </div>
      </div>
    );
  }
  // classic
  return (
    <div className="mx-auto flex h-24 w-20 flex-col gap-1 overflow-hidden rounded-sm border border-[#39445a] bg-white">
      <div className="flex h-5 items-center gap-1 bg-[#f4f1ea] px-1.5">
        <div className="h-3 w-3 rounded-sm bg-[#e6ddc8]" />
        <div className="flex flex-col gap-0.5">
          {bar('7', '#1a1a1a', 'h-1')}
          {bar('5', '#a1a1aa')}
        </div>
      </div>
      <div className="h-2.5 w-full bg-[#1c1c1c]" />
      <div className="flex gap-1 px-1.5">
        <div className="h-4 flex-1 rounded-sm border border-zinc-300 bg-[#fafafa]" />
        <div className="h-4 flex-1 rounded-sm border border-zinc-300 bg-[#fafafa]" />
      </div>
      <div className="mx-1.5 grid flex-1 grid-cols-5 gap-px rounded-sm bg-zinc-200 p-px">
        {Array.from({ length: 10 }).map((_, i) => <div key={i} className="bg-white" />)}
      </div>
      <div className="ml-auto mb-1.5 mr-1.5 h-2.5 w-9 rounded-sm bg-[#1c1c1c]" />
    </div>
  );
}

export default function TemplatesView({ templates, settings, onEdit, onCreateBill, onChanged }: Props) {
  const { toast } = useToast();
  const [deleting, setDeleting] = React.useState<Template | null>(null);
  const [presetOpen, setPresetOpen] = React.useState(false);
  const [creating, setCreating] = React.useState(false);

  const createFromPreset = async (key: PresetKey, blank = false) => {
    setCreating(true);
    try {
      const tpl = blank
        ? {
            ...buildPresetTemplate('classic'),
            id: uid('tpl'),
            name: `Blank Template ${templates.length + 1}`,
            elements: [],
          }
        : buildPresetTemplate(key);
      const res = await fetch('/api/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tpl),
      });
      if (!res.ok) throw new Error();
      const saved = (await res.json()) as Template;
      setPresetOpen(false);
      onChanged();
      onEdit(saved);
      toast({ title: 'Template created', description: saved.name });
    } catch {
      toast({ title: 'Could not create template', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const duplicate = async (t: Template) => {
    const copy: Template = {
      ...JSON.parse(JSON.stringify(t)) as Template,
      id: uid('tpl'),
      name: `${t.name} (copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const res = await fetch('/api/templates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(copy),
    });
    if (res.ok) {
      toast({ title: 'Template duplicated', description: copy.name });
      onChanged();
    }
  };

  const doDelete = async () => {
    if (!deleting) return;
    const res = await fetch(`/api/templates/${deleting.id}`, { method: 'DELETE' });
    if (res.ok) {
      toast({ title: 'Template deleted', description: deleting.name });
      onChanged();
    }
    setDeleting(null);
  };

  return (
    <div className="studio-scroll flex-1 overflow-y-auto p-5">
      <div className="mx-auto max-w-6xl">
        <div className="mb-5 flex items-end justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-100">Bill Templates</h1>
            <p className="mt-0.5 text-xs text-zinc-500">Design once — reuse for every bill.</p>
          </div>
          <Button className="h-9 gap-1.5 bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055]" onClick={() => setPresetOpen(true)}>
            <Plus className="h-4 w-4" /> New template
          </Button>
        </div>

        {templates.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed border-[#2a3342] py-16 text-center">
            <FileText className="h-9 w-9 text-zinc-700" />
            <p className="text-sm text-zinc-500">No templates yet — start from a ready-made preset.</p>
            <Button className="bg-[#d9a13b] text-black hover:bg-[#e5b055]" onClick={() => setPresetOpen(true)}>
              <Sparkles className="mr-1 h-4 w-4" /> Browse presets
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {templates.map((t) => (
              <div key={t.id} className="group overflow-hidden rounded-lg border border-[#232b38] bg-[#12161d] transition-all hover:-translate-y-0.5 hover:border-[#d9a13b]/50 hover:shadow-[0_10px_32px_rgba(0,0,0,0.4)]">
                <TemplateThumb template={t} settings={settings} />
                <div className="border-t border-[#232b38] p-3.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate text-sm font-semibold text-zinc-100">{t.name}</h3>
                      <p className="mt-0.5 text-[10px] text-zinc-600">
                        {t.page.sizeName} · {t.elements.length} elements · edited {fmtDate(t.updatedAt.slice(0, 10))}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-1.5">
                    <Button size="sm" className="h-7 flex-1 gap-1 bg-[#d9a13b] text-[11px] font-semibold text-black hover:bg-[#e5b055]" onClick={() => onEdit(t)}>
                      <Pencil className="h-3 w-3" /> Design
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 flex-1 gap-1 border-[#2a3342] text-[11px]" onClick={() => onCreateBill(t)}>
                      <Printer className="h-3 w-3" /> Use
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" title="Duplicate" onClick={() => duplicate(t)}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7 hover:text-red-400" title="Delete" onClick={() => setDeleting(t)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* preset gallery */}
      <Dialog open={presetOpen} onOpenChange={setPresetOpen}>
        <DialogContent className="max-w-3xl border-[#2a3342] bg-[#12161d] text-zinc-200">
          <DialogHeader className="border-b border-[#232b38] pb-3">
            <DialogTitle className="flex items-center gap-2 text-sm">
              <Sparkles className="h-4 w-4 text-[#d9a13b]" /> New template from a preset
            </DialogTitle>
            <DialogDescription className="sr-only">
              Pick a starting layout; everything stays editable in the designer.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {TEMPLATE_PRESETS.map((p) => (
              <button
                key={p.key}
                type="button"
                disabled={creating}
                className="group flex items-start gap-3 rounded-lg border border-[#232b38] bg-[#0f1319] p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-[#d9a13b]/60 hover:shadow-[0_8px_28px_rgba(0,0,0,0.4)] disabled:opacity-50"
                onClick={() => createFromPreset(p.key)}
              >
                <PresetMock kind={p.key} />
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                    {p.name}
                    <span
                      className="h-2 w-2 shrink-0 rounded-full ring-2 ring-white/10"
                      style={{ background: p.accent }}
                    />
                  </p>
                  <p className="mt-0.5 text-[10px] font-medium uppercase tracking-wider text-zinc-600">{p.size} · ready to edit</p>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-zinc-500">{p.desc}</p>
                </div>
              </button>
            ))}
            <button
              type="button"
              disabled={creating}
              className="flex items-center justify-center gap-2 rounded-lg border border-dashed border-[#2a3342] p-3.5 text-sm text-zinc-500 transition-colors hover:border-[#d9a13b]/50 hover:text-zinc-300 disabled:opacity-50 sm:col-span-2"
              onClick={() => createFromPreset('classic', true)}
            >
              <Plus className="h-4 w-4" /> Start from a blank canvas instead
            </button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{deleting?.name}”?</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Bills printed with this template keep their stored copy, but you will no longer be able to print new ones.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2a3342] bg-transparent text-zinc-300 hover:bg-[#1a212c]">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 text-white hover:bg-red-500" onClick={doDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

'use client';

/* ============================================================
 * InvoiceStudio — business settings
 * ============================================================ */
import React, { useEffect, useRef, useState } from 'react';
import { CalendarSync, Crosshair, Download, Globe, ListPlus, Plus, Save, Sparkles, Trash2, Type, Upload, UploadCloud, X } from 'lucide-react';
import type { BuyerFieldDef, CustomFontDef, Settings } from '@/lib/studio/types';
import { RESERVED_BUYER_KEYS } from '@/lib/studio/defaults';
import { formatFontFamily, getGoogleFontCssUrl } from '@/lib/studio/fonts';
import { slugKey } from '@/lib/studio/format';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

interface Props {
  settings: Settings;
  onSaved: (s: Settings) => void;
  onPrintCalibration?: () => void;
}

export default function SettingsView({ settings, onSaved, onPrintCalibration }: Props) {
  const { toast } = useToast();
  const [form, setForm] = useState<Settings>(settings);
  const [saving, setSaving] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoring, setRestoring] = useState(false);
  const restoreInputRef = useRef<HTMLInputElement | null>(null);
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldType, setNewFieldType] = useState<BuyerFieldDef['type']>('text');

  // Custom fonts state
  const [customFontMode, setCustomFontMode] = useState<'google' | 'upload'>('google');
  const [googleFontName, setGoogleFontName] = useState('');
  const [googleFontCategory, setGoogleFontCategory] = useState<'sans' | 'serif' | 'mono' | 'display' | 'handwriting'>('sans');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadFontName, setUploadFontName] = useState('');
  const [uploadFontCategory, setUploadFontCategory] = useState<'sans' | 'serif' | 'mono' | 'display'>('sans');
  const [isUploadingFont, setIsUploadingFont] = useState(false);
  const fontFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => setForm(settings), [settings]);

  const setB = (patch: Partial<Settings['business']>) =>
    setForm((f) => ({ ...f, business: { ...f.business, ...patch } }));

  /** add a buyer custom field — key is slugged from the label and frozen from then on */
  const addBuyerField = () => {
    const label = newFieldLabel.trim();
    if (!label) {
      toast({ title: 'Enter a field name first', variant: 'destructive' });
      return;
    }
    const key = slugKey(label);
    const taken = new Set([...(form.buyerFields ?? []).map((f) => f.key), ...RESERVED_BUYER_KEYS]);
    if (taken.has(key)) {
      toast({ title: 'A field with this name already exists', variant: 'destructive' });
      return;
    }
    setForm((f) => ({ ...f, buyerFields: [...(f.buyerFields ?? []), { key, label, type: newFieldType }] }));
    setNewFieldLabel('');
  };

  /** add a custom font from Google Fonts / Web font */
  const addGoogleFont = (directName?: string) => {
    const name = (directName || googleFontName).trim();
    if (!name) {
      toast({ title: 'Enter a font name first', variant: 'destructive' });
      return;
    }
    const exists = (form.customFonts ?? []).some(
      (f) => f.name.toLowerCase() === name.toLowerCase(),
    );
    if (exists) {
      toast({ title: 'This font is already in your custom fonts list', variant: 'destructive' });
      return;
    }
    const fallback = googleFontCategory === 'serif' ? 'serif' : googleFontCategory === 'mono' ? 'monospace' : 'sans-serif';
    const newFont: CustomFontDef = {
      id: `font_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name,
      family: formatFontFamily(name, fallback),
      source: 'google',
      url: getGoogleFontCssUrl(name),
      category: googleFontCategory,
      createdAt: new Date().toISOString(),
    };
    setForm((f) => ({ ...f, customFonts: [...(f.customFonts ?? []), newFont] }));
    setGoogleFontName('');
    toast({
      title: 'Custom font added',
      description: `"${name}" is now available in the template designer. Click "Save settings" to save.`,
    });
  };

  const pickUploadFont = (file?: File) => {
    if (!file) return;
    setUploadFile(file);
    const base = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]+/g, ' ').trim();
    setUploadFontName(base);
  };

  const submitUploadFont = async () => {
    if (!uploadFile) {
      toast({ title: 'Select a font file first', variant: 'destructive' });
      return;
    }
    setIsUploadingFont(true);
    try {
      const fd = new FormData();
      fd.append('file', uploadFile);
      if (uploadFontName.trim()) {
        fd.append('name', uploadFontName.trim());
      }
      const res = await fetch('/api/fonts/upload', {
        method: 'POST',
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Upload failed');

      const fallback = uploadFontCategory === 'serif' ? 'serif' : uploadFontCategory === 'mono' ? 'monospace' : 'sans-serif';
      const newFont: CustomFontDef = {
        id: `font_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        name: data.name,
        family: formatFontFamily(data.name, fallback),
        source: 'upload',
        fileUrl: data.fileUrl,
        dataUrl: data.dataUrl,
        format: data.format,
        category: uploadFontCategory,
        createdAt: new Date().toISOString(),
      };
      setForm((f) => ({ ...f, customFonts: [...(f.customFonts ?? []), newFont] }));
      setUploadFile(null);
      setUploadFontName('');
      if (fontFileInputRef.current) fontFileInputRef.current.value = '';
      toast({
        title: 'Font uploaded successfully',
        description: `"${data.name}" is now installed and available in the designer. Click "Save settings" to save.`,
      });
    } catch (err) {
      toast({
        title: 'Upload failed',
        description: err instanceof Error ? err.message : 'Could not upload font',
        variant: 'destructive',
      });
    } finally {
      setIsUploadingFont(false);
    }
  };

  const removeCustomFont = (id: string) => {
    setForm((f) => ({
      ...f,
      customFonts: (f.customFonts ?? []).filter((font) => font.id !== id),
    }));
    toast({ title: 'Font removed', description: 'Click "Save settings" to save your changes.' });
  };

  const uploadLogo = (file: File) => {
    // compress to max 400px to keep the JSON DB lean
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 400;
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * k);
        canvas.height = Math.round(img.height * k);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setB({ logo: canvas.toDataURL('image/png') });
          toast({ title: 'Logo ready', description: 'Remember to press Save.' });
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      const saved = (await res.json()) as Settings;
      onSaved(saved);
      toast({ title: 'Settings saved', description: 'Your business profile has been updated.' });
    } catch {
      toast({ title: 'Save failed', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const pickRestore = (file: File | undefined) => {
    if (file && file.type !== 'application/json' && !file.name.endsWith('.json')) {
      toast({ title: 'Not a backup file', description: 'Choose a previously downloaded InvoiceStudio backup (.json).', variant: 'destructive' });
      return;
    }
    if (file) setRestoreFile(file);
  };

  const doRestore = async () => {
    if (!restoreFile) return;
    setRestoring(true);
    try {
      const text = await restoreFile.text();
      const payload = JSON.parse(text); // validates the file is valid JSON first
      const res = await fetch('/api/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(err.error || 'restore failed');
      }
      const out = (await res.json()) as { counts: { templates: number; bills: number; buyers: number } };
      toast({
        title: 'Backup restored',
        description: `${out.counts.templates} templates · ${out.counts.bills} bills · ${out.counts.buyers} buyers.`,
      });
      window.location.reload();
    } catch (e) {
      toast({ title: 'Restore failed', description: e instanceof Error ? e.message : 'The file could not be restored.', variant: 'destructive' });
    } finally {
      setRestoring(false);
      setRestoreFile(null);
    }
  };

  const F = ({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) => (
    <div className={wide ? 'sm:col-span-2' : ''}>
      <Label className="text-[10px] uppercase tracking-wider text-zinc-500">{label}</Label>
      {children}
    </div>
  );
  const inputCls = 'mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm';

  return (
    <div className="studio-scroll flex-1 overflow-y-auto p-5">
      <div className="mx-auto max-w-3xl space-y-5">
        <div className="flex items-end justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-100">Settings</h1>
            <p className="mt-0.5 text-xs text-zinc-500">Business profile, tax mode & bill numbering.</p>
          </div>
          <Button className="h-9 gap-1.5 bg-[#d9a13b] font-semibold text-black hover:bg-[#e5b055]" disabled={saving} onClick={save}>
            <Save className="h-4 w-4" /> Save settings
          </Button>
        </div>

        {/* business profile */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">My Business</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <F label="Business name">
              <Input className={inputCls} value={form.business.name} onChange={(e) => setB({ name: e.target.value })} />
            </F>
            <F label="GSTIN">
              <Input className={inputCls} value={form.business.gstin} onChange={(e) => setB({ gstin: e.target.value })} />
            </F>
            <F label="Address" wide>
              <Textarea className="mt-1 min-h-[60px] border-[#2a3342] bg-[#0d1117] text-sm" value={form.business.address} onChange={(e) => setB({ address: e.target.value })} />
            </F>
            <F label="Phone">
              <Input className={inputCls} value={form.business.phone} onChange={(e) => setB({ phone: e.target.value })} />
            </F>
            <F label="Email">
              <Input className={inputCls} value={form.business.email} onChange={(e) => setB({ email: e.target.value })} />
            </F>
            <F label="State">
              <Input className={inputCls} value={form.business.state} onChange={(e) => setB({ state: e.target.value })} />
            </F>
            <F label="State code">
              <Input className={inputCls} value={form.business.stateCode} onChange={(e) => setB({ stateCode: e.target.value })} />
            </F>
            <F label="Terms & Conditions" wide>
              <Textarea className="mt-1 min-h-[70px] border-[#2a3342] bg-[#0d1117] text-sm" value={form.business.terms} onChange={(e) => setB({ terms: e.target.value })} />
            </F>
          </div>
          <div className="mt-4 flex items-center gap-4 rounded border border-[#2a3342] bg-[#0d1117] p-3">
            {form.business.logo ? (
              <div className="relative flex h-16 w-24 items-center justify-center rounded bg-white p-1">
                { }
                <img src={form.business.logo} alt="Business logo" className="max-h-full max-w-full object-contain" />
                <button
                  type="button"
                  className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-600 text-white"
                  onClick={() => setB({ logo: '' })}
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <div className="flex h-16 w-24 items-center justify-center rounded border border-dashed border-[#3a4456] text-[10px] text-zinc-600">
                No logo
              </div>
            )}
            <div>
              <p className="text-xs font-medium text-zinc-300">Business logo</p>
              <p className="mb-2 text-[10px] text-zinc-600">Upload once here, then add a Logo element in any template — or insert it per-template in the designer.</p>
              <label className="inline-flex h-7 cursor-pointer items-center gap-1.5 rounded bg-[#171d27] px-2.5 text-[11px] text-zinc-300 hover:bg-[#202936]">
                <Upload className="h-3 w-3" /> Upload logo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadLogo(f);
                    e.target.value = '';
                  }}
                />
              </label>
            </div>
          </div>
        </section>

        {/* bank */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Bank Details</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <F label="Bank name">
              <Input className={inputCls} value={form.business.bankName} onChange={(e) => setB({ bankName: e.target.value })} />
            </F>
            <F label="Account no">
              <Input className={inputCls} value={form.business.accountNo} onChange={(e) => setB({ accountNo: e.target.value })} />
            </F>
            <F label="IFSC">
              <Input className={inputCls} value={form.business.ifsc} onChange={(e) => setB({ ifsc: e.target.value })} />
            </F>
            <F label="UPI ID">
              <Input className={inputCls} value={form.business.upi} onChange={(e) => setB({ upi: e.target.value })} />
            </F>
          </div>
        </section>

        {/* billing prefs */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Billing Preferences</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <F label="Currency symbol">
              <Input className={inputCls} value={form.currency} onChange={(e) => setForm((f) => ({ ...f, currency: e.target.value }))} />
            </F>
            <F label="Bill no prefix">
              <Input className={inputCls} value={form.billNoPrefix} onChange={(e) => setForm((f) => ({ ...f, billNoPrefix: e.target.value }))} />
            </F>
            <F label="Next bill number">
              <Input
                type="number"
                className={inputCls}
                value={form.billNoNext}
                min={1}
                onChange={(e) => setForm((f) => ({ ...f, billNoNext: Math.max(1, Number(e.target.value)) }))}
              />
            </F>
            <div className="flex items-end pb-1">
              <div className="flex items-center justify-between rounded border border-[#2a3342] bg-[#0d1117] px-3 py-2">
                <div className="mr-4">
                  <p className="text-xs font-medium text-zinc-200">Inter-state supplies (IGST)</p>
                  <p className="text-[10px] text-zinc-600">Off = split CGST + SGST</p>
                </div>
                <Switch
                  checked={form.interState}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, interState: v }))}
                />
              </div>
            </div>
            <div className="flex items-end pb-1 sm:col-span-2">
              <div className="flex w-full items-center justify-between rounded-md border border-[#d9a13b]/25 bg-gradient-to-r from-[#d9a13b]/[0.07] to-transparent px-3 py-2.5">
                <div className="mr-4">
                  <p className="flex items-center gap-1.5 text-xs font-medium text-zinc-100">
                    <CalendarSync className="h-3.5 w-3.5 text-[#d9a13b]" /> Auto-create recurring invoices
                  </p>
                  <p className="mt-0.5 text-[10px] leading-relaxed text-zinc-500">
                    When enabled, the first app-open of each day creates the next copy of every due recurring invoice —
                    same buyer & items, next number, fresh unpaid state. Manual “Create next” always stays available.
                  </p>
                </div>
                <Switch
                  checked={form.autoRecurring === true}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, autoRecurring: v }))}
                />
              </div>
            </div>
          </div>
        </section>

        {/* buyer custom fields */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
            <ListPlus className="h-3.5 w-3.5 text-[#d9a13b]" /> Buyer Custom Fields
          </h2>
          <p className="mb-3 text-[11px] leading-relaxed text-zinc-600">
            Need more buyer info than name / GSTIN / phone? Define your own fields — they appear on the
            buyer form &amp; cards, flow into bills as template variables
            (<code className="font-mono text-[10px] text-zinc-500">{'{{buyer_<key>}}'}</code>) and become extra
            CSV import/export columns. Press <span className="text-zinc-400">Save settings</span> to apply.
          </p>

          {(form.buyerFields ?? []).length > 0 && (
            <div className="space-y-1.5">
              {(form.buyerFields ?? []).map((f) => (
                <div
                  key={f.key}
                  className="flex flex-wrap items-center gap-2 rounded-md border border-[#232b38] bg-[#0f1319] px-2.5 py-2"
                >
                  <Input
                    className="h-7 w-44 border-[#2a3342] bg-[#0d1117] text-xs"
                    value={f.label}
                    aria-label={`Label for ${f.key}`}
                    onChange={(e) =>
                      setForm((s) => ({
                        ...s,
                        buyerFields: (s.buyerFields ?? []).map((x) => (x.key === f.key ? { ...x, label: e.target.value } : x)),
                      }))
                    }
                  />
                  <span className="rounded border border-[#2a3342] bg-[#0d1117] px-1.5 py-0.5 font-mono text-[9px] text-zinc-500" title="Stable storage key — used as the {{buyer_<key>}} template variable">
                    {'{{buyer_' + f.key + '}}'}
                  </span>
                  <Select
                    value={f.type}
                    onValueChange={(v) =>
                      setForm((s) => ({
                        ...s,
                        buyerFields: (s.buyerFields ?? []).map((x) => (x.key === f.key ? { ...x, type: v as BuyerFieldDef['type'] } : x)),
                      }))
                    }
                  >
                    <SelectTrigger className="h-7 w-24 border-[#2a3342] bg-[#0d1117] text-[11px]" aria-label={`Type for ${f.key}`} />
                    <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                      <SelectItem value="text" className="text-xs">Text</SelectItem>
                      <SelectItem value="number" className="text-xs">Number</SelectItem>
                      <SelectItem value="date" className="text-xs">Date</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-auto h-7 w-7 hover:text-red-400"
                    title="Remove this field from the buyer form"
                    aria-label={`Remove ${f.label}`}
                    onClick={() =>
                      setForm((s) => ({ ...s, buyerFields: (s.buyerFields ?? []).filter((x) => x.key !== f.key) }))
                    }
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {(form.buyerFields ?? []).length < 12 ? (
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Input
                className="h-8 w-52 border-[#2a3342] bg-[#0d1117] text-xs"
                placeholder="New field name — e.g. Credit Limit"
                value={newFieldLabel}
                onChange={(e) => setNewFieldLabel(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addBuyerField(); } }}
              />
              <Select value={newFieldType} onValueChange={(v) => setNewFieldType(v as BuyerFieldDef['type'])}>
                <SelectTrigger className="h-8 w-24 border-[#2a3342] bg-[#0d1117] text-[11px]" aria-label="New field type" />
                <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                  <SelectItem value="text" className="text-xs">Text</SelectItem>
                  <SelectItem value="number" className="text-xs">Number</SelectItem>
                  <SelectItem value="date" className="text-xs">Date</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                className="h-8 gap-1.5 border-[#d9a13b]/40 text-xs text-[#e8c064] hover:bg-[#d9a13b]/10 hover:text-[#e8c064]"
                onClick={addBuyerField}
              >
                <Plus className="h-3.5 w-3.5" /> Add field
              </Button>
              <span className="text-[10px] text-zinc-600">{(form.buyerFields ?? []).length}/12 fields</span>
            </div>
          ) : (
            <p className="mt-2 text-[10px] text-zinc-600">Field limit reached (12) — remove one to add another.</p>
          )}
        </section>

        {/* custom fonts manager */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-400 flex items-center gap-1.5">
              <Type className="h-4 w-4 text-[#d9a13b]" /> Custom Fonts
            </h2>
            <span className="text-[10px] text-zinc-500 font-mono">
              {(form.customFonts ?? []).length} custom font{(form.customFonts ?? []).length === 1 ? '' : 's'}
            </span>
          </div>
          <p className="mb-3 text-[11px] leading-relaxed text-zinc-500">
            Install custom fonts from local files (<code className="text-[10px] text-[#e8c064]">.woff2, .woff, .ttf, .otf</code>) or add any Google Font by name. Installed fonts become immediately available in the template designer typography picker and are preserved in print and PDF outputs.
          </p>

          {/* Mode switch */}
          <div className="flex gap-2 p-1 rounded-md bg-[#0d1117] border border-[#2a3342] w-fit mb-4">
            <button
              type="button"
              onClick={() => setCustomFontMode('google')}
              className={`px-3 py-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
                customFontMode === 'google' ? 'bg-[#d9a13b] font-semibold text-black' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Globe className="h-3.5 w-3.5" /> Google & Web Fonts
            </button>
            <button
              type="button"
              onClick={() => setCustomFontMode('upload')}
              className={`px-3 py-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
                customFontMode === 'upload' ? 'bg-[#d9a13b] font-semibold text-black' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <UploadCloud className="h-3.5 w-3.5" /> Upload Font File
            </button>
          </div>

          {customFontMode === 'google' ? (
            <div className="space-y-3 rounded-md border border-[#2a3342] bg-[#0d1117] p-3.5">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <Input
                  className="h-8 flex-1 border-[#2a3342] bg-[#12161d] text-xs"
                  placeholder="Enter Google Font name (e.g. Cinzel, Caveat, Fira Code, Great Vibes)"
                  value={googleFontName}
                  onChange={(e) => setGoogleFontName(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addGoogleFont(); } }}
                />
                <Select value={googleFontCategory} onValueChange={(v) => setGoogleFontCategory(v as any)}>
                  <SelectTrigger className="h-8 w-32 border-[#2a3342] bg-[#12161d] text-xs" aria-label="Font Category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    <SelectItem value="sans" className="text-xs">Sans-Serif</SelectItem>
                    <SelectItem value="serif" className="text-xs">Serif</SelectItem>
                    <SelectItem value="mono" className="text-xs">Monospace</SelectItem>
                    <SelectItem value="display" className="text-xs">Display / Header</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  className="h-8 gap-1.5 border-[#d9a13b]/40 text-xs text-[#e8c064] hover:bg-[#d9a13b]/10 hover:text-[#e8c064]"
                  onClick={() => addGoogleFont()}
                >
                  <Plus className="h-3.5 w-3.5" /> Add Font
                </Button>
              </div>

              {/* Quick suggestions */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider mr-1">Popular Suggestions:</span>
                {[
                  { name: 'Cinzel', cat: 'serif' as const },
                  { name: 'Caveat', cat: 'display' as const },
                  { name: 'Fira Code', cat: 'mono' as const },
                  { name: 'DM Sans', cat: 'sans' as const },
                  { name: 'Dancing Script', cat: 'display' as const },
                  { name: 'Abril Fatface', cat: 'display' as const },
                  { name: 'Barlow Semi Condensed', cat: 'sans' as const },
                ].map((s) => (
                  <button
                    key={s.name}
                    type="button"
                    onClick={() => {
                      setGoogleFontCategory(s.cat);
                      addGoogleFont(s.name);
                    }}
                    className="px-2 py-0.5 rounded border border-[#2a3342] bg-[#12161d] text-[10px] text-zinc-300 hover:border-[#d9a13b]/60 hover:text-[#d9a13b] transition-colors"
                  >
                    + {s.name}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-3 rounded-md border border-[#2a3342] bg-[#0d1117] p-3.5">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <input
                  ref={fontFileInputRef}
                  type="file"
                  accept=".woff2,.woff,.ttf,.otf"
                  className="hidden"
                  onChange={(e) => pickUploadFont(e.target.files?.[0])}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5 border-[#2a3342] text-xs shrink-0"
                  onClick={() => fontFileInputRef.current?.click()}
                >
                  <UploadCloud className="h-3.5 w-3.5" /> Choose Font File (.woff2, .ttf, .otf)
                </Button>

                <Input
                  className="h-8 flex-1 border-[#2a3342] bg-[#12161d] text-xs"
                  placeholder="Font Display Name (e.g. My Brand Sans)"
                  value={uploadFontName}
                  onChange={(e) => setUploadFontName(e.target.value)}
                />

                <Select value={uploadFontCategory} onValueChange={(v) => setUploadFontCategory(v as any)}>
                  <SelectTrigger className="h-8 w-32 border-[#2a3342] bg-[#12161d] text-xs" aria-label="Font Category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    <SelectItem value="sans" className="text-xs">Sans-Serif</SelectItem>
                    <SelectItem value="serif" className="text-xs">Serif</SelectItem>
                    <SelectItem value="mono" className="text-xs">Monospace</SelectItem>
                    <SelectItem value="display" className="text-xs">Display</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant="outline"
                  disabled={!uploadFile || isUploadingFont}
                  className="h-8 gap-1.5 border-[#d9a13b]/40 text-xs text-[#e8c064] hover:bg-[#d9a13b]/10 hover:text-[#e8c064] shrink-0"
                  onClick={submitUploadFont}
                >
                  {isUploadingFont ? <UploadCloud className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
                  Upload & Install
                </Button>
              </div>

              {uploadFile && (
                <div className="flex items-center gap-2 text-xs text-[#e8c064]">
                  <span className="font-mono text-[11px] bg-[#181f2a] px-2 py-0.5 rounded border border-[#2a3342]">
                    {uploadFile.name} ({(uploadFile.size / 1024).toFixed(1)} KB)
                  </span>
                  <span className="text-zinc-500 text-[11px]">Ready to upload.</span>
                </div>
              )}
            </div>
          )}

          {/* Installed Custom Fonts List */}
          <div className="mt-4">
            <h3 className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-2">Installed Custom Fonts</h3>
            {(!form.customFonts || form.customFonts.length === 0) ? (
              <div className="rounded-md border border-dashed border-[#2a3342] bg-[#0d1117] p-5 text-center text-xs text-zinc-500">
                No custom fonts installed yet. Add a Google Font above or upload a font file to use in your templates.
              </div>
            ) : (
              <div className="space-y-2">
                {form.customFonts.map((font) => (
                  <div
                    key={font.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 rounded-md border border-[#232b38] bg-[#0d1117] px-3.5 py-2.5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-xs text-zinc-200">{font.name}</span>
                        <span className="rounded bg-[#202836] px-1.5 py-0.5 text-[9px] uppercase font-mono text-zinc-400">
                          {font.source === 'upload' ? (font.format ? `Upload (${font.format})` : 'Upload') : 'Google Font'}
                        </span>
                        <span className="text-[10px] text-zinc-500">· {font.category ?? 'sans'}</span>
                      </div>
                      {/* Live preview in the exact font */}
                      <div
                        style={{ fontFamily: font.family }}
                        className="text-sm text-[#e8c064] tracking-wide truncate select-all py-0.5"
                        title={font.family}
                      >
                        ABCDEFGHIJKLM 1234567890 — The quick brown fox jumps over the lazy dog
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-zinc-500 hover:text-red-400 shrink-0 self-end sm:self-center"
                      title="Remove font"
                      onClick={() => removeCustomFont(font.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* print calibration */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Print Calibration</h2>
          <p className="mb-3 text-[11px] text-zinc-600">
            Shift the whole print by a few mm if your printer misaligns — ideal for pre-printed letterhead stock.
            <span className="text-zinc-500"> Individual templates can override this in the designer (page setup → print offset).</span>
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <F label="Horizontal offset (mm, +right)">
              <Input
                type="number"
                step={0.5}
                className={inputCls}
                value={form.printOffsetX}
                onChange={(e) => setForm((f) => ({ ...f, printOffsetX: Number(e.target.value) || 0 }))}
              />
            </F>
            <F label="Vertical offset (mm, +down)">
              <Input
                type="number"
                step={0.5}
                className={inputCls}
                value={form.printOffsetY}
                onChange={(e) => setForm((f) => ({ ...f, printOffsetY: Number(e.target.value) || 0 }))}
              />
            </F>
          </div>
          <div className="mt-3 flex items-center justify-between rounded-md border border-[#1e2634] bg-[#0f1319] px-3 py-2.5">
            <div>
              <p className="text-xs font-medium text-zinc-200">Status stamp on print</p>
              <p className="mt-0.5 text-[10px] text-zinc-600">
                Auto-overlay a “PAID” / “CANCELLED” rubber stamp when printing bills with that status.
              </p>
            </div>
            <Switch
              checked={form.statusStamp !== false}
              onCheckedChange={(v) => setForm((f) => ({ ...f, statusStamp: v }))}
            />
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-md border border-[#d9a13b]/25 bg-gradient-to-r from-[#d9a13b]/10 to-transparent px-3 py-2.5">
            <div className="min-w-0">
              <p className="flex items-center gap-1.5 text-xs font-medium text-zinc-100">
                <Crosshair className="h-3.5 w-3.5 text-[#d9a13b]" /> Calibration sheet
              </p>
              <p className="mt-0.5 text-[10px] leading-relaxed text-zinc-500">
                Print an A4 test grid with rulers, crop marks and a 100×50 mm box — shifted by your current offsets.
                Compare against a ruler to dial the offsets in for pre-printed letterhead stock.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-8 shrink-0 gap-1.5 border-[#d9a13b]/40 text-xs text-[#e8c064] hover:bg-[#d9a13b]/10"
              onClick={onPrintCalibration}
              disabled={!onPrintCalibration}
            >
              <Crosshair className="h-3.5 w-3.5" /> Print test sheet
            </Button>
          </div>
        </section>

        {/* backup & restore */}
        <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
          <h2 className="mb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Backup & Restore</h2>
          <p className="mb-3 text-[11px] text-zinc-600">
            Download everything (templates, bills, buyers, variables, settings) as one JSON file — or restore from a previous backup.
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <a href="/api/backup" download>
              <Button variant="outline" size="sm" className="h-8 gap-1.5 border-[#2a3342] text-xs">
                <Download className="h-3.5 w-3.5" /> Download backup
              </Button>
            </a>
            <label className="inline-flex">
              <Button
                variant="outline"
                size="sm"
                className="h-8 cursor-pointer gap-1.5 border-[#2a3342] text-xs"
                onClick={(e) => {
                  e.preventDefault();
                  restoreInputRef.current?.click();
                }}
              >
                <Upload className="h-3.5 w-3.5" /> Restore from backup…
              </Button>
              <input
                ref={restoreInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={(e) => {
                  pickRestore(e.target.files?.[0]);
                  e.target.value = '';
                }}
              />
            </label>
            {restoreFile && (
              <span className="flex items-center gap-2 rounded border border-[#d9a13b]/40 bg-[#d9a13b]/10 px-2 py-1 text-[11px] text-[#e8c064]">
                {restoreFile.name}
                <button type="button" onClick={() => setRestoreFile(null)} aria-label="Clear chosen file">
                  <X className="h-3 w-3" />
                </button>
              </span>
            )}
          </div>
          {restoreFile && (
            <p className="mt-2 text-[11px] text-amber-400/90">
              Confirm on the dialog to restore — this will <strong>overwrite all current data</strong>.
            </p>
          )}
        </section>

        {/* storage info */}
        <section className="rounded-lg border border-[#2a3342] border-dashed bg-transparent p-4">
          <h2 className="mb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Data Storage</h2>
          <p className="text-xs leading-relaxed text-zinc-500">
            All data is stored in simple JSON files on this machine under <code className="rounded bg-[#1a212c] px-1 font-mono text-[10px] text-[#d9a13b]">/db</code> —
            templates, bills, buyers, variables and settings. No external database is required. Back up the folder by copying it anywhere, or use the one-click backup above.
          </p>
        </section>
      </div>

      {/* restore confirm */}
      <AlertDialog open={!!restoreFile} onOpenChange={(o) => !o && setRestoreFile(null)}>
        <AlertDialogContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
          <AlertDialogHeader>
            <AlertDialogTitle>Overwrite all data with this backup?</AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Current templates, bills, buyers, variables and settings will be replaced by the contents of “{restoreFile?.name}”. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2a3342] bg-transparent text-zinc-300 hover:bg-[#1a212c]">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 text-white hover:bg-red-500" onClick={doRestore}>
              Yes, restore
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

'use client';

/* ============================================================
 * InvoiceStudio — Create / Edit Bill
 * Dynamic variable form + items editor + totals + live preview
 * ============================================================ */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, ArrowRightLeft, BookmarkPlus, CalendarSync, ChevronDown,
  FileDown, Package, Plus, Printer, Save, Trash2,
} from 'lucide-react';
import type { Bill, BillItem, BillStatus, Buyer, DocType, ItemRecord, RepeatCadence, Settings, Template, VariableDef } from '@/lib/studio/types';
import { BUILTIN_BILL_VARS, buyerCustomVarDefs } from '@/lib/studio/defaults';
import { amountInWords, computeTotals, docTypeOf, fmtMoney, itemAmount, nextBillNo, todayISO, uid } from '@/lib/studio/format';
import { effectivePageHeight, paginateTemplate } from '@/lib/studio/render';
import { downloadPdf } from '@/lib/studio/downloadPdf';
import BillPreview from './BillPreview';
import { useFitScale } from './useFitScale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

interface Props {
  templates: Template[];
  settings: Settings;
  customVars: VariableDef[];
  bills: Bill[];
  buyers: Buyer[];
  catalogItems?: ItemRecord[];
  initialItem?: ItemRecord | null;
  onReloadCatalog?: () => void;
  editBill: Bill | null;
  duplicateFrom: Bill | null;
  initialTemplateId: string | null;
  onSaved: (b: Bill) => void;
  onPrint: (template: Template, bill: Bill, copies: number) => void;
  onBack: () => void;
}

function emptyItem(): BillItem {
  return { id: uid('it'), desc: '', hsn: '', qty: 0, unit: 'PCS', rate: 0, gst: 18, discPct: 0 };
}

/** legacy/imported bills may carry items without ids or numeric junk — coerce defensively */
function normalizeItems(list: BillItem[] | undefined): BillItem[] {
  if (!list?.length) return [emptyItem()];
  return list.map((raw) => {
    const o = raw as Record<string, unknown>;
    const n = (v: unknown, d = 0) => {
      const x = Number(v);
      return Number.isFinite(x) ? x : d;
    };
    return {
      ...o,
      id: typeof o.id === 'string' && o.id ? o.id : uid('it'),
      desc: String(o.desc ?? o.description ?? ''),
      hsn: String(o.hsn ?? ''),
      qty: n(o.qty),
      unit: String(o.unit ?? 'PCS'),
      rate: n(o.rate),
      gst: n(o.gst, 18),
      discPct: Math.max(0, Math.min(100, n(o.discPct, 0))),
    } as BillItem;
  });
}

export default function CreateBillView({
  templates,
  settings,
  customVars,
  buyers,
  bills,
  catalogItems = [],
  initialItem,
  onReloadCatalog,
  editBill,
  duplicateFrom,
  initialTemplateId,
  onSaved,
  onPrint,
  onBack,
}: Props) {
  const { toast } = useToast();
  const [templateId, setTemplateId] = useState<string>(
    editBill?.templateId ?? duplicateFrom?.templateId ?? initialTemplateId ?? templates[0]?.id ?? '',
  );
  const [billNo, setBillNo] = useState(editBill?.billNo ?? duplicateFrom?.billNo ?? nextBillNo(settings));
  const [date, setDate] = useState(editBill?.date ?? duplicateFrom?.date ?? todayISO());
  const [vars, setVars] = useState<Record<string, string>>(editBill?.variables ?? duplicateFrom?.variables ?? {});
  const [items, setItems] = useState<BillItem[]>(() => {
    if (editBill?.items?.length) return normalizeItems(editBill.items);
    if (duplicateFrom?.items?.length) return normalizeItems(duplicateFrom.items);
    if (initialItem) {
      return [{
        id: uid('it'),
        desc: initialItem.name,
        hsn: initialItem.hsn || '',
        qty: 1,
        unit: initialItem.unit || 'PCS',
        rate: initialItem.rate,
        gst: initialItem.gst,
        discPct: 0,
      }];
    }
    return [emptyItem()];
  });
  const [discountPct, setDiscountPct] = useState(editBill?.discountPct ?? duplicateFrom?.discountPct ?? 0);
  const [notes, setNotes] = useState(editBill?.notes ?? duplicateFrom?.notes ?? '');
  const [payStatus, setPayStatus] = useState<BillStatus>(editBill?.status ?? 'unpaid');
  const [docType, setDocType] = useState<DocType>(editBill?.docType ?? duplicateFrom?.docType ?? 'invoice');
  const [repeat, setRepeat] = useState<RepeatCadence>(editBill?.repeat ?? duplicateFrom?.repeat ?? 'none');
  const [repeatEnd, setRepeatEnd] = useState<string>(editBill?.repeatEndDate ?? duplicateFrom?.repeatEndDate ?? '');
  const [copies, setCopies] = useState(1);
  const [saving, setSaving] = useState(false);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [saveBuyerToList, setSaveBuyerToList] = useState(true);
  /** id of a bill created during this session — switches the form into update mode after the first save */
  const [savedId, setSavedId] = useState<string | null>(editBill?.id ?? null);

  const initialBuyer = buyers.find((b) => b.name.toLowerCase() === (vars['buyer_name'] ?? '').toLowerCase());
  const [selectedBuyerId, setSelectedBuyerId] = useState<string>(initialBuyer?.id ?? '');
  const [buyerDropdownOpen, setBuyerDropdownOpen] = useState(false);
  const buyerDropdownRef = useRef<HTMLDivElement>(null);

  const [activeItemDropdownId, setActiveItemDropdownId] = useState<string | null>(null);
  const [savingCatalogName, setSavingCatalogName] = useState<string | null>(null);
  const itemsContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (buyerDropdownRef.current && !buyerDropdownRef.current.contains(e.target as Node)) {
        setBuyerDropdownOpen(false);
      }
      if (itemsContainerRef.current && !itemsContainerRef.current.contains(e.target as Node)) {
        setActiveItemDropdownId(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const template = templates.find((t) => t.id === templateId) ?? null;

  const totals = useMemo(() => computeTotals(items, discountPct, settings.interState), [items, discountPct, settings.interState]);
  const words = useMemo(() => amountInWords(totals.grandTotal), [totals.grandTotal]);
  const previewPages = useMemo(
    () => (template ? paginateTemplate(template, items.length).length : 1),
    [template, items.length],
  );
  const isRoll = !!template?.page.autoHeight;
  const rollLength = useMemo(
    () => (template && template.page.autoHeight ? Math.round(effectivePageHeight(template, items.length)) : 0),
    [template, items.length],
  );

  const buyerVars = useMemo(() => buyerCustomVarDefs(settings.buyerFields), [settings.buyerFields]);
  const varDefs = useMemo(() => [...BUILTIN_BILL_VARS, ...buyerVars, ...customVars], [customVars, buyerVars]);

  // custom item columns defined by the template's table
  const customCols = useMemo(() => {
    if (!template) return [];
    const known = new Set(['sr', 'desc', 'hsn', 'qty', 'unit', 'rate', 'disc', 'gst', 'amount']);
    const keys = new Set<string>();
    for (const el of template.elements) {
      if (el.type === 'table') for (const c of el.columns ?? []) if (!known.has(c.key)) keys.add(c.key);
    }
    return Array.from(keys);
  }, [template]);

  const [previewRef, previewScale] = useFitScale(template?.page.width ?? 210);

  const setVar = (k: string, v: string) => setVars((s) => ({ ...s, [k]: v }));

  /** map a saved Buyer record → the buyer_* variables (including custom fields) */
  const buyerToVars = (b: Buyer): Record<string, string> => {
    const out: Record<string, string> = {
      buyer_name: b.name,
      buyer_address: b.address,
      buyer_gst: b.gst,
      buyer_phone: b.phone,
      buyer_state: b.state,
    };
    for (const f of settings.buyerFields ?? []) out[`buyer_${f.key}`] = b.custom?.[f.key] ?? '';
    return out;
  };

  const selectBuyer = (b: Buyer) => {
    setVars((s) => ({ ...s, ...buyerToVars(b) }));
    setSelectedBuyerId(b.id);
    setBuyerDropdownOpen(false);
    toast({ title: 'Buyer loaded', description: `${b.name}${b.gst ? ` · ${b.gst}` : ''}` });
  };

  const filteredBuyers = useMemo(() => {
    const q = (vars['buyer_name'] ?? '').trim().toLowerCase();
    if (!q) return buyers;
    return buyers.filter(
      (b) =>
        b.name.toLowerCase().includes(q) ||
        (b.gst && b.gst.toLowerCase().includes(q)) ||
        (b.phone && b.phone.includes(q)) ||
        (b.address && b.address.toLowerCase().includes(q)),
    );
  }, [buyers, vars['buyer_name']]);

  /** autofill buyer fields from saved buyers or from the most recent bill of the same buyer */
  const autofillBuyer = (name: string) => {
    if (!name.trim()) return;
    const q = name.trim().toLowerCase();
    // 1. Check saved buyers directory first
    const saved = buyers.find((b) => b.name.trim().toLowerCase() === q);
    if (saved) {
      setVars((s) => ({ ...s, ...buyerToVars(saved) }));
      setSelectedBuyerId(saved.id);
      toast({ title: 'Buyer details filled', description: `Loaded from saved buyer: ${saved.name}` });
      return;
    }
    // 2. Check past bills
    const match = bills
      .filter((b) => (b.variables['buyer_name'] ?? '').trim().toLowerCase() === q)
      .sort((a, b) => (a.date < b.date ? 1 : -1))[0];
    if (!match) return;
    setVars((s) => {
      const next = { ...s, buyer_name: name };
      for (const d of [...BUILTIN_BILL_VARS, ...buyerVars]) {
        if (d.key === 'buyer_name') continue;
        next[d.key] = s[d.key] || match.variables[d.key] || '';
      }
      return next;
    });
    toast({ title: 'Buyer details filled', description: `Pulled from ${match.billNo}` });
  };

  const updateItem = (id: string, patch: Partial<BillItem>) =>
    setItems((list) => list.map((it) => (it.id === id ? { ...it, ...patch } : it)));

  const selectCatalogItem = (rowId: string, ci: ItemRecord) => {
    setItems((list) =>
      list.map((row) => {
        if (row.id !== rowId) return row;
        return {
          ...row,
          desc: ci.name,
          hsn: ci.hsn || '',
          unit: ci.unit || 'PCS',
          rate: ci.rate,
          gst: ci.gst,
          qty: row.qty && row.qty > 0 ? row.qty : 1,
        };
      }),
    );
    setActiveItemDropdownId(null);
    toast({
      title: 'Item loaded from catalog',
      description: `${ci.name} · Unit: ${ci.unit || 'PCS'} · Rate: ${ci.rate} · GST: ${ci.gst}%`,
    });
  };

  const saveItemToCatalog = async (item: BillItem) => {
    const name = item.desc.trim();
    if (!name) return;
    setSavingCatalogName(name);
    try {
      const res = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          hsn: item.hsn || '',
          unit: item.unit || 'PCS',
          rate: item.rate || 0,
          gst: item.gst || 0,
        }),
      });
      if (!res.ok) throw new Error();
      toast({
        title: 'Saved to Catalog',
        description: `"${name}" added to master catalog.`,
      });
      onReloadCatalog?.();
    } catch {
      toast({
        title: 'Could not save item to catalog',
        variant: 'destructive',
      });
    } finally {
      setSavingCatalogName(null);
    }
  };

  const buildBill = (): Bill => ({
    id: savedId ?? editBill?.id ?? uid('bill'),
    billNo: billNo.trim(),
    date,
    templateId: templateId,
    templateName: template?.name ?? '',
    variables: vars,
    items,
    discountPct,
    totals,
    amountInWords: words,
    notes,
    printCount: editBill?.printCount ?? 0,
    docType,
    repeat: docType === 'invoice' ? repeat : 'none',
    repeatEndDate: docType === 'invoice' && repeat !== 'none' && repeatEnd ? repeatEnd : undefined,
    // payment lifecycle only applies to tax invoices
    status: docType === 'invoice' ? payStatus : 'unpaid',
    paidAt: docType === 'invoice' && payStatus === 'paid' ? (editBill?.paidAt ?? new Date().toISOString()) : undefined,
    payments: docType === 'invoice' ? editBill?.payments : undefined,
    createdAt: editBill?.createdAt ?? new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  const validate = (): string | null => {
    if (!template) return 'Select a template first.';
    if (!billNo.trim()) return 'Bill number is required.';
    if (items.length === 0) return 'Add at least one item.';
    if (items.every((it) => !it.desc.trim())) return 'Fill in at least one item description.';
    return null;
  };

  const doSave = async (thenPrint: boolean): Promise<Bill | null> => {
    const err = validate();
    if (err) {
      toast({ title: 'Cannot save bill', description: err, variant: 'destructive' });
      return null;
    }
    setSaving(true);
    try {
      const bill = buildBill();
      const existingId = editBill?.id ?? savedId ?? null;
      const res = await fetch(existingId ? `/api/bills/${existingId}` : '/api/bills', {
        method: existingId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bill),
      });
      if (!res.ok) throw new Error('save failed');
      const saved = (await res.json()) as Bill;
      if (!existingId) setSavedId(saved.id); // further saves update this bill
      onSaved(saved);
      // keep the buyer directory fresh (upsert by name)
      const buyerName = vars['buyer_name']?.trim();
      if (buyerName && saveBuyerToList) {
        fetch('/api/buyers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: buyerName,
            address: vars['buyer_address'] ?? '',
            gst: vars['buyer_gst'] ?? '',
            phone: vars['buyer_phone'] ?? '',
            state: vars['buyer_state'] ?? '',
            custom: Object.fromEntries(
              (settings.buyerFields ?? []).map((f) => [f.key, vars[`buyer_${f.key}`] ?? '']),
            ),
          }),
        }).catch(() => undefined);
      }
      toast({
        title: editBill ? 'Bill updated' : 'Bill saved',
        description: `${saved.billNo} · ${settings.currency}${saved.totals.grandTotal.toFixed(2)}`,
      });
      if (thenPrint) {
        if (template) onPrint(template, saved, copies);
      }
      return saved;
    } catch {
      toast({ title: 'Save failed', description: 'Could not save the bill.', variant: 'destructive' });
      return null;
    } finally {
      setSaving(false);
    }
  };

  /** reset the form for the next bill (after a fresh save) */
  const startNext = () => {
    const next = nextBillNo(settings);
    setSavedId(null);
    setBillNo(next);
    setVars({});
    setItems([emptyItem()]);
    setDiscountPct(0);
    setNotes('');
    setPayStatus('unpaid');
    setDocType('invoice');
    setRepeat('none');
    setRepeatEnd('');
    toast({ title: 'Ready for the next bill', description: `Bill number ${next}` });
  };

  /** server-side PDF export — the bill must be saved first (it renders from the store) */
  const exportPdf = async () => {
    const id = savedId ?? editBill?.id;
    if (!id) {
      toast({ title: 'Save the bill first', description: 'PDF export renders the saved document from the store.', variant: 'destructive' });
      return;
    }
    setPdfBusy(true);
    try {
      await downloadPdf({ kind: 'bill', billId: id, copies }, `${billNo.trim() || 'bill'}.pdf`);
      toast({ title: 'PDF downloaded', description: `${billNo.trim()} · exact ${template?.page.sizeName ?? ''} layout` });
    } catch (e) {
      toast({ title: 'PDF export failed', description: e instanceof Error ? e.message : undefined, variant: 'destructive' });
    } finally {
      setPdfBusy(false);
    }
  };

  if (templates.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-10 text-center">
        <p className="text-sm text-zinc-400">No templates yet.</p>
        <Button className="bg-[#d9a13b] text-black hover:bg-[#e5b055]" onClick={onBack}>
          <ArrowLeft className="mr-1 h-4 w-4" /> Go to Templates & create your first design
        </Button>
      </div>
    );
  }

  const buyerNames = useMemo(
    () =>
      Array.from(
        new Set(
          [
            ...buyers.map((b) => b.name),
            ...bills.map((b) => b.variables['buyer_name']),
          ].filter((n): n is string => !!n?.trim()),
        ),
      ),
    [buyers, bills],
  );

  return (
    <div className="flex h-full min-h-0 flex-1">
      {/* ---------------- left: form ---------------- */}
      <div className="studio-scroll flex-1 overflow-y-auto p-5">
        <div className="mx-auto max-w-3xl space-y-5">
          {/* bill meta */}
          <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Bill Details</h2>
              <div className="flex items-center gap-2">
                <Label className="text-[10px] text-zinc-500">Template</Label>
                <Select
                  value={templateId}
                  onValueChange={(v) => setTemplateId(v)}
                  disabled={!!editBill}
                >
                  <SelectTrigger className="h-8 w-56 border-[#2a3342] bg-[#0d1117] text-xs">
                    <SelectValue placeholder="Choose template" />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {templates.map((t) => (
                      <SelectItem key={t.id} value={t.id} className="text-xs">
                        {t.name} · {t.page.sizeName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Document type</Label>
                <Select value={docType} onValueChange={(v) => setDocType(v as DocType)}>
                  <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    <SelectItem value="invoice" className="text-xs">Tax Invoice</SelectItem>
                    <SelectItem value="proforma" className="text-xs">Proforma Invoice</SelectItem>
                    <SelectItem value="quotation" className="text-xs">Quotation</SelectItem>
                    <SelectItem value="challan" className="text-xs">Delivery Challan</SelectItem>
                    <SelectItem value="creditnote" className="text-xs">Credit Note</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Bill No *</Label>
                <Input className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]" value={billNo} onChange={(e) => setBillNo(e.target.value)} />
              </div>
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Date *</Label>
                <Input type="date" className="mt-1 h-9 border-[#2a3342] bg-[#0d1117]" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div>
                <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Copies to print</Label>
                <Select value={String(copies)} onValueChange={(v) => setCopies(Number(v))}>
                  <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    {[1, 2, 3].map((n) => (
                      <SelectItem key={n} value={String(n)} className="text-xs">
                        {n} {n === 1 ? '(Original)' : n === 2 ? '(+ Duplicate)' : '(+ Triplicate)'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </section>

          {/* credit-note linkage */}
          {docType === 'creditnote' && (
            <section className="rounded-lg border border-rose-500/25 bg-rose-500/[0.04] p-4">
              <div className="mb-3 flex items-center justify-between gap-3">
                <h2 className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-rose-300">
                  <ArrowRightLeft className="h-3.5 w-3.5" /> Against Invoice
                </h2>
                <span className="text-[10px] text-zinc-500">links this credit note to the invoice it adjusts — available as <code className="font-mono text-[9px]">{'{{ref_invoice_no}}'}</code></span>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Reference invoice</Label>
                  <Select
                    value={vars['ref_invoice_no'] ?? '__none'}
                    onValueChange={(v) => setVar('ref_invoice_no', v === '__none' ? '' : v)}
                  >
                    <SelectTrigger className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-xs">
                      <SelectValue placeholder="Pick an invoice…" />
                    </SelectTrigger>
                    <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                      <SelectItem value="__none" className="text-xs text-zinc-500">— none —</SelectItem>
                      {bills
                        .filter((b) => docTypeOf(b) === 'invoice')
                        .sort((a, b) => (a.date < b.date ? 1 : -1))
                        .map((b) => (
                          <SelectItem key={b.id} value={b.billNo} className="text-xs">
                            <span className="font-mono">{b.billNo}</span>
                            <span className="ml-1.5 text-zinc-500">{b.variables['buyer_name'] ?? ''} · {fmtMoney(b.totals.grandTotal, settings.currency)}</span>
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-[10px] uppercase tracking-wider text-zinc-500">Reason / adjustment note</Label>
                  <Input
                    className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm"
                    placeholder="e.g. Damaged goods returned"
                    value={vars['credit_reason'] ?? ''}
                    onChange={(e) => setVar('credit_reason', e.target.value)}
                  />
                </div>
              </div>
            </section>
          )}

          {/* variables form */}
          <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                Buyer & Variables
              </h2>
              <div className="flex items-center gap-2">
                <Label className="shrink-0 text-[10px] uppercase tracking-wider text-zinc-500">Saved buyer</Label>
                <Select
                  value={selectedBuyerId || '__none'}
                  onValueChange={(v) => {
                    if (v === '__none') {
                      setSelectedBuyerId('');
                      return;
                    }
                    const b = buyers.find((x) => x.id === v);
                    if (!b) return;
                    selectBuyer(b);
                  }}
                >
                  <SelectTrigger className="h-8 w-56 border-[#2a3342] bg-[#0d1117] text-xs cursor-pointer">
                    <SelectValue placeholder={buyers.length ? `${buyers.length} saved — pick…` : 'No saved buyers yet'} />
                  </SelectTrigger>
                  <SelectContent className="border-[#2a3342] bg-[#12161d] text-zinc-200">
                    <SelectItem value="__none" className="text-xs text-zinc-500">— None / Custom —</SelectItem>
                    {buyers.map((b) => (
                      <SelectItem key={b.id} value={b.id} className="text-xs cursor-pointer">
                        <span className="font-medium text-zinc-100">{b.name}</span>
                        {b.gst ? <span className="ml-1.5 font-mono text-[10px] text-[#d9a13b]">{b.gst}</span> : null}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {varDefs.map((d) => (
                <div key={d.key} className={d.key === 'buyer_address' ? 'sm:col-span-2' : ''}>
                  <Label className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-500">
                    {d.label}
                    <span className="font-mono text-[9px] normal-case text-zinc-700">{`{{${d.key}}}`}</span>
                  </Label>
                  {d.key === 'buyer_address' ? (
                    <Textarea
                      className="mt-1 min-h-[52px] border-[#2a3342] bg-[#0d1117] text-sm"
                      value={vars[d.key] ?? ''}
                      onChange={(e) => setVar(d.key, e.target.value)}
                    />
                  ) : d.key === 'buyer_name' ? (
                    <div className="relative" ref={buyerDropdownRef}>
                      <Input
                        type="text"
                        className="mt-1 h-9 pr-10 border-[#2a3342] bg-[#0d1117] text-sm"
                        value={vars[d.key] ?? ''}
                        placeholder="Type or pick a buyer…"
                        autoComplete="off"
                        onChange={(e) => {
                          setVar(d.key, e.target.value);
                          setBuyerDropdownOpen(true);
                          const matching = buyers.find((b) => b.name.toLowerCase() === e.target.value.trim().toLowerCase());
                          setSelectedBuyerId(matching?.id ?? '');
                        }}
                        onFocus={() => {
                          if (buyers.length > 0) setBuyerDropdownOpen(true);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') setBuyerDropdownOpen(false);
                        }}
                        onBlur={(e) => autofillBuyer(e.target.value)}
                      />
                      <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center">
                        {buyers.length > 0 && (
                          <button
                            type="button"
                            tabIndex={-1}
                            onClick={() => setBuyerDropdownOpen((o) => !o)}
                            className="flex h-7 w-7 cursor-pointer items-center justify-center rounded text-zinc-400 hover:bg-[#1a222e] hover:text-[#d9a13b] transition-colors"
                            title="Toggle saved buyers list"
                          >
                            <ChevronDown className={`h-4 w-4 transition-transform duration-150 ${buyerDropdownOpen ? 'rotate-180 text-[#d9a13b]' : ''}`} />
                          </button>
                        )}
                      </div>

                      {buyerDropdownOpen && (
                        <div className="no-scrollbar absolute left-0 right-0 top-full z-50 mt-1 max-h-64 overflow-y-auto rounded-lg border border-[#2a3342] bg-[#12161d] p-1 shadow-2xl [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                          <div className="flex items-center justify-between px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-zinc-500 border-b border-[#1f2633] mb-1">
                            <span>Saved Buyers ({filteredBuyers.length})</span>
                            <span className="text-[9px] font-normal lowercase text-zinc-600">click to auto-fill</span>
                          </div>
                          {filteredBuyers.length === 0 ? (
                            <div className="px-3 py-2 text-xs text-zinc-500">
                              No matching buyers found. Keep typing to use &ldquo;{vars['buyer_name']}&rdquo;.
                            </div>
                          ) : (
                            filteredBuyers.map((b) => (
                              <button
                                key={b.id}
                                type="button"
                                onMouseDown={(e) => {
                                  e.preventDefault();
                                  selectBuyer(b);
                                }}
                                className="group flex w-full cursor-pointer items-start justify-between gap-2 rounded px-2.5 py-2 text-left text-xs transition-colors hover:bg-[#1a2330]"
                              >
                                <div className="min-w-0 flex-1">
                                  <div className="font-semibold text-zinc-100 group-hover:text-[#e8c064] transition-colors">
                                    {b.name}
                                  </div>
                                  {(b.address || b.phone) && (
                                    <div className="mt-0.5 truncate text-[11px] text-zinc-400">
                                      {[b.address?.split('\n')[0], b.phone].filter(Boolean).join(' · ')}
                                    </div>
                                  )}
                                </div>
                                {b.gst && (
                                  <span className="shrink-0 rounded bg-[#d9a13b]/10 px-1.5 py-0.5 font-mono text-[10px] text-[#e8c064]">
                                    {b.gst}
                                  </span>
                                )}
                              </button>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="relative">
                      <Input
                        type={d.type === 'number' ? 'number' : d.type === 'date' ? 'date' : 'text'}
                        className="mt-1 h-9 border-[#2a3342] bg-[#0d1117] text-sm"
                        value={vars[d.key] ?? ''}
                        onChange={(e) => setVar(d.key, e.target.value)}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* items editor */}
          <section className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                Items · {items.length}
              </h2>
              <Button size="sm" variant="outline" className="h-8 gap-1 border-[#2a3342] text-xs" onClick={() => setItems((l) => [...l, emptyItem()])}>
                <Plus className="h-3.5 w-3.5" /> Add item
              </Button>
            </div>
            <div className="studio-scroll overflow-x-auto min-h-[220px] pb-32" ref={itemsContainerRef}>
              <table className="w-full min-w-[840px] text-sm">
                <thead>
                  <tr className="border-b border-[#232b38] text-left text-[10px] uppercase tracking-wider text-zinc-500">
                    <th className="w-8 py-2 pr-2 font-medium">#</th>
                    <th className="py-2 pr-2 font-medium min-w-[220px]">Description</th>
                    <th className="w-20 py-2 pr-2 font-medium">HSN</th>
                    <th className="w-20 py-2 pr-2 font-medium">Qty</th>
                    <th className="w-20 py-2 pr-2 font-medium">Unit</th>
                    <th className="w-28 py-2 pr-2 font-medium">Rate</th>
                    <th className="w-16 py-2 pr-2 font-medium">Disc%</th>
                    <th className="w-16 py-2 pr-2 font-medium">GST%</th>
                    {customCols.map((c) => (
                      <th key={c} className="w-24 py-2 pr-2 font-medium">{c}</th>
                    ))}
                    <th className="w-28 py-2 pr-2 text-right font-medium">Amount</th>
                    <th className="w-8" />
                  </tr>
                </thead>
                <tbody>
                  {items.map((it, i) => {
                    const itemDescQuery = (it.desc ?? '').trim().toLowerCase();
                    const matchingCatalog = catalogItems.filter(
                      (ci) =>
                        !itemDescQuery ||
                        ci.name.toLowerCase().includes(itemDescQuery) ||
                        (ci.hsn && ci.hsn.toLowerCase().includes(itemDescQuery)),
                    );
                    const isLinkedToCatalog = catalogItems.some(
                      (ci) => ci.name.trim().toLowerCase() === itemDescQuery,
                    );

                    return (
                      <tr key={it.id || `row-${i}`} className="border-b border-[#1a212c] hover:bg-[#151b25]">
                        <td className="tabular py-1.5 pr-2 text-xs text-zinc-500">{i + 1}</td>
                        <td className="py-1.5 pr-2 relative min-w-[220px]">
                          <div className="relative flex items-center">
                            <Input
                              className={`h-8 border-[#2a3342] bg-[#0d1117] text-sm ${
                                isLinkedToCatalog ? 'pl-7 border-[#d9a13b]/40 focus:border-[#d9a13b]' : ''
                              } ${catalogItems.length > 0 ? 'pr-7' : ''}`}
                              value={it.desc}
                              placeholder="Type or pick an item…"
                              autoComplete="off"
                              onChange={(e) => {
                                updateItem(it.id, { desc: e.target.value });
                                setActiveItemDropdownId(it.id);
                              }}
                              onFocus={() => {
                                if (catalogItems.length > 0) setActiveItemDropdownId(it.id);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Escape') setActiveItemDropdownId(null);
                              }}
                            />

                            {/* Badge/icon if item matches catalog */}
                            {isLinkedToCatalog && (
                              <span
                                className="pointer-events-none absolute left-2 text-[#d9a13b]"
                                title="Catalog item: description, HSN, and GST linked. Rate & Qty can be tailored per bill."
                              >
                                <Package className="h-3.5 w-3.5" />
                              </span>
                            )}

                            {/* Quick toggle dropdown chevron */}
                            {catalogItems.length > 0 && (
                              <button
                                type="button"
                                tabIndex={-1}
                                onClick={() => setActiveItemDropdownId((cur) => (cur === it.id ? null : it.id))}
                                className="absolute right-1 text-zinc-500 hover:text-[#d9a13b] p-1 rounded transition-colors cursor-pointer"
                                title="Browse catalog items"
                              >
                                <ChevronDown
                                  className={`h-3.5 w-3.5 transition-transform duration-150 ${
                                    activeItemDropdownId === it.id ? 'rotate-180 text-[#d9a13b]' : ''
                                  }`}
                                />
                              </button>
                            )}
                          </div>

                          {/* Quick "+ Save to Catalog" pill if custom item is typed */}
                          {!isLinkedToCatalog && it.desc.trim().length >= 2 && (
                            <div className="mt-1 flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => saveItemToCatalog(it)}
                                disabled={savingCatalogName === it.desc.trim()}
                                className="inline-flex items-center gap-1 rounded bg-[#1b232f] px-1.5 py-0.5 text-[10px] font-medium text-zinc-400 hover:bg-[#253041] hover:text-[#d9a13b] transition-colors cursor-pointer disabled:opacity-50"
                                title="Save this new item to master catalog"
                              >
                                <BookmarkPlus className="h-3 w-3 text-[#d9a13b]" />
                                <span>{savingCatalogName === it.desc.trim() ? 'Saving…' : '+ Save to Catalog'}</span>
                              </button>
                            </div>
                          )}

                          {/* Autocomplete Dropdown */}
                          {activeItemDropdownId === it.id && (
                            <div className="no-scrollbar absolute left-0 top-full z-50 mt-1 w-80 max-h-60 overflow-y-auto rounded-lg border border-[#2a3342] bg-[#12161d] p-1 shadow-2xl [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                              <div className="flex items-center justify-between border-b border-[#1f2633] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                                <span>Catalog Items ({matchingCatalog.length})</span>
                                <span className="text-[9px] font-normal lowercase text-zinc-600">click to auto-fill</span>
                              </div>

                              {matchingCatalog.length === 0 ? (
                                <div className="px-3 py-2 text-xs text-zinc-500">
                                  No matching catalog items. Keep typing to use &ldquo;{it.desc}&rdquo;.
                                </div>
                              ) : (
                                matchingCatalog.map((ci) => (
                                  <button
                                    key={ci.id}
                                    type="button"
                                    onMouseDown={(e) => {
                                      e.preventDefault();
                                      selectCatalogItem(it.id, ci);
                                    }}
                                    className="group flex w-full cursor-pointer items-start justify-between gap-2 rounded px-2.5 py-2 text-left text-xs transition-colors hover:bg-[#1a2330]"
                                  >
                                    <div className="min-w-0 flex-1">
                                      <div className="font-semibold text-zinc-100 group-hover:text-[#e8c064] transition-colors flex items-center gap-1.5">
                                        <Package className="h-3 w-3 text-[#d9a13b] shrink-0" />
                                        <span className="truncate">{ci.name}</span>
                                      </div>
                                      <div className="mt-0.5 text-[11px] text-zinc-400 flex items-center gap-2">
                                        {ci.hsn && <span>HSN: {ci.hsn}</span>}
                                        <span>Unit: {ci.unit || 'PCS'}</span>
                                        <span>GST: {ci.gst}%</span>
                                      </div>
                                    </div>
                                    <div className="shrink-0 text-right">
                                      <span className="font-mono text-xs font-semibold text-zinc-200">
                                        {settings.currency}{ci.rate}
                                      </span>
                                    </div>
                                  </button>
                                ))
                              )}

                              {/* Option to save custom item into catalog directly from dropdown */}
                              {!isLinkedToCatalog && it.desc.trim().length >= 2 && (
                                <button
                                  type="button"
                                  onMouseDown={(e) => {
                                    e.preventDefault();
                                    saveItemToCatalog(it);
                                  }}
                                  disabled={savingCatalogName === it.desc.trim()}
                                  className="mt-1 flex w-full cursor-pointer items-center gap-1.5 rounded border-t border-[#1f2633] px-2.5 py-1.5 text-left text-xs text-[#d9a13b] hover:bg-[#1a2330] transition-colors disabled:opacity-50"
                                >
                                  <BookmarkPlus className="h-3.5 w-3.5" />
                                  <span>Save &ldquo;{it.desc.trim()}&rdquo; to Catalog</span>
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-1.5 pr-2">
                          <Input className="h-8 border-[#2a3342] bg-[#0d1117] text-sm" value={it.hsn} onChange={(e) => updateItem(it.id, { hsn: e.target.value })} />
                        </td>
                      <td className="py-1.5 pr-2">
                        <Input type="number" className="tabular h-8 border-[#2a3342] bg-[#0d1117] text-sm" value={it.qty} onChange={(e) => updateItem(it.id, { qty: Number(e.target.value) })} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <Input className="h-8 border-[#2a3342] bg-[#0d1117] text-sm" value={it.unit} onChange={(e) => updateItem(it.id, { unit: e.target.value })} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <Input type="number" className="tabular h-8 border-[#2a3342] bg-[#0d1117] text-sm" value={it.rate} onChange={(e) => updateItem(it.id, { rate: Number(e.target.value) })} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <Input
                          type="number"
                          className={`tabular h-8 border-[#2a3342] bg-[#0d1117] text-sm ${it.discPct ? 'text-amber-300' : ''}`}
                          value={it.discPct ?? 0}
                          min={0}
                          max={100}
                          title="Item-level discount percent"
                          onChange={(e) => updateItem(it.id, { discPct: Math.max(0, Math.min(100, Number(e.target.value))) })}
                        />
                      </td>
                      <td className="py-1.5 pr-2">
                        <Input type="number" className="tabular h-8 border-[#2a3342] bg-[#0d1117] text-sm" value={it.gst} onChange={(e) => updateItem(it.id, { gst: Number(e.target.value) })} />
                      </td>
                      {customCols.map((c) => (
                        <td key={c} className="py-1.5 pr-2">
                          <Input
                            className="h-8 border-[#2a3342] bg-[#0d1117] text-sm"
                            value={String(it[c] ?? '')}
                            onChange={(e) => updateItem(it.id, { [c]: e.target.value })}
                          />
                        </td>
                      ))}
                      <td className="tabular py-1.5 pr-2 text-right text-sm text-zinc-200">
                        {settings.currency}
                        {itemAmount(it).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        {(it.discPct ?? 0) > 0 && (
                          <span className="ml-1 text-[10px] text-zinc-600 line-through">
                            {(it.qty * it.rate).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        )}
                      </td>
                      <td className="py-1.5 text-center">
                        <button
                          type="button"
                          className="text-zinc-600 hover:text-red-400"
                          title="Remove item"
                          onClick={() => setItems((l) => l.filter((x) => x.id !== it.id))}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          {/* totals */}
          <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
              <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Notes</h2>
              <Textarea
                className="min-h-[64px] border-[#2a3342] bg-[#0d1117] text-sm"
                placeholder="Optional notes — available as {{notes}} in templates"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
              <label className="mt-3 flex cursor-pointer items-center gap-2 text-[11px] text-zinc-400">
                <input
                  type="checkbox"
                  className="h-3.5 w-3.5 accent-[#d9a13b]"
                  checked={saveBuyerToList}
                  onChange={(e) => setSaveBuyerToList(e.target.checked)}
                />
                Save buyer “{vars['buyer_name'] || '…'}” to the buyer list for reuse
              </label>
            </div>
            <div className="rounded-lg border border-[#232b38] bg-[#12161d] p-4">
              <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Totals</h2>
              <div className="space-y-1.5 text-sm">
                <Row label="Subtotal" value={`${settings.currency}${totals.subtotal.toFixed(2)}`} />
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Bill discount</span>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      className="tabular h-7 w-16 border-[#2a3342] bg-[#0d1117] text-xs"
                      value={discountPct}
                      min={0}
                      max={100}
                      onChange={(e) => setDiscountPct(Math.max(0, Math.min(100, Number(e.target.value))))}
                    />
                    <span className="text-xs text-zinc-500">%</span>
                    <span className="tabular w-24 text-right text-zinc-200">−{settings.currency}{totals.discount.toFixed(2)}</span>
                  </div>
                </div>
                <p className="-mt-0.5 text-[10px] text-zinc-600">includes per-item discounts · set Disc% per item above</p>
                <Row label="Taxable value" value={`${settings.currency}${totals.taxable.toFixed(2)}`} />
                {settings.interState ? (
                  <Row label="IGST" value={`${settings.currency}${totals.igst.toFixed(2)}`} />
                ) : (
                  <>
                    <Row label="CGST" value={`${settings.currency}${totals.cgst.toFixed(2)}`} />
                    <Row label="SGST" value={`${settings.currency}${totals.sgst.toFixed(2)}`} />
                  </>
                )}
                <Row label="Round off" value={totals.roundOff.toFixed(2)} />
                <Separator className="my-2 bg-[#232b38]" />
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-zinc-100">GRAND TOTAL</span>
                  <span className="tabular text-lg font-bold text-[#d9a13b]">
                    {settings.currency}{totals.grandTotal.toFixed(2)}
                  </span>
                </div>
                <p className="pt-1 text-[11px] italic text-zinc-500">{words}</p>
              </div>
            </div>
          </section>

          {/* actions */}
          <div className="sticky bottom-0 flex flex-wrap items-center gap-2 border-t border-[#232b38] bg-[#0b0e13]/95 py-3 backdrop-blur">
            {savedId && !editBill && (
              <span className="mr-auto flex items-center gap-2 text-[11px] text-zinc-500">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Saved — further changes will update this bill
              </span>
            )}
            {savedId && !editBill && (
              <Button variant="outline" className="h-9 gap-1.5 border-[#2a3342] text-sm" onClick={startNext}>
                <Plus className="h-4 w-4" /> Start next bill
              </Button>
            )}
            <div className="flex h-9 items-center gap-2 rounded-md border border-[#2a3342] bg-[#0d1117] px-2">
              <span className="text-[10px] uppercase tracking-wider text-zinc-500">Payment</span>
              {docType === 'invoice' ? (
                <select
                  className="bg-transparent text-xs font-semibold text-zinc-200 outline-none"
                  value={payStatus}
                  onChange={(e) => setPayStatus(e.target.value as BillStatus)}
                  aria-label="Payment status"
                >
                  <option value="unpaid" className="bg-[#12161d]">Unpaid</option>
                  <option value="paid" className="bg-[#12161d]">Paid</option>
                  <option value="cancelled" className="bg-[#12161d]">Cancelled</option>
                </select>
              ) : (
                <span className="text-[10px] italic text-zinc-600">n/a — {docType === 'proforma' ? 'estimate' : docType === 'quotation' ? 'estimate' : docType === 'challan' ? 'challan' : 'adjustment'}</span>
              )}
            </div>
            {docType === 'invoice' && (
              <div
                className={`flex h-9 items-center gap-1.5 rounded-md border px-2.5 ${
                  repeat !== 'none'
                    ? 'border-[#d9a13b]/60 bg-[#d9a13b]/15'
                    : 'border-[#2a3342] bg-[#0d1117]'
                }`}
                title="Flag this invoice as recurring — the dashboard nags you when the next copy is due"
              >
                <CalendarSync className={`h-3.5 w-3.5 ${repeat !== 'none' ? 'text-[#e8b954]' : 'text-zinc-500'}`} />
                <select
                  className={`bg-transparent text-xs font-semibold outline-none ${
                    repeat !== 'none' ? 'text-[#e8b954]' : 'text-zinc-400'
                  }`}
                  value={repeat}
                  onChange={(e) => setRepeat(e.target.value as RepeatCadence)}
                  aria-label="Recurring cadence"
                >
                  <option value="none" className="bg-[#12161d]">One-off</option>
                  <option value="weekly" className="bg-[#12161d]">Weekly</option>
                  <option value="monthly" className="bg-[#12161d]">Monthly</option>
                  <option value="yearly" className="bg-[#12161d]">Yearly</option>
                </select>
                {repeat !== 'none' && (
                  <input
                    type="date"
                    className="ml-1 w-32 border-l border-[#d9a13b]/30 bg-transparent pl-2 text-[10px] text-zinc-300 outline-none"
                    value={repeatEnd}
                    aria-label="Repeat until (optional end date)"
                    title="Repeat until — the chain stops creating copies after this date (optional)"
                    onChange={(e) => setRepeatEnd(e.target.value)}
                  />
                )}
              </div>
            )}
            <Button variant="outline" className="h-9 gap-1.5 border-[#2a3342] text-sm" disabled={saving} onClick={() => doSave(false)}>
              <Save className="h-4 w-4" /> {editBill || savedId ? 'Update bill' : 'Save bill'}
            </Button>
            <Button
              variant="outline"
              className="h-9 gap-1.5 border-sky-500/40 text-sm text-sky-300 hover:bg-sky-500/10"
              disabled={saving || pdfBusy}
              title="Download PDF — renders the saved bill with headless Chromium at the exact page size (QR, barcodes & stamps included)"
              onClick={exportPdf}
            >
              <FileDown className={`h-4 w-4 ${pdfBusy ? 'animate-pulse' : ''}`} /> PDF
            </Button>
            <Button className="h-9 gap-1.5 bg-[#d9a13b] text-sm font-semibold text-black hover:bg-[#e5b055]" disabled={saving} onClick={() => doSave(true)}>
              <Printer className="h-4 w-4" /> Save & Print
            </Button>
          </div>
        </div>
      </div>

      {/* ---------------- right: live preview ---------------- */}
      <div className="hidden w-[42%] max-w-[640px] shrink-0 flex-col border-l border-[#232b38] bg-[#0d1015] lg:flex">
        <div className="flex h-9 shrink-0 items-center justify-between border-b border-[#232b38] bg-[#0f1319] px-4">
          <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">Live Preview</span>
          <span className="text-[10px] text-zinc-600">{template?.name ?? '—'}</span>
        </div>
        <div ref={previewRef} className="studio-scroll min-h-0 flex-1 overflow-auto p-6">
          {template && (
            <div>
              <BillPreview
                template={template}
                bill={buildBill()}
                settings={settings}
                scale={previewScale}
                multiPage
                showStatusStamp={docType === 'invoice' && settings.statusStamp !== false}
                className="mx-auto"
              />
              <p className="mt-3 text-center text-[10px] text-zinc-600">
                {isRoll
                  ? `Continuous ${template?.page.width ?? 80}mm roll — content ≈ ${rollLength}mm at ${items.length} item${items.length === 1 ? '' : 's'}`
                  : items.length > 0 && previewPages > 1
                    ? `${previewPages} pages — continuation pages repeat letterhead elements`
                    : 'Single page'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-zinc-400">{label}</span>
      <span className="tabular text-zinc-200">{value}</span>
    </div>
  );
}

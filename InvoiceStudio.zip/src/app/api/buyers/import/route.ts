import { NextRequest, NextResponse } from 'next/server';
import { mutateBuyers, sanitizeBuyerCustom } from '@/lib/studio/store';
import type { Buyer } from '@/lib/studio/types';
import { uid } from '@/lib/studio/format';
import { isValidGstin } from '@/lib/studio/csv';

export const dynamic = 'force-dynamic';

interface ImportRow {
  name?: string;
  address?: string;
  gst?: string;
  phone?: string;
  state?: string;
  /** extra values keyed by Settings.buyerFields keys — unknown keys are dropped server-side */
  custom?: Record<string, string>;
}

export interface ImportResult {
  created: number;
  updated: number;
  skipped: number;
  failed: number;
  errors: { row: number; name: string; reason: string }[];
}

const MAX_ROWS = 1000;

/**
 * POST /api/buyers/import
 * Body: { rows: ImportRow[], mode?: 'skip' | 'update' }
 *  - 'skip'   : existing buyers (matched by name, case-insensitive) are left untouched
 *  - 'update' : non-empty CSV fields overwrite the saved buyer's fields
 * Names are matched case-insensitively. All validation runs server-side too —
 * the client preview is a convenience, this is authoritative.
 */
export async function POST(req: NextRequest) {
  let body: { rows?: ImportRow[]; mode?: 'skip' | 'update' };
  try {
    body = (await req.json()) as { rows?: ImportRow[]; mode?: 'skip' | 'update' };
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const rows = Array.isArray(body.rows) ? body.rows : [];
  if (rows.length === 0) {
    return NextResponse.json({ error: 'No rows to import' }, { status: 400 });
  }
  if (rows.length > MAX_ROWS) {
    return NextResponse.json({ error: `Too many rows — limit is ${MAX_ROWS} per import` }, { status: 413 });
  }
  const mode = body.mode === 'update' ? 'update' : 'skip';

  const clean = await Promise.all(
    rows.map(async (r, i) => ({
      row: i + 1,
      name: (r.name ?? '').trim(),
      address: (r.address ?? '').trim(),
      gst: (r.gst ?? '').trim().toUpperCase(),
      phone: (r.phone ?? '').trim(),
      state: (r.state ?? '').trim(),
      custom: await sanitizeBuyerCustom(r.custom),
    })),
  );

  const errors: ImportResult['errors'] = [];
  const valid = clean.filter((r) => {
    if (!r.name) {
      errors.push({ row: r.row, name: r.name || '(blank)', reason: 'Buyer name is required' });
      return false;
    }
    if (r.name.length > 120) {
      errors.push({ row: r.row, name: r.name, reason: 'Name is too long (max 120 chars)' });
      return false;
    }
    if (r.gst && !isValidGstin(r.gst)) {
      errors.push({ row: r.row, name: r.name, reason: `Invalid GSTIN format: ${r.gst}` });
      return false;
    }
    return true;
  });

  // collapse duplicate names inside the file — last occurrence wins
  const byName = new Map<string, (typeof valid)[number]>();
  for (const r of valid) byName.set(r.name.toLowerCase(), r);

  let created = 0;
  let updated = 0;
  let skipped = 0;

  await mutateBuyers((list) => {
    const now = new Date().toISOString();
    const next = [...list];
    const indexByName = new Map<string, number>(); // list index by lowercased name
    next.forEach((b, i) => indexByName.set(b.name.trim().toLowerCase(), i));

    for (const r of byName.values()) {
      const idx = indexByName.get(r.name.toLowerCase());
      if (idx !== undefined) {
        if (mode === 'skip') { skipped++; continue; }
        const cur = next[idx];
        const merged: Buyer = {
          ...cur,
          // only overwrite with non-empty CSV values — blanks keep what's saved
          address: r.address || cur.address,
          gst: r.gst || cur.gst,
          phone: r.phone || cur.phone,
          state: r.state || cur.state,
          custom: Object.keys(r.custom).length > 0 ? { ...cur.custom, ...r.custom } : cur.custom,
          updatedAt: now,
        };
        next[idx] = merged;
        updated++;
      } else {
        const buyer: Buyer = {
          id: uid('byr'),
          name: r.name,
          address: r.address,
          gst: r.gst,
          phone: r.phone,
          state: r.state,
          custom: Object.keys(r.custom).length > 0 ? r.custom : undefined,
          createdAt: now,
          updatedAt: now,
        };
        indexByName.set(r.name.toLowerCase(), next.length);
        next.push(buyer);
        created++;
      }
    }
    return next;
  });

  const failed = clean.length - valid.length;
  return NextResponse.json({ created, updated, skipped, failed, errors } satisfies ImportResult);
}

import { NextResponse } from 'next/server';
import { csvRow } from '@/lib/studio/csv';

export const dynamic = 'force-dynamic';

/**
 * GET /api/buyers/sample
 * Downloadable sample CSV showing the exact bulk-import format.
 * Rows are realistic Indian examples; the last row shows optional
 * fields left blank. Users can edit this file directly.
 */
export async function GET() {
  const csv =
    csvRow(['name', 'address', 'gst', 'phone', 'state']) +
    csvRow(['Sharma Electronics', '12, MG Road, Bengaluru - 560001', '29ABCDE1234F1Z5', '9876543210', 'Karnataka']) +
    csvRow(['Mehta & Sons', '45/B, Ring Road, Surat - 395002', '24PQRSX5678G1Z2', '9822011223', 'Gujarat']) +
    csvRow(['Verma Traders', 'Shop 8, Main Bazaar, Jaipur - 302003', '08TUVAB9012H1Z9', '9414223344', 'Rajasthan']) +
    csvRow(['Krishna Enterprises', 'Plot 22, MIDC, Pune - 411019', '27LMNOP3456J1Z7', '9850123456', 'Maharashtra']) +
    csvRow(['Anand Hardware', '', '07AAECS1234K1Z5', '', 'Delhi']);

  return new NextResponse(`\uFEFF${csv}`, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="buyers-sample.csv"',
      'Cache-Control': 'no-store',
    },
  });
}

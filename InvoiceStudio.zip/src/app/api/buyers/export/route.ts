import { NextResponse } from 'next/server';
import { getSettings, listBuyers } from '@/lib/studio/store';
import { csvRow } from '@/lib/studio/csv';

export const dynamic = 'force-dynamic';

/**
 * GET /api/buyers/export
 * Export every saved buyer in the exact bulk-import CSV format —
 * canonical columns first, then one column per custom buyer field
 * (header = the field's label so a re-import maps it back automatically).
 */
export async function GET() {
  const [buyers, settings] = await Promise.all([listBuyers(), getSettings()]);
  const fields = settings.buyerFields ?? [];
  buyers.sort((a, b) => a.name.localeCompare(b.name));

  let csv = csvRow(['name', 'address', 'gst', 'phone', 'state', ...fields.map((f) => f.label)]);
  for (const b of buyers) {
    csv += csvRow([
      b.name,
      b.address,
      b.gst,
      b.phone,
      b.state,
      ...fields.map((f) => b.custom?.[f.key] ?? ''),
    ]);
  }

  return new NextResponse(`\uFEFF${csv}`, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="buyers-export-${new Date().toISOString().slice(0, 10)}.csv"`,
      'Cache-Control': 'no-store',
    },
  });
}

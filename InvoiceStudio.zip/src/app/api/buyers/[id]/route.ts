import { NextRequest, NextResponse } from 'next/server';
import { mutateBuyers, sanitizeBuyerCustom } from '@/lib/studio/store';
import type { Buyer } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<Buyer>;
  const custom = body.custom !== undefined ? await sanitizeBuyerCustom(body.custom) : undefined;
  const buyers = await mutateBuyers((list) =>
    list.map((b) =>
      b.id === id
        ? {
            ...b,
            ...body,
            ...(custom !== undefined ? { custom: Object.keys(custom).length > 0 ? custom : undefined } : {}),
            id: b.id,
            name: (body.name ?? b.name).trim() || b.name,
            createdAt: b.createdAt,
            updatedAt: new Date().toISOString(),
          }
        : b,
    ),
  );
  const out = buyers.find((b) => b.id === id);
  if (!out) return NextResponse.json({ error: 'Buyer not found' }, { status: 404 });
  return NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  let removed = false;
  await mutateBuyers((list) => {
    const next = list.filter((b) => b.id !== id);
    removed = next.length !== list.length;
    return next;
  });
  if (!removed) return NextResponse.json({ error: 'Buyer not found' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

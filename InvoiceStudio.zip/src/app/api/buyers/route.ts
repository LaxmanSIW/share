import { NextRequest, NextResponse } from 'next/server';
import { listBuyers, mutateBuyers, sanitizeBuyerCustom } from '@/lib/studio/store';
import type { Buyer } from '@/lib/studio/types';
import { uid } from '@/lib/studio/format';

export const dynamic = 'force-dynamic';

/** GET -> all saved buyers (name A-Z) */
export async function GET() {
  const buyers = await listBuyers();
  buyers.sort((a, b) => a.name.localeCompare(b.name));
  return NextResponse.json(buyers);
}

/** POST -> upsert buyer by name (used by Create Bill auto-save) */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as Partial<Buyer>;
  const name = (body.name ?? '').trim();
  if (!name) {
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  }
  const now = new Date().toISOString();
  const custom = await sanitizeBuyerCustom(body.custom);
  let createdFlag = false;
  const buyers = await mutateBuyers((list) => {
    const idx = list.findIndex((b) => b.name.toLowerCase() === name.toLowerCase());
    if (idx >= 0) {
      const merged: Buyer = {
        ...list[idx],
        address: body.address ?? list[idx].address,
        gst: body.gst ?? list[idx].gst,
        phone: body.phone ?? list[idx].phone,
        state: body.state ?? list[idx].state,
        // custom values merge per-key — non-empty overrides, blanks keep what's saved
        custom: Object.keys(custom).length > 0 ? { ...list[idx].custom, ...custom } : list[idx].custom,
        updatedAt: now,
      };
      return list.map((b, i) => (i === idx ? merged : b));
    }
    createdFlag = true;
    const buyer: Buyer = {
      id: uid('byr'),
      name,
      address: body.address ?? '',
      gst: body.gst ?? '',
      phone: body.phone ?? '',
      state: body.state ?? '',
      custom: Object.keys(custom).length > 0 ? custom : undefined,
      createdAt: now,
      updatedAt: now,
    };
    return [...list, buyer];
  });
  const saved = buyers.find((b) => b.name.toLowerCase() === name.toLowerCase());
  return NextResponse.json(saved, { status: createdFlag ? 201 : 200 });
}

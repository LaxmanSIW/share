import { NextRequest, NextResponse } from 'next/server';
import { getSettings, saveSettings, sanitizeBuyerFields } from '@/lib/studio/store';
import type { Settings } from '@/lib/studio/types';
import { DEFAULT_SETTINGS } from '@/lib/studio/defaults';

export const dynamic = 'force-dynamic';

export async function GET() {
  const settings = await getSettings();
  return NextResponse.json(settings);
}

export async function PUT(req: NextRequest) {
  const body = (await req.json()) as Partial<Settings>;
  const current = await getSettings();
  const next: Settings = {
    business: { ...DEFAULT_SETTINGS.business, ...current.business, ...(body.business ?? {}) },
    currency: body.currency ?? current.currency,
    interState: body.interState ?? current.interState,
    billNoPrefix: body.billNoPrefix ?? current.billNoPrefix,
    billNoNext: Number.isFinite(body.billNoNext) ? Number(body.billNoNext) : current.billNoNext,
    printOffsetX: Number.isFinite(body.printOffsetX) ? Number(body.printOffsetX) : (Number.isFinite(current.printOffsetX) ? current.printOffsetX : 0),
    printOffsetY: Number.isFinite(body.printOffsetY) ? Number(body.printOffsetY) : (Number.isFinite(current.printOffsetY) ? current.printOffsetY : 0),
    statusStamp: body.statusStamp ?? current.statusStamp ?? true,
    autoRecurring: body.autoRecurring ?? current.autoRecurring ?? false,
    buyerFields: body.buyerFields !== undefined ? sanitizeBuyerFields(body.buyerFields) : (current.buyerFields ?? []),
    customFonts: Array.isArray(body.customFonts) ? body.customFonts : (current.customFonts ?? []),
  };
  await saveSettings(next);
  return NextResponse.json(next);
}

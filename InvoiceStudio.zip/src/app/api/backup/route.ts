import { NextResponse } from 'next/server';
import { listBills, listBuyers, listItems, listTemplates, listVariables, getSettings, saveBills, saveBuyers, saveItems, saveTemplates, saveVariables, saveSettings } from '@/lib/studio/store';
import type { Bill, Buyer, ItemRecord, Settings, Template, VariableDef } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

interface BackupPayload {
  version: number;
  exportedAt: string;
  templates: Template[];
  bills: Bill[];
  variables: VariableDef[];
  settings: Settings;
  buyers: Buyer[];
  items?: ItemRecord[];
}

/** GET /api/backup — full snapshot of every JSON collection */
export async function GET() {
  try {
    const [templates, bills, variables, settings, buyers, items] = await Promise.all([
      listTemplates(),
      listBills(),
      listVariables(),
      getSettings(),
      listBuyers(),
      listItems(),
    ]);
    const payload: BackupPayload = {
      version: 1,
      exportedAt: new Date().toISOString(),
      templates,
      bills,
      variables,
      settings,
      buyers,
      items,
    };
    return new NextResponse(JSON.stringify(payload, null, 2), {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="invoicestudio-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: 'backup failed', detail: String(e) }, { status: 500 });
  }
}

/** POST /api/backup — restore a previously downloaded snapshot (overwrites all data) */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Partial<BackupPayload>;
    if (
      !Array.isArray(body.templates) ||
      !Array.isArray(body.bills) ||
      !Array.isArray(body.variables) ||
      !body.settings ||
      !Array.isArray(body.buyers)
    ) {
      return NextResponse.json({ error: 'invalid backup file' }, { status: 400 });
    }
    await Promise.all([
      saveTemplates(body.templates),
      saveBills(body.bills),
      saveVariables(body.variables),
      saveSettings(body.settings as Settings),
      saveBuyers(body.buyers),
      saveItems(Array.isArray(body.items) ? body.items : []),
    ]);
    return NextResponse.json({
      ok: true,
      counts: {
        templates: body.templates.length,
        bills: body.bills.length,
        variables: body.variables.length,
        buyers: body.buyers.length,
        items: Array.isArray(body.items) ? body.items.length : 0,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: 'restore failed', detail: String(e) }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { listBills } from '@/lib/studio/store';
import { billStatus, docTypeOf } from '@/lib/studio/format';

export const dynamic = 'force-dynamic';

function csvCell(v: string | number): string {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

interface MonthRow {
  month: string;
  bills: number;
  subtotal: number;
  discount: number;
  taxable: number;
  cgst: number;
  sgst: number;
  igst: number;
  roundOff: number;
  grand: number;
}

/** GET /api/reports/gst — month-wise GST summary (only TAX INVOICES; cancelled excluded) */
export async function GET() {
  try {
    const bills = (await listBills()).filter(
      (b) => billStatus(b) !== 'cancelled' && docTypeOf(b) === 'invoice',
    );

    const map = new Map<string, MonthRow>();
    for (const b of bills) {
      const month = b.date.slice(0, 7); // yyyy-mm
      const row = map.get(month) ?? {
        month, bills: 0, subtotal: 0, discount: 0, taxable: 0,
        cgst: 0, sgst: 0, igst: 0, roundOff: 0, grand: 0,
      };
      row.bills += 1;
      row.subtotal += b.totals.subtotal;
      row.discount += b.totals.discount;
      row.taxable += b.totals.taxable;
      row.cgst += b.totals.cgst;
      row.sgst += b.totals.sgst;
      row.igst += b.totals.igst;
      row.roundOff += b.totals.roundOff;
      row.grand += b.totals.grandTotal;
      map.set(month, row);
    }

    const rows = Array.from(map.values()).sort((a, b) => (a.month < b.month ? -1 : 1));
    const f = (n: number) => n.toFixed(2);

    const header = ['Month', 'Bills', 'Subtotal', 'Discount', 'Taxable Value', 'CGST', 'SGST', 'IGST', 'Round Off', 'Grand Total'];
    const body = rows.map((r) => [
      r.month, r.bills, f(r.subtotal), f(r.discount), f(r.taxable),
      f(r.cgst), f(r.sgst), f(r.igst), f(r.roundOff), f(r.grand),
    ]);
    const totals: (string | number)[] = ['TOTAL', rows.reduce((s, r) => s + r.bills, 0)];
    for (const key of ['subtotal', 'discount', 'taxable', 'cgst', 'sgst', 'igst', 'roundOff', 'grand'] as const) {
      totals.push(f(rows.reduce((s, r) => s + r[key], 0)));
    }

    const csv = [header, ...body, totals].map((r) => r.map(csvCell).join(',')).join('\r\n');
    return new NextResponse(`\uFEFF${csv}`, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="gst-monthly-summary-${new Date().toISOString().slice(0, 10)}.csv"`,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: 'report failed', detail: String(e) }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { listBills } from '@/lib/studio/store';
import { billStatus, docTypeOf, dueAmount, fmtDate, paidAmount } from '@/lib/studio/format';

export const dynamic = 'force-dynamic';

function csvCell(v: string | number): string {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get('from');
  const to = searchParams.get('to');
  const idsParam = searchParams.get('ids');
  const ids = idsParam ? new Set(idsParam.split(',').map((s) => s.trim()).filter(Boolean)) : null;
  let bills = await listBills();
  if (ids) bills = bills.filter((b) => ids.has(b.id));
  if (from) bills = bills.filter((b) => b.date >= from);
  if (to) bills = bills.filter((b) => b.date <= to);
  bills.sort((a, b) => (a.date < b.date ? -1 : 1));

  const header = [
    'Bill No', 'Date', 'Doc Type', 'Buyer', 'Buyer GSTIN', 'Items', 'Total Qty',
    'Subtotal', 'Discount', 'Taxable', 'CGST', 'SGST', 'IGST',
    'Round Off', 'Grand Total', 'Status', 'Paid', 'Due', 'Payments', 'Template', 'Prints', 'Created At',
  ];
  const rows = bills.map((b) => [
    b.billNo,
    fmtDate(b.date),
    docTypeOf(b),
    b.variables['buyer_name'] ?? '',
    b.variables['buyer_gst'] ?? '',
    b.items.length,
    b.totals.totalQty,
    b.totals.subtotal.toFixed(2),
    b.totals.discount.toFixed(2),
    b.totals.taxable.toFixed(2),
    b.totals.cgst.toFixed(2),
    b.totals.sgst.toFixed(2),
    b.totals.igst.toFixed(2),
    b.totals.roundOff.toFixed(2),
    b.totals.grandTotal.toFixed(2),
    billStatus(b),
    paidAmount(b).toFixed(2),
    dueAmount(b).toFixed(2),
    (b.payments ?? []).length,
    b.templateName,
    b.printCount,
    b.createdAt,
  ]);

  const csv = [header, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n');
  return new NextResponse(`\uFEFF${csv}`, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="bills-export-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}

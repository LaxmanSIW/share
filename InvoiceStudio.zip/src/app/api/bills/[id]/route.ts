import { NextRequest, NextResponse } from 'next/server';
import { listBills, mutateBills, getSettings } from '@/lib/studio/store';
import type { Bill } from '@/lib/studio/types';
import { computeTotals } from '@/lib/studio/format';
import { sanitizeItems, sanitizePayments } from '@/lib/studio/sanitize';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const bills = await listBills();
  const bill = bills.find((b) => b.id === id);
  if (!bill) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
  return NextResponse.json(bill);
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<Bill>;

  // normalize whichever collections the client sent
  const items = Array.isArray(body.items) ? sanitizeItems(body.items) : null;
  const payments = body.payments === undefined ? null : sanitizePayments(body.payments);
  const interState = !!(await getSettings()).interState;

  const result = await mutateBills((bills) => {
    const idx = bills.findIndex((b) => b.id === id);
    if (idx === -1) return bills;
    const current = bills[idx];
    const nextItems = items ?? current.items;

    // if items/discount changed, recompute totals so stored data stays consistent
    const itemsChanged = items !== null || body.discountPct !== undefined;
    const totals = itemsChanged
      ? computeTotals(nextItems, Number(body.discountPct ?? current.discountPct) || 0, interState)
      : (body.totals ?? current.totals);

    const next: Bill = {
      ...current,
      ...body,
      items: nextItems,
      payments: payments ?? current.payments,
      totals,
      repeat: body.repeat === undefined ? current.repeat : ['weekly', 'monthly', 'yearly'].includes(body.repeat as string) ? body.repeat : 'none',
      id: current.id,
      createdAt: current.createdAt,
      updatedAt: new Date().toISOString(),
    };
    return bills.map((b) => (b.id === id ? next : b));
  });

  const out = result.find((b) => b.id === id);
  if (!out) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
  return NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  let removed = false;
  await mutateBills((bills) => {
    const next = bills.filter((b) => b.id !== id);
    removed = next.length !== bills.length;
    return next;
  });
  if (!removed) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

import { NextRequest, NextResponse } from 'next/server';
import { mutateBills } from '@/lib/studio/store';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/** Records a print event (increments printCount). */
export async function POST(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const bills = await mutateBills((arr) =>
    arr.map((b) =>
      b.id === id
        ? { ...b, printCount: (b.printCount || 0) + 1, updatedAt: new Date().toISOString() }
        : b,
    ),
  );
  const bill = bills.find((b) => b.id === id);
  if (!bill) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
  return NextResponse.json(bill);
}

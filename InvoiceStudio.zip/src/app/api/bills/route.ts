import { NextRequest, NextResponse } from 'next/server';
import { listBills, mutateBills, getSettings, saveSettings } from '@/lib/studio/store';
import type { Bill } from '@/lib/studio/types';
import { uid, computeTotals, amountInWords } from '@/lib/studio/format';
import { sanitizeItems, sanitizePayments } from '@/lib/studio/sanitize';

export const dynamic = 'force-dynamic';

export async function GET() {
  const bills = await listBills();
  // newest first
  bills.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  return NextResponse.json(bills);
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as Partial<Bill>;
  if (!body.templateId || !body.billNo) {
    return NextResponse.json({ error: 'templateId and billNo are required' }, { status: 400 });
  }
  const now = new Date().toISOString();
  const items = sanitizeItems(body.items);
  const settings0 = await getSettings();
  // server-recomputed totals keep the stored bill consistent with its items
  const totals =
    Array.isArray(body.items) && items.length >= 0
      ? computeTotals(items, Number(body.discountPct) || 0, !!settings0.interState)
      : (body.totals ?? {
          subtotal: 0, discount: 0, taxable: 0, cgst: 0, sgst: 0, igst: 0,
          roundOff: 0, grandTotal: 0, totalQty: 0, itemCount: 0,
        });
  const bill: Bill = {
    id: uid('bill'),
    billNo: body.billNo,
    date: body.date || now.slice(0, 10),
    templateId: body.templateId,
    templateName: body.templateName ?? '',
    variables: body.variables ?? {},
    items,
    discountPct: Number(body.discountPct) || 0,
    totals,
    amountInWords: body.amountInWords || amountInWords(totals.grandTotal),
    notes: body.notes ?? '',
    printCount: 0,
    status: body.status === 'paid' || body.status === 'cancelled' || body.status === 'unpaid' ? body.status : 'unpaid',
    paidAt: body.status === 'paid' ? now : undefined,
    docType: ['proforma', 'quotation', 'challan', 'creditnote'].includes(body.docType as string) ? body.docType : 'invoice',
    repeat: ['weekly', 'monthly', 'yearly'].includes(body.repeat as string) ? body.repeat : 'none',
    repeatEndDate: typeof body.repeatEndDate === 'string' && body.repeatEndDate ? body.repeatEndDate : undefined,
    repeatSkipNext: body.repeatSkipNext === true ? true : undefined,
    payments: sanitizePayments(body.payments),
    createdAt: now,
    updatedAt: now,
  };
  await mutateBills((bills) => [...bills, bill]);
  // advance the bill number counter
  if (body.billNo === `${settings0.billNoPrefix}${String(settings0.billNoNext).padStart(4, '0')}`) {
    settings0.billNoNext = (settings0.billNoNext || 1) + 1;
    await saveSettings(settings0);
  }
  return NextResponse.json(bill, { status: 201 });
}

/* ============================================================
 * InvoiceStudio — PDF export API (server-only)
 * POST /api/pdf
 *   { kind: 'bill',     billId, copies?, includeStamp? }  → the designed document
 *   { kind: 'receipt',  billId, paymentId, receiptNo? }   → payment receipt (A5)
 *   { kind: 'statement',buyerName?, buyerId?, from?, to? }  → buyer account statement (A4)
 * Returns the PDF binary (application/pdf, attachment).
 * ============================================================ */
import { NextRequest, NextResponse } from 'next/server';
import React from 'react';
import BillPreview from '@/components/studio/BillPreview';
import PaymentReceipt from '@/components/studio/PaymentReceipt';
import { getSettings, listBills, listTemplates } from '@/lib/studio/store';
import { wrapPrintHtml, htmlToPdf, renderStaticMarkup } from '@/lib/studio/pdfEngine';
import { billStatus, docTypeOf, dueAmount, fmtDate, fmtMoney, paidAmount, DOC_TYPE_TITLE } from '@/lib/studio/format';
import type { Bill, Settings, Template } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const APP_ORIGIN = process.env.PDF_BASE_URL || 'http://127.0.0.1:3000';

function safeFilename(name: string): string {
  return (name || 'document').replace(/[^\w.\-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 80) || 'document';
}

/* ---------------- statement document ---------------- */

function buildStatementHtml(
  buyerName: string,
  bills: Bill[],
  settings: Settings,
  from: string,
  to: string,
): { markup: string; filename: string } {
  const cur = settings.currency;
  const biz = settings.business;
  const invoices = bills.filter((b) => docTypeOf(b) !== 'creditnote' && docTypeOf(b) !== 'challan');
  const credits = bills.filter((b) => docTypeOf(b) === 'creditnote');

  const billed = invoices.reduce((s, b) => s + b.totals.grandTotal, 0);
  const credited = credits.reduce((s, b) => s + b.totals.grandTotal, 0);
  const received = invoices.reduce((s, b) => s + paidAmount(b), 0);
  const outstanding = invoices.reduce((s, b) => s + dueAmount(b), 0);

  // aging buckets by bill date vs today (outstanding invoices only)
  const today = new Date(`${new Date().toISOString().slice(0, 10)}T00:00:00`).getTime();
  const buckets = { current: 0, d30: 0, d60: 0, d90: 0, d90p: 0 };
  for (const b of invoices) {
    const due = dueAmount(b);
    if (due <= 0 || billStatus(b) === 'cancelled') continue;
    const ageDays = Math.floor((today - new Date(`${b.date}T00:00:00`).getTime()) / 86400000);
    if (ageDays <= 0) buckets.current += due;
    else if (ageDays <= 30) buckets.d30 += due;
    else if (ageDays <= 60) buckets.d60 += due;
    else if (ageDays <= 90) buckets.d90 += due;
    else buckets.d90p += due;
  }

  const rows = [...bills].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  const receipts = rows
    .flatMap((b) => (b.payments ?? []).map((p) => ({ b, p })))
    .sort((x, y) => (x.p.date < y.p.date ? -1 : 1));

  const cellTh: React.CSSProperties = { border: '0.4mm solid #b9b3a4', padding: '1.6mm 2mm', fontSize: '8pt', textAlign: 'left' };
  const cellTd: React.CSSProperties = { border: '0.3mm solid #cfc9ba', padding: '1.4mm 2mm', fontSize: '8.5pt' };
  const num = (v: number) => fmtMoney(v, cur);

  const txRows = rows.map((b) => {
    const dt = docTypeOf(b);
    const isCn = dt === 'creditnote';
    const total = isCn ? -b.totals.grandTotal : b.totals.grandTotal;
    const bal = dt === 'invoice' ? dueAmount(b) : null;
    const st = billStatus(b);
    return (
      <tr key={b.id}>
        <td style={cellTd}>{fmtDate(b.date)}</td>
        <td style={cellTd}>{DOC_TYPE_TITLE[dt]}</td>
        <td style={{ ...cellTd, fontFamily: 'monospace' }}><b>{b.billNo}</b></td>
        <td style={cellTd}>{b.items.length}</td>
        <td style={{ ...cellTd, textAlign: 'right', color: isCn ? '#9f1239' : undefined }}><b>{num(total)}</b></td>
        <td style={{ ...cellTd, textAlign: 'right' }}>{dt === 'invoice' ? num(paidAmount(b)) : '—'}</td>
        <td style={{ ...cellTd, textAlign: 'right', color: bal !== null && bal > 0 ? '#b45309' : undefined }}><b>{bal !== null ? num(bal) : '—'}</b></td>
        <td style={{ ...cellTd, textTransform: 'uppercase', fontSize: '7.5pt', letterSpacing: '0.4pt' }}>{st}</td>
      </tr>
    );
  });

  const receiptRows = receipts.map(({ b, p }) => (
    <tr key={p.id}>
      <td style={cellTd}>{fmtDate(p.date)}</td>
      <td style={cellTd}><b>{b.billNo}</b></td>
      <td style={cellTd}>{p.method}{p.reference ? <> · <span style={{ fontFamily: 'monospace' }}>{p.reference}</span></> : null}</td>
      <td style={{ ...cellTd, textAlign: 'right' }}><b style={{ color: '#0e7a4f' }}>{num(p.amount)}</b></td>
    </tr>
  ));

  const tile = (label: string, value: string, color = '#1a1a1a') => (
    <td style={{ border: '0.3mm solid #b9b3a4', padding: '2.5mm 3mm', width: '25%' }}>
      <div style={{ fontSize: '6.5pt', letterSpacing: '1.2pt', color: '#777' }}>{label}</div>
      <div style={{ fontSize: '11pt', fontWeight: 'bold', color, marginTop: '1mm' }}>{value}</div>
    </td>
  );

  const markup = renderStaticMarkup(
    <div
      style={{
        width: '210mm',
        minHeight: '297mm',
        background: '#ffffff',
        color: '#1a1a1a',
        fontFamily: 'Arial, Helvetica, sans-serif',
        padding: '12mm 12mm 10mm',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1.2mm solid #1a1a1a', paddingBottom: '3mm' }}>
        <div style={{ display: 'flex', gap: '4mm', minWidth: 0 }}>
          {biz.logo && (
            <img src={biz.logo} alt="logo" style={{ width: '15mm', height: '15mm', objectFit: 'contain' }} />
          )}
          <div>
            <div style={{ fontSize: '14pt', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.5pt' }}>{biz.name}</div>
            <div style={{ fontSize: '7.5pt', whiteSpace: 'pre-line', color: '#333', marginTop: '0.6mm' }}>{biz.address}</div>
            <div style={{ fontSize: '7.5pt', color: '#333' }}>
              {biz.phone && <>Ph {biz.phone} · </>}{biz.email}
            </div>
            {biz.gstin && <div style={{ fontSize: '7.5pt', fontWeight: 700 }}>GSTIN: {biz.gstin}</div>}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '13pt', fontWeight: 900, letterSpacing: '3pt', color: '#8a6a24' }}>STATEMENT</div>
          <div style={{ fontSize: '7.5pt', color: '#555', marginTop: '0.8mm' }}>Account summary</div>
          <div style={{ fontSize: '7.5pt', color: '#555' }}>
            {from || 'beginning'} → {to || fmtDate(new Date().toISOString().slice(0, 10))}
          </div>
        </div>
      </div>

      {/* buyer */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4mm' }}>
        <div>
          <div style={{ fontSize: '6.5pt', letterSpacing: '1.4pt', color: '#777' }}>PREPARED FOR</div>
          <div style={{ fontSize: '11.5pt', fontWeight: 700, marginTop: '0.8mm' }}>{buyerName}</div>
        </div>
        <div style={{ textAlign: 'right', fontSize: '7.5pt', color: '#555' }}>
          Generated {fmtDate(new Date().toISOString().slice(0, 10))}
        </div>
      </div>

      {/* summary tiles */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '4mm' }}>
        <tbody>
          <tr>
            {tile('TOTAL BILLED', num(billed - credited))}
            {tile('RECEIVED', num(received), '#0e7a4f')}
            {tile('CREDIT NOTES', num(credited), '#9f1239')}
            {tile('OUTSTANDING', num(outstanding), '#b45309')}
          </tr>
        </tbody>
      </table>

      {/* aging */}
      <div style={{ marginTop: '4mm' }}>
        <div style={{ fontSize: '6.5pt', letterSpacing: '1.4pt', color: '#777', marginBottom: '1.4mm' }}>OUTSTANDING BY AGE</div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <tbody>
            <tr>
              {([
                ['Not due', buckets.current],
                ['1–30 d', buckets.d30],
                ['31–60 d', buckets.d60],
                ['61–90 d', buckets.d90],
                ['90+ d', buckets.d90p],
              ] as [string, number][]).map(([label, v]) => (
                <td key={label} style={{ border: '0.3mm solid #b9b3a4', padding: '1.8mm 2mm', textAlign: 'center', width: '20%' }}>
                  <div style={{ fontSize: '6.5pt', letterSpacing: '0.8pt', color: '#777' }}>{label}</div>
                  <div style={{ fontSize: '9.5pt', fontWeight: 700, color: v > 0 ? '#b45309' : '#0e7a4f' }}>{fmtMoney(v, cur)}</div>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      {/* transactions */}
      <div style={{ marginTop: '5mm' }}>
        <div style={{ fontSize: '6.5pt', letterSpacing: '1.4pt', color: '#777', marginBottom: '1.4mm' }}>TRANSACTIONS</div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#efe9db' }}>
              <th style={cellTh}>Date</th>
              <th style={cellTh}>Document</th>
              <th style={cellTh}>No.</th>
              <th style={cellTh}>Items</th>
              <th style={{ ...cellTh, textAlign: 'right' }}>Total</th>
              <th style={{ ...cellTh, textAlign: 'right' }}>Received</th>
              <th style={{ ...cellTh, textAlign: 'right' }}>Balance</th>
              <th style={cellTh}>Status</th>
            </tr>
          </thead>
          <tbody>
            {txRows.length > 0 ? txRows : (
              <tr>
                <td colSpan={8} style={{ ...cellTd, textAlign: 'center', color: '#888' }}>
                  No transactions in this period.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* receipts */}
      {receipts.length > 0 && (
        <div style={{ marginTop: '5mm' }}>
          <div style={{ fontSize: '6.5pt', letterSpacing: '1.4pt', color: '#777', marginBottom: '1.4mm' }}>RECEIPTS</div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#efe9db' }}>
                <th style={cellTh}>Date</th>
                <th style={cellTh}>Invoice</th>
                <th style={cellTh}>Method / Reference</th>
                <th style={{ ...cellTh, textAlign: 'right' }}>Amount</th>
              </tr>
            </thead>
            <tbody>{receiptRows}</tbody>
          </table>
        </div>
      )}

      {/* footer */}
      <div style={{ marginTop: 'auto', paddingTop: '6mm', borderTop: '0.3mm solid #b9b3a4', display: 'flex', justifyContent: 'space-between', fontSize: '6.5pt', color: '#888' }}>
        <span>Computer-generated statement · {biz.name}{biz.gstin ? ` · GSTIN ${biz.gstin}` : ''}</span>
        <span>{bills.length} document{bills.length === 1 ? '' : 's'} listed</span>
      </div>
    </div>,
  );

  return { markup, filename: safeFilename(`Statement-${buyerName}`) };
}

/* ---------------- route ---------------- */

export async function POST(req: NextRequest) {
  let body: {
    kind?: string;
    billId?: string;
    paymentId?: string;
    receiptNo?: string;
    copies?: number;
    includeStamp?: boolean;
    buyerId?: string;
    buyerName?: string;
    from?: string;
    to?: string;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const kind = body.kind ?? 'bill';

  try {
    const settings = await getSettings();

    /* ---- bill document ---- */
    if (kind === 'bill') {
      if (!body.billId) return NextResponse.json({ error: 'billId is required' }, { status: 400 });
      const [bills, templates] = await Promise.all([listBills(), listTemplates()]);
      const bill = bills.find((b) => b.id === body.billId);
      if (!bill) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
      const template: Template | undefined = templates.find((t) => t.id === bill.templateId);
      if (!template) {
        return NextResponse.json({ error: 'The template used by this bill was deleted — PDF export is unavailable.' }, { status: 409 });
      }

      const copies = Math.max(1, Math.min(3, Number(body.copies) || 1));
      const roll = !!template.page.autoHeight;
      // fixed pages use the template height; continuous rolls measure the true
      // painted content (hide-when-blank / barcode overflow can exceed the estimate)
      const heightMm = roll ? undefined : template.page.height;

      const offX = template.printOffsetX !== undefined && template.printOffsetX !== null
        ? Number(template.printOffsetX) || 0
        : Number(settings.printOffsetX) || 0;
      const offY = template.printOffsetY !== undefined && template.printOffsetY !== null
        ? Number(template.printOffsetY) || 0
        : Number(settings.printOffsetY) || 0;

      const markup = renderStaticMarkup(
        <div id="print-root">
          <div style={offX || offY ? { transform: `translate(${offX}mm, ${offY}mm)` } : undefined}>
            {Array.from({ length: copies }).map((_, i) => (
              <div className="print-copy" key={i}>
                <BillPreview
                  template={template}
                  bill={bill}
                  settings={settings}
                  copyIndex={i}
                  multiPage
                  forPrint
                  showStatusStamp={body.includeStamp !== false && settings.statusStamp !== false}
                />
              </div>
            ))}
          </div>
        </div>,
      );

      const html = wrapPrintHtml(markup, {
        pageCss: roll
          ? `size: ${template.page.width}mm auto;`
          : `size: ${template.page.width}mm ${template.page.height}mm;`,
        baseUrl: `${APP_ORIGIN}/`,
        customFonts: settings.customFonts,
      });
      const bytes = await htmlToPdf({
        html,
        widthMm: template.page.width,
        heightMm,
        measureContent: roll,
      });
      return new NextResponse(new Uint8Array(bytes), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${safeFilename(bill.billNo)}.pdf"`,
          'Cache-Control': 'no-store',
        },
      });
    }

    /* ---- payment receipt ---- */
    if (kind === 'receipt') {
      if (!body.billId || !body.paymentId) {
        return NextResponse.json({ error: 'billId and paymentId are required' }, { status: 400 });
      }
      const bills = await listBills();
      const bill = bills.find((b) => b.id === body.billId);
      if (!bill) return NextResponse.json({ error: 'Bill not found' }, { status: 404 });
      const payment = (bill.payments ?? []).find((p) => p.id === body.paymentId);
      if (!payment) return NextResponse.json({ error: 'Payment not found' }, { status: 404 });
      const idx = (bill.payments ?? []).findIndex((p) => p.id === body.paymentId);
      const receiptNo = body.receiptNo || `RCP-${bill.billNo}-${String(idx + 1).padStart(2, '0')}`;

      const markup = renderStaticMarkup(
        <div id="print-root">
          <PaymentReceipt bill={bill} payment={payment} receiptNo={receiptNo} settings={settings} />
        </div>,
      );
      const html = wrapPrintHtml(markup, { pageCss: 'size: 148mm 210mm;', baseUrl: `${APP_ORIGIN}/` });
      const bytes = await htmlToPdf({ html, widthMm: 148, heightMm: 210 });
      return new NextResponse(new Uint8Array(bytes), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${safeFilename(`Receipt-${receiptNo}`)}.pdf"`,
          'Cache-Control': 'no-store',
        },
      });
    }

    /* ---- buyer account statement ---- */
    if (kind === 'statement') {
      const bills = await listBills();
      let buyerName = (body.buyerName ?? '').trim();
      if (!buyerName && body.buyerId) {
        const hit = bills.find((b) => b.variables['buyer_id'] === body.buyerId);
        buyerName = hit?.variables['buyer_name'] ?? '';
      }
      if (!buyerName) return NextResponse.json({ error: 'buyerName or buyerId is required' }, { status: 400 });

      const from = body.from ?? '';
      const to = body.to ?? '';
      const scoped = bills.filter((b) => {
        if ((b.variables['buyer_name'] ?? '') !== buyerName) return false;
        if (from && b.date < from) return false;
        if (to && b.date > to) return false;
        return true;
      });
      if (scoped.length === 0) {
        return NextResponse.json({ error: 'No documents found for this buyer in the selected period.' }, { status: 404 });
      }

      const { markup, filename } = buildStatementHtml(buyerName, scoped, settings, from, to);
      const html = wrapPrintHtml(markup, { pageCss: 'size: 210mm 297mm;', baseUrl: `${APP_ORIGIN}/` });
      const bytes = await htmlToPdf({ html, widthMm: 210, heightMm: 297 });
      return new NextResponse(new Uint8Array(bytes), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${filename}.pdf"`,
          'Cache-Control': 'no-store',
        },
      });
    }

    return NextResponse.json({ error: `Unknown kind "${kind}"` }, { status: 400 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'PDF rendering failed';
    console.error('[api/pdf]', msg);
    return NextResponse.json({ error: `PDF export failed: ${msg}` }, { status: 500 });
  }
}

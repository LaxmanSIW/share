import { NextRequest, NextResponse } from 'next/server';
import { listItems, mutateItems } from '@/lib/studio/store';
import type { ItemRecord } from '@/lib/studio/types';
import { uid } from '@/lib/studio/format';

export const dynamic = 'force-dynamic';

/** GET -> all saved items (name A-Z) */
export async function GET() {
  const items = await listItems();
  items.sort((a, b) => a.name.localeCompare(b.name));
  return NextResponse.json(items);
}

/** POST -> create or upsert item by name */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Partial<ItemRecord>;
    const name = (body.name ?? '').trim();
    if (!name) {
      return NextResponse.json({ error: 'Item name / description is required' }, { status: 400 });
    }

    const now = new Date().toISOString();
    let createdFlag = false;

    const items = await mutateItems((list) => {
      const idx = list.findIndex((it) => it.name.toLowerCase() === name.toLowerCase());
      if (idx >= 0) {
        const merged: ItemRecord = {
          ...list[idx],
          hsn: body.hsn !== undefined ? body.hsn.trim() : list[idx].hsn,
          unit: body.unit !== undefined ? (body.unit.trim() || 'PCS') : list[idx].unit,
          rate: body.rate !== undefined ? Number(body.rate) || 0 : list[idx].rate,
          gst: body.gst !== undefined ? Number(body.gst) || 0 : list[idx].gst,
          updatedAt: now,
        };
        return list.map((it, i) => (i === idx ? merged : it));
      }

      createdFlag = true;
      const newItem: ItemRecord = {
        id: uid('item'),
        name,
        hsn: (body.hsn ?? '').trim(),
        unit: (body.unit ?? '').trim() || 'PCS',
        rate: Number(body.rate) || 0,
        gst: Number(body.gst) || 0,
        createdAt: now,
        updatedAt: now,
      };
      return [...list, newItem];
    });

    const saved = items.find((it) => it.name.toLowerCase() === name.toLowerCase());
    return NextResponse.json(saved, { status: createdFlag ? 201 : 200 });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}

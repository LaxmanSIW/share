import { NextRequest, NextResponse } from 'next/server';
import { mutateItems } from '@/lib/studio/store';
import type { ItemRecord } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<ItemRecord>;

  const items = await mutateItems((list) =>
    list.map((it) =>
      it.id === id
        ? {
            ...it,
            name: (body.name ?? it.name).trim() || it.name,
            hsn: body.hsn !== undefined ? body.hsn.trim() : it.hsn,
            unit: body.unit !== undefined ? (body.unit.trim() || 'PCS') : it.unit,
            rate: body.rate !== undefined ? Number(body.rate) || 0 : it.rate,
            gst: body.gst !== undefined ? Number(body.gst) || 0 : it.gst,
            updatedAt: new Date().toISOString(),
          }
        : it,
    ),
  );

  const out = items.find((it) => it.id === id);
  if (!out) return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  return NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  let removed = false;

  await mutateItems((list) => {
    const next = list.filter((it) => it.id !== id);
    removed = next.length !== list.length;
    return next;
  });

  if (!removed) return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

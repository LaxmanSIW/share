import { NextResponse } from 'next/server';
import { runRecurringSweep } from '@/lib/studio/recurring';

export const dynamic = 'force-dynamic';

/**
 * POST /api/recurring/sweep
 * Creates the next occurrence of every due recurring invoice
 * (at most once per day; respects the Settings → auto-create switch).
 * Body { force: true } runs even when off / already run today.
 */
export async function POST(req: Request) {
  let force = false;
  try {
    const body = (await req.json()) as { force?: boolean };
    force = !!body?.force;
  } catch {
    /* empty body is fine */
  }
  const result = await runRecurringSweep(force);
  return NextResponse.json({
    ran: result.ran,
    reason: result.reason,
    createdCount: result.created.length,
    created: result.created.map((b) => ({ id: b.id, billNo: b.billNo, date: b.date, buyer: b.variables['buyer_name'] ?? '' })),
    sourceNos: result.sourceNos,
    skipped: result.skipped,
    ended: result.ended,
  });
}

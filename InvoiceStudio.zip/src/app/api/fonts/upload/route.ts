import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

const ALLOWED_EXTENSIONS = new Set(['.woff2', '.woff', '.ttf', '.otf']);

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    const customName = (formData.get('name') as string | null)?.trim();

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    const originalName = file.name;
    const ext = path.extname(originalName).toLowerCase();

    if (!ALLOWED_EXTENSIONS.has(ext)) {
      return NextResponse.json(
        { error: `Unsupported font format. Allowed: ${Array.from(ALLOWED_EXTENSIONS).join(', ')}` },
        { status: 400 },
      );
    }

    // Determine clean font name
    const baseName = path.basename(originalName, ext).replace(/[_-]+/g, ' ').trim();
    const fontName = customName || baseName;

    // Detect format descriptor for @font-face
    let format: 'woff2' | 'woff' | 'truetype' | 'opentype' = 'truetype';
    if (ext === '.woff2') format = 'woff2';
    else if (ext === '.woff') format = 'woff';
    else if (ext === '.otf') format = 'opentype';

    // Read bytes
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Save to public/fonts directory
    const fontsDir = path.join(process.cwd(), 'public', 'fonts');
    if (!fs.existsSync(fontsDir)) {
      fs.mkdirSync(fontsDir, { recursive: true });
    }

    const safeFilename = `${Date.now()}-${baseName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}${ext}`;
    const filePath = path.join(fontsDir, safeFilename);
    fs.writeFileSync(filePath, buffer);

    const fileUrl = `/fonts/${safeFilename}`;
    const mimeType = ext === '.woff2' ? 'font/woff2' : ext === '.woff' ? 'font/woff' : ext === '.otf' ? 'font/otf' : 'font/ttf';
    const dataUrl = `data:${mimeType};base64,${buffer.toString('base64')}`;

    return NextResponse.json({
      ok: true,
      name: fontName,
      family: `'${fontName}', sans-serif`,
      fileUrl,
      dataUrl,
      format,
    });
  } catch (error) {
    console.error('Error handling font upload:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Font upload failed' },
      { status: 500 },
    );
  }
}

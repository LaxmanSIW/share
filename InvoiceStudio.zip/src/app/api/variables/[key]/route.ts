import { NextRequest, NextResponse } from 'next/server';
import { listVariables, saveVariables, builtinVars } from '@/lib/studio/store';
import type { VariableDef } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ key: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const { key } = await ctx.params;
  const body = (await req.json()) as Partial<VariableDef>;
  const vars = await listVariables();
  const idx = vars.findIndex((v) => v.key === key);
  if (idx === -1) return NextResponse.json({ error: 'Variable not found' }, { status: 404 });
  vars[idx] = {
    ...vars[idx],
    label: (body.label ?? vars[idx].label).trim() || vars[idx].label,
    type: body.type === 'number' || body.type === 'date' ? body.type : vars[idx].type,
  };
  await saveVariables(vars);
  return NextResponse.json(vars[idx]);
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { key } = await ctx.params;
  if (builtinVars().some((v) => v.key === key)) {
    return NextResponse.json({ error: 'Built-in variables cannot be deleted' }, { status: 400 });
  }
  const vars = await listVariables();
  const next = vars.filter((v) => v.key !== key);
  if (next.length === vars.length) {
    return NextResponse.json({ error: 'Variable not found' }, { status: 404 });
  }
  await saveVariables(next);
  return NextResponse.json({ ok: true });
}

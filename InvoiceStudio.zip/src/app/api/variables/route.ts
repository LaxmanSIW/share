import { NextRequest, NextResponse } from 'next/server';
import { listVariables, saveVariables, builtinVars } from '@/lib/studio/store';
import type { VariableDef } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  const custom = await listVariables();
  return NextResponse.json({ builtin: builtinVars(), custom });
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as Partial<VariableDef>;
  const key = (body.key ?? '').trim();
  const label = (body.label ?? '').trim();
  if (!key || !label) {
    return NextResponse.json({ error: 'key and label are required' }, { status: 400 });
  }
  if (!/^[a-z0-9_]+$/.test(key)) {
    return NextResponse.json(
      { error: 'Key may only contain lowercase letters, numbers and underscores' },
      { status: 400 },
    );
  }
  const builtin = builtinVars();
  if (builtin.some((v) => v.key === key)) {
    return NextResponse.json({ error: 'This key is reserved (built-in variable)' }, { status: 409 });
  }
  const vars = await listVariables();
  if (vars.some((v) => v.key === key)) {
    return NextResponse.json({ error: 'A variable with this key already exists' }, { status: 409 });
  }
  const def: VariableDef = {
    key,
    label,
    type: body.type === 'number' || body.type === 'date' ? body.type : 'text',
  };
  vars.push(def);
  await saveVariables(vars);
  return NextResponse.json(def, { status: 201 });
}

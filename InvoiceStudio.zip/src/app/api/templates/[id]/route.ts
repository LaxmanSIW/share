import { NextRequest, NextResponse } from 'next/server';
import { listTemplates, mutateTemplates } from '@/lib/studio/store';
import type { Template } from '@/lib/studio/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const templates = await listTemplates();
  const tpl = templates.find((t) => t.id === id);
  if (!tpl) return NextResponse.json({ error: 'Template not found' }, { status: 404 });
  return NextResponse.json(tpl);
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<Template>;
  const result = await mutateTemplates((templates) => {
    const idx = templates.findIndex((t) => t.id === id);
    if (idx === -1) return templates;
    const current = templates[idx];
    // per-template print offsets: null clears the override (falls back to Settings)
    const offsetX = 'printOffsetX' in body
      ? (body.printOffsetX === null || body.printOffsetX === undefined ? undefined : Number(body.printOffsetX) || 0)
      : current.printOffsetX;
    const offsetY = 'printOffsetY' in body
      ? (body.printOffsetY === null || body.printOffsetY === undefined ? undefined : Number(body.printOffsetY) || 0)
      : current.printOffsetY;
    const updated: Template = {
      ...current,
      ...body,
      printOffsetX: offsetX,
      printOffsetY: offsetY,
      id: current.id,
      createdAt: current.createdAt,
      updatedAt: new Date().toISOString(),
    };
    return templates.map((t, i) => (i === idx ? updated : t));
  });
  const out = result.find((t) => t.id === id);
  if (!out) return NextResponse.json({ error: 'Template not found' }, { status: 404 });
  return NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  let removed = false;
  await mutateTemplates((templates) => {
    const next = templates.filter((t) => t.id !== id);
    removed = next.length !== templates.length;
    return next;
  });
  if (!removed) return NextResponse.json({ error: 'Template not found' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

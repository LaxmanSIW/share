import { NextRequest, NextResponse } from 'next/server';
import { listTemplates, mutateTemplates } from '@/lib/studio/store';
import type { Template } from '@/lib/studio/types';
import { uid } from '@/lib/studio/format';

export const dynamic = 'force-dynamic';

export async function GET() {
  const templates = await listTemplates();
  return NextResponse.json(templates);
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as Partial<Template>;
  if (!body.name || typeof body.name !== 'string') {
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  }
  const now = new Date().toISOString();
  const template: Template = {
    id: uid('tpl'),
    name: body.name,
    page: body.page ?? {
      sizeName: 'A4',
      width: 210,
      height: 297,
      orientation: 'portrait',
      margin: { top: 8, right: 8, bottom: 8, left: 8 },
    },
    elements: body.elements ?? [],
    createdAt: now,
    updatedAt: now,
  };
  await mutateTemplates((templates) => [template, ...templates]);
  return NextResponse.json(template, { status: 201 });
}
